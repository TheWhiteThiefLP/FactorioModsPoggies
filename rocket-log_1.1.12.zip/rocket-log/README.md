# rocket-log
 Factorio mod in Lua: Logging system for Space Exploration Cargo Rocket launches
