recipe = data.raw["recipe"]["flying-robot-frame"]
recipe.ingredients = {
    {name = "electronic-circuit", amount = 3},
    {name = "iron-stick", amount = 20},
    {name = "copper-plate", amount = 10},
    {name = "iron-gear-wheel", amount = 4}
}
recipe.enabled = true