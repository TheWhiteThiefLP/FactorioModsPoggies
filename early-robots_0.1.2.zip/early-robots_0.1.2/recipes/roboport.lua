recipe = data.raw["recipe"]["roboport"]
recipe.ingredients = {
    {name = "electronic-circuit", amount = 45},
    {name = "iron-plate", amount = 100},
    {name = "iron-gear-wheel", amount = 45}
}
recipe.enabled = true