recipe = data.raw["recipe"]["logistic-robot"]
recipe.ingredients = {
    {name = "electronic-circuit", amount = 2},
    {name = "flying-robot-frame", amount = 1}
}
recipe.enabled = true