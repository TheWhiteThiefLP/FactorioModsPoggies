chests = {
    "logistic-chest-active-provider",
    "logistic-chest-passive-provider",
    "logistic-chest-storage",
    "logistic-chest-requester",
    "logistic-chest-buffer"
}

for i, chest in ipairs(chests) do
    data.raw["recipe"][chest].ingredients = 
    {
        {name = "electronic-circuit", amount = 5},
        {name = "iron-chest", amount = 1},
        {name = "iron-plate", amount = 24},
    }
    data.raw["recipe"][chest].enabled = true
end