chests = {
    "logistic-chest-active-provider",
    "logistic-chest-passive-provider",
    "logistic-chest-storage",
    "logistic-chest-requester",
    "logistic-chest-buffer"
}

for i, chest in ipairs(chests) do
    data.raw["logistic-container"][chest].inventory_size = 49
end