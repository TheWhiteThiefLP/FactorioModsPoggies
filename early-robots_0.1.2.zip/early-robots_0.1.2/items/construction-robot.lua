bot = data.raw["construction-robot"]["construction-robot"]
bot.energy_per_move = "2kJ"
bot.energy_per_tick = "1200W"
bot.max_energy = "600kJ"