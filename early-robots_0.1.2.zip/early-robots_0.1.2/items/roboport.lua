port = data.raw["roboport"]["roboport"]
port.charging_energy = "400kW"
port.energy_usage = "20kW"
port.energy_source.buffer_capacity = "40MJ"
port.energy_source.input_flow_limit = "2MW"
