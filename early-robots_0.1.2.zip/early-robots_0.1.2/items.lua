items = {
    "construction-robot",
    "logistic-robot",
    "roboport",
    "logistic-chests"
}

for i, item in ipairs(items) do
    require("items." .. item)
end