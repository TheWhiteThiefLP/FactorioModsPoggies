recipes = {
    "flying-robot-frame",
    "construction-robot",
    "logistic-robot",
    "roboport",
    "logistic-chests"
}

for i, recipe in ipairs(recipes) do
    require("recipes." .. recipe)
end