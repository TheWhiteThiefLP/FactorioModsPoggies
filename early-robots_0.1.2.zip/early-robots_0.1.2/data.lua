energy_multiplier = 0.4
require("items")
require("recipes")