﻿log("LIBORIO CONTROL")
require("prototypes.scripts.defines") 
require("prototypes.scripts.util") 