﻿log("LIBORIO UTIL")
require("defines")
require("sharedutil")

function get_liborio()
	return liborio 
end