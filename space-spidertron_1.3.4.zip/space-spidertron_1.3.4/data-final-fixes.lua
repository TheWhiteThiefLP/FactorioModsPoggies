-- This must done last to support SEK2, which
-- changes the recipe after data-final-fixes
require("prototypes.recipes")