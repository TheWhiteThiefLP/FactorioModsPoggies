
data:extend({
    {
        type = "bool-setting",
        name = "space-spidertron-allow-other-spiders-in-space",
        setting_type = "startup",
        order = "m",
        default_value = false,
        hidden = not mods["space-exploration"],
    }
})