local handler = require "__core__.lualib.event_handler"

handler.add_lib(require "scripts.upgrader")