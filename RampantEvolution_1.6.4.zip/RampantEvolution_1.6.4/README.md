# Rampant Evolution

Changes evolution mechanic to allow for green play and changes how evolution increases

https://mods.factorio.com/mod/RampantEvolution

# Notes

If you want to donate:
https://ko-fi.com/rampant

By default:  
New game map settings for evolution from pollution, spawners, and time are set to 0  

Evolution can be configured for:  

- Pollution absorbed by Spawners
- Pollution damaging trees
- Pollution absorbed by trees
- Pollution absorbed by tiles
- Killing Spawners
- Killing Units
- Killing Worms
- Killing Hives (Rampant New Enemies)
- Total Pollution (Similar to vanilla)
- Time (Similar to vanilla)

- Minimum Evolution can be set as a percentage of peak evolution

Console Commands
`/rampantEvolution` displays the evolution stats in the console.
