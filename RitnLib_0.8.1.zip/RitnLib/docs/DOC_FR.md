# RitnLib

Ce mod est une librairie de fonctions et depuis la version 0.7 elle ajoute surtout des classes utilisées dans la plupart des RitnMods.
Vous pouvez évidement utiliser cette bibliothèque pour vos mods.
