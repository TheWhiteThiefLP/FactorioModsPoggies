## Utilisation :

Dans votre mod, ajouté simplement ce RitnLib en dépendance dans le fichier "info.json".