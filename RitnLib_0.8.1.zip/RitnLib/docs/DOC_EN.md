# RitnLib

This mod is a library of functions and since version 0.7 it mainly adds classes used in most of the RitnMods.
You can of course use this library for your mods.
