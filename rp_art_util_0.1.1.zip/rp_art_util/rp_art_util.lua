local rp_art_util = {};
local util = require('util')
local function get_entity_prototype_name(entity_prototype)
    if not entity_prototype then return '[nil]' end
    return (entity_prototype.name or '[unnamed]') .. '(' .. (entity_prototype.type or 'unknown_type') .. ')'
end

local function array_to_set(arr)
    local ret = {};
    for _, value in pairs(arr) do
        ret[value] = true
    end
    return ret;
end

local function get_turret_tint_color(rp_art, inputs)
    if inputs.tint then
        return inputs.tint
    elseif settings.startup['rp_art_util_turret_tint_mode'].value == 'icon_color' then
        return rp_art.icon_tint
    end
    return nil
end

rp_art_util.item_subtypes = array_to_set {
    'item', 'ammo', 'capsule', 'gun', 'item-with-entity-data', 'item-with-label',
    'item-with-inventory', 'blueprint-book', 'item-with-tags', 'selection-tool',
    'blueprint', 'copy-paste-tool', 'deconstruction-item', 'upgrade-item', 'module',
    'rail-planner', 'spidertron-remote', 'tool', 'armor', 'mining-tool', 'repair-tool'
}

local function assert_is_rp_art_object(rp_art)
    if not rp_art then
        error('"rp_art" cannot be null')
    end
    if not rp_art.api_version then
        error('"rp_art" does not appear to be an RP Art object\n' .. serpent.block(rp_art))
    end
    if rp_art.api_version ~= 2 then
        error(
            '"The RP Art assets were made for a different version than the utility library understands. Please update your mods. If the problem persists, then please wait a little while before filing a bug. We are probably in the process of updating them.\n\nrp_art.api_version = '
            ..
            rp_art.api_version)
    end
end

--- Converts a Y-up 3d point to a factorio 2D point in {x,y}
function rp_art_util:p3d_to_warped_p2d(x, y, z)
    return {
        x = x,
        y = (y + z) / 2
    }
end

--- Converts a Y-up 3d point to a factorio 2D point in {x,y}
function rp_art_util:p3d_to_ortho_p2d(x, y, z)
    return {
        x = x,
        y = (y + z) * 0.7071067811865
    }
end

--- Converts a Y-up 3d point to a factorio 2D vector in {x,y}
function rp_art_util:p3d_to_ortho_v2d(x, y, z)
    return {
        x,
        (y + z) * 0.7071067811865
    }
end

function rp_art_util:p3d_add(a, b)
    return {
        x = (a.x + b.x),
        y = (a.y + b.y),
        z = (a.z + b.z),
    }
end

function rp_art_util:p3d_sub(a, b)
    return {
        x = (a.x - b.x),
        y = (a.y - b.y),
        z = (a.z - b.z),
    }
end

function rp_art_util:p3d_distance(a, b)
    return ((a.x - b.x) ^ 2 + (a.y - b.y) ^ 2 + (a.z - b.z) ^ 2) ^ 0.5
end

function rp_art_util:p3d_length(a)
    return (a.x ^ 2 + a.y ^ 2 + a.z ^ 2) ^ 0.5
end

-- Converts an `{x,y}` table to an offset array (y is negative)
function rp_art_util:p2d_to_offset(point)
    return { point.x, -point.y }
end

-- Converts an `{x,y}` table to an array (y is positive)
function rp_art_util:p2d_to_array(point)
    return { point.x, point.y }
end

function rp_art_util:get_scale_factor(footprint_size, rp_art)
    return footprint_size / rp_art.original_footprint_size;
end

--- Updates the entity_prototype to use the rp_art sprites. All the animations and
--- projectile launch positions will be updated. It will attempt to also update
--- icons. The rp_art_util:use_icon(...) function can (and should) be called
--- on the technology. Icons can also be accessed directly in the rp_art asset.
-- @param entity_prototype The factorio entity prototype
-- @param rp_art the art data returned from a `requre(rp_xyz_art)` call
-- @param inputs a table of additional optional parameters
-- @param inputs.footprint (optional) the width of the entity_prototype in tiles.
--        If not set, then it is inferred from the collision_box
-- @param inputs.enable_attack_animation (optional) Defaults to true. Very fast firing turrets will look silly if their attack animation wasn't made for that
-- @param inputs.ack_artillery_gun_warning (optional) allows you to use the
--        same gun for multiple artillery
function rp_art_util:use_sprites(entity_prototype, rp_art, inputs)
    if not entity_prototype then
        error('"entity_prototype" cannot be null')
    end
    assert_is_rp_art_object(rp_art)

    if not inputs then inputs = {} end

    if settings.startup['rp_art_util_debug_final_output'].value
        or settings.startup['rp_art_util_debug_muzzle'].value then
        log('Applying "' ..
            rp_art.name .. '" sprites to "' .. entity_prototype.name .. '" (' .. entity_prototype.type .. ')');
    end

    --log('Applying "' .. rp_art.name .. '" sprites to "' .. entity_prototype.name .. '" (' .. entity_prototype.type .. ')');
    local footprint_size = inputs.footprint_size or
        rp_art_util:get_bounding_box_footprint_size(entity_prototype.collision_box);

    if entity_prototype.type == 'ammo-turret'
        or entity_prototype.type == 'electric-turret'
        or entity_prototype.type == 'fluid-turret'
        or entity_prototype.type == 'turret' then
        rp_art_util:use_sprites_for_turret(entity_prototype, rp_art, inputs);
    elseif entity_prototype.type == 'artillery-turret' then
        rp_art_util:use_sprites_for_artillery_turret(entity_prototype, rp_art, inputs);
    elseif entity_prototype.type == 'car' then
        rp_art_util:use_sprites_for_car(entity_prototype, rp_art, inputs);
    elseif entity_prototype.type == 'ammo' then
        rp_art_util:set_muzzle_location_for_action_delivery(
            entity_prototype.ammo_type.action.action_delivery, footprint_size);
    else
        rp_art_util:use_icon(entity_prototype, rp_art)
    end
    if settings.startup['rp_art_util_debug_final_output'].value then
        log('Applied "' ..
            rp_art.name .. '" sprites to "' .. get_entity_prototype_name(entity_prototype) .. '\n'
            .. serpent.block(entity_prototype));
    end
    return entity_prototype
end

function rp_art_util:use_sprites_for_turret(entity_prototype, rp_art, inputs)
    assert(rp_art.type == 'turret',
        entity_prototype.name .. ' (' .. entity_prototype.type .. ') cannot use "' .. rp_art.type ..
        '" formatted sprites');
    assert((entity_prototype.type == 'ammo-turret'
        or entity_prototype.type == 'electric-turret'
        or entity_prototype.type == 'fluid-turret'
        or entity_prototype.type == 'turret'),
        entity_prototype.name .. ' (' .. entity_prototype.type .. ') has an invalid type');

    rp_art_util:use_sprites_for_entity(entity_prototype, rp_art, inputs)

    local footprint_size = inputs.footprint_size or
        rp_art_util:get_bounding_box_footprint_size(entity_prototype.collision_box);
    local tint = get_turret_tint_color(rp_art, inputs)

    entity_prototype.base_picture = self:to_factorio_animation_layers(rp_art.base_picture, {
        layer_description_style = 'stripes',
        footprint_size = footprint_size,
        tint = tint,
    });

    entity_prototype.preparing_speed = self:calc_animation_speed(rp_art.preparing, entity_prototype.preparing_speed);
    entity_prototype.preparing_animation = self:to_factorio_animation_layers(rp_art.preparing, {
        layer_description_style = 'stripes',
        footprint_size = footprint_size,
        tint = tint,
    });

    entity_prototype.folding_speed = self:calc_animation_speed(rp_art.preparing, entity_prototype.folding_speed);
    entity_prototype.folding_animation = self:to_factorio_animation_layers(rp_art.preparing, {
        layer_description_style = 'stripes',
        footprint_size = footprint_size,
        run_mode = 'backward',
        tint = tint,
    });

    --entity_prototype.folded_speed = ?
    entity_prototype.folded_animation = self:to_factorio_animation_layers(rp_art.preparing, {
        layer_description_style = 'stripes',
        footprint_size = footprint_size,
        frame_count = 1,
        tint = tint,
    });

    local attacking_frame_count = 1;
    if inputs.enable_attack_animation == nil or inputs.enable_attack_animation then
        attacking_frame_count = rp_art.attacking.num_frames
        if entity_prototype.attacking_speed == nil then
            entity_prototype.attacking_speed = self:duration_ticks_to_turret_animation_speed(
                rp_art.attacking.duration_ticks)
        end
    else
        attacking_frame_count = 1
        entity_prototype.attacking_speed = self:duration_ticks_to_turret_animation_speed(1)
    end
    entity_prototype.attacking_speed = self:calc_animation_speed(rp_art.attacking, entity_prototype.attacking_speed);
    entity_prototype.attacking_animation = self:to_factorio_animation_layers(rp_art.attacking, {
        layer_description_style = 'stripes',
        footprint_size = footprint_size,
        frame_count = attacking_frame_count,
        tint = tint,
    });

    --entity_prototype.prepared_speed = ?
    entity_prototype.prepared_animation = self:to_factorio_animation_layers(rp_art.attacking, {
        layer_description_style = 'stripes',
        footprint_size = footprint_size,
        frame_count = 1,
        tint = tint,
    });

    entity_prototype.attack_from_start_frame = true;
    entity_prototype.shoot_in_prepare_state = false;
    --rp_art_util:set_muzzle_location_for_attack_parameters(
    --entity_prototype.attack_parameters, rp_art, footprint_size, entity_prototype.type);
    rp_art_util:set_muzzle_location_for_attack_parameters_using_raw_points(
        entity_prototype.attack_parameters,
        rp_art_util:get_attachment_raw_positions(rp_art, footprint_size, rp_art.attacking, 'muzzle')[1],
        entity_prototype.type);

    -- These are not implemented/todo
    entity_prototype.prepared_alternative_animation = nil;
    entity_prototype.prepared_alternative_speed = nil;
    entity_prototype.starting_attack_animation = nil;
    entity_prototype.ending_attack_animation = nil;
    entity_prototype.ending_attack_speed = nil;
    entity_prototype.energy_glow_animation = nil;
    entity_prototype.energy_glow_speed = nil;
    entity_prototype.secondary_animation = false;
    entity_prototype.gun_animation_render_layer = nil;
    entity_prototype.gun_animation_secondary_draw_order = nil;
    entity_prototype.base_picture_render_layer = nil;
    entity_prototype.base_picture_secondary_draw_order = nil;

    -- The below are only used by fluid turrets
    if entity_prototype.type == 'fluid-turret'
        and (entity_prototype.muzzle_animation or entity_prototype.muzzle_light) then
        local attacking_av = rp_art_util:get_truncated_animated_vector(
            rp_art_util:get_attachment_points_as_animated_vector(
                rp_art, footprint_size,
                rp_art.attacking, 'muzzle'), attacking_frame_count)
        local preparing_av = rp_art_util:get_attachment_points_as_animated_vector(rp_art, footprint_size,
            rp_art.preparing, 'muzzle')
        local folding_av = rp_art_util:get_reversed_animated_vector(preparing_av)

        entity_prototype.attacking_muzzle_animation_shift = attacking_av;
        entity_prototype.ending_attack_muzzle_animation_shift = nil;
        entity_prototype.folded_muzzle_animation_shift =
            rp_art_util:get_truncated_animated_vector(preparing_av, 1);
        entity_prototype.folding_muzzle_animation_shift = folding_av;
        entity_prototype.prepared_muzzle_animation_shift =
            rp_art_util:get_truncated_animated_vector(attacking_av, 1);
        entity_prototype.preparing_muzzle_animation_shift = preparing_av;
        entity_prototype.starting_attack_muzzle_animation_shift = nil;
    else
        entity_prototype.muzzle_animation = nil;
        entity_prototype.attacking_muzzle_animation_shift = nil;
        entity_prototype.ending_attack_muzzle_animation_shift = nil;
        entity_prototype.folded_muzzle_animation_shift = nil;
        entity_prototype.folding_muzzle_animation_shift = nil;
        entity_prototype.prepared_muzzle_animation_shift = nil;
        entity_prototype.preparing_muzzle_animation_shift = nil;
        entity_prototype.starting_attack_muzzle_animation_shift = nil;
    end
end

function rp_art_util:use_sprites_for_artillery_turret(entity_prototype, rp_art, inputs)
    assert(entity_prototype.type == 'artillery-turret',
        entity_prototype.name .. ' (' .. entity_prototype.type .. ') has an invalid type');

    rp_art_util:use_sprites_for_entity(entity_prototype, rp_art, inputs);

    local footprint_size = inputs.footprint_size or
        rp_art_util:get_bounding_box_footprint_size(entity_prototype.collision_box);
    local tint = get_turret_tint_color(rp_art, inputs)

    entity_prototype.base_picture = self:to_factorio_animation_layers(rp_art.base_picture, {
        layer_description_style = 'filename',
        footprint_size = footprint_size,
        frame_count = 1,
        tint = tint,
    });
    entity_prototype.cannon_base_pictures = self:to_factorio_animation_layers(rp_art.attacking, {
        layer_description_style = 'filenames',
        footprint_size = footprint_size,
        frame_count = 1,
        tint = tint,
    });

    local gun = data.raw['gun'][entity_prototype.gun];
    if not gun then
        error('"' ..
            entity_prototype.gun ..
            '" (gun) is not defined (yet) but is being used by "' ..
            entity_prototype.name ..
            '" (' .. entity_prototype.type .. '). Please add it to "data" before calling this method.')
    end
    if gun.has_rp_sprites and not inputs.ack_artillery_gun_warning then
        error('"' ..
            gun.name ..
            '" (gun) has already been used by another artillery prototype. Using it again may have unintended concequences. Set "inputs.ack_artillery_gun_warning = true" to ignore this warning.\n'
            ..
            'Artillery use a secret gun entity for some properties. The same gun should not be shared across multiple entities unless they use identical textures.')
    end
    gun.has_rp_sprites = true;
    --rp_art_util:set_muzzle_location_for_attack_parameters(
    --gun.attack_parameters, rp_art, footprint_size, entity_prototype.type);
    rp_art_util:set_muzzle_location_for_attack_parameters_using_raw_points(
        gun.attack_parameters,
        rp_art_util:get_attachment_raw_positions(rp_art, footprint_size, rp_art.attacking, 'muzzle')[1],
        entity_prototype.type);

    entity_prototype.base_picture_render_layer = nil;
    entity_prototype.base_picture_secondary_draw_order = nil;
    entity_prototype.base_shift = nil; -- offsets the entire entity; all layers, the muzzle, even the shell casings
    entity_prototype.cannon_barrel_light_direction = nil;
    entity_prototype.cannon_barrel_pictures = nil;
    entity_prototype.cannon_barrel_recoil_shiftings = nil;
    entity_prototype.cannon_barrel_recoil_shiftings_load_correction_matrix = nil;
    entity_prototype.cannon_parking_frame_count = nil;
    entity_prototype.cannon_parking_speed = nil;
end

function rp_art_util:add_tire_tracks_to_car(entity_prototype, rp_art, footprint_size)
    local tire_attach_points = self:get_attachment_raw_positions(rp_art, footprint_size, rp_art.body, "ground_contact");
    local tire_track_art = entity_prototype.track_particle_triggers
    if tire_track_art then
        tire_track_art = util.table.deepcopy(tire_track_art)
    else
        local movement_triggers = require("__base__/prototypes/entity/movement-triggers")
        tire_track_art = movement_triggers[rp_art.type] or movement_triggers.car
    end
    local tire_track_offsets = {}
    for _, group in ipairs(tire_attach_points) do
        for _, offset in ipairs(group.offsets) do
            table.insert(tire_track_offsets, { offset.x, -offset.z })
        end
    end
    for _, tire_track_for_tile in ipairs(tire_track_art) do
        if tire_track_for_tile.offsets then
            tire_track_for_tile.offsets = util.table.deepcopy(tire_track_offsets)
        elseif tire_track_for_tile.actions then
            for _, action in ipairs(tire_track_for_tile.actions) do
                if action.offsets then
                    action.offsets = util.table.deepcopy(tire_track_offsets)
                end
            end
        end
    end
    entity_prototype.track_particle_triggers = tire_track_art
end

function rp_art_util:add_muffler_smoke_to_car(entity_prototype, rp_art, footprint_size)
    local energy_source = entity_prototype.burner or entity_prototype.energy_source
    if energy_source then
        local muffler_attach_points = self:get_attachment_raw_positions(rp_art, footprint_size, rp_art.body, "muffler");
        local smoke_art = energy_source.smoke
        if smoke_art then
            smoke_art = util.table.deepcopy(smoke_art)
        elseif rp_art.type == 'car' then
            -- Copied from car prototype
            smoke_art = { {
                name = "car-smoke",
                deviation = { 0.25, 0.25 },
                frequency = 200,
                position = { 0, 1.5 },
                starting_frame = 0,
                starting_frame_deviation = 60
            } }
        elseif rp_art.type == 'tank' then
            -- Copied from tank prototype
            smoke_art = { {
                name = "tank-smoke",
                deviation = { 0.25, 0.25 },
                frequency = 50,
                position = { 0, 1.5 },
                starting_frame = 0,
                starting_frame_deviation = 60
            } }
        end

        local car_smoke = {}
        for _, art in ipairs(smoke_art) do
            for _, group in ipairs(muffler_attach_points) do
                for _, offset in ipairs(group.offsets) do
                    local instance = util.table.deepcopy(art)
                    -- This uses array format instead of {x, y} points
                    -- This is a point instead of offset so the y-axis is negative compared to offset format
                    instance.position = { offset.x, -offset.z }
                    instance.height = offset.y
                    table.insert(car_smoke, instance)
                end
            end
        end
        energy_source.smoke = car_smoke
    end
end

function rp_art_util:add_headlights_to_car(entity_prototype, rp_art, footprint_size)
    local attach_points = self:get_attachment_raw_positions(rp_art, footprint_size, rp_art.body, "headlight");
    local light_prototype = entity_prototype.light
    if light_prototype then
        if light_prototype[1] then
            light_prototype = light_prototype[1]
        end
    else
        light_prototype = {
            type = "oriented",
            minimum_darkness = 0.3,
            picture = {
                filename = "__core__/graphics/light-cone.png",
                priority = "extra-high",
                flags = { "light" },
                scale = 2,
                width = 200,
                height = 200
            },
            shift = { 0, 0 },
            size = 2,
            intensity = 0.8,
            color = { r = 1.0, g = 1.0, b = 0.8 },
            source_orientation_offset = 0
        }
    end
    local scale = self:get_scale_factor(footprint_size, rp_art)
    local y_shift = 0
    if light_prototype.picture then
        local height = 0
        if light_prototype.picture.size then
            height = light_prototype.size[2]
        else
            height = light_prototype.picture.height
        end
        y_shift = (height or 0) / (32 * 2)
        y_shift = y_shift
            * (light_prototype.picture.scale or 1)
            * (light_prototype.size or 1)
            * scale
    end

    local all_lights = {}
    for _, group in ipairs(attach_points) do
        for _, offset in ipairs(group.offsets) do
            local light = util.table.deepcopy(light_prototype)
            -- positive y shift moves it backwards
            light.shift = { offset.x, -(offset.z + y_shift) }
            light.size = (light.size or 1) * scale
            table.insert(all_lights, light)
        end
    end
    entity_prototype.light = all_lights
end

function rp_art_util:get_car_reflection(scale)
    return {
        pictures = {
            filename = "__base__/graphics/entity/car/car-reflection.png",
            priority = "extra-high",
            width = 20,
            height = 24,
            shift = util.by_pixel(0, 35),
            variation_count = 1,
            scale = 5 * scale
        },
        rotate = true,
        orientation_to_variation = false
    }
end

function rp_art_util:set_muzzle_positions_for_guns(entity_prototype, rp_art, footprint_size, inputs)
    if entity_prototype.guns then
        local muzzle_attachment_points = self:get_attachment_raw_positions(
            rp_art, footprint_size, rp_art.turret, "muzzle");
        for index, gun_name in ipairs(entity_prototype.guns) do
            local gun = data.raw['gun'][gun_name]
            if not gun then
                error('Could not find gun named "' .. gun_name .. '" referenced by ' ..
                    get_entity_prototype_name(entity_prototype))
            end
            if gun.has_rp_sprites and not inputs.ack_gun_warning then
                error('"' ..
                    gun.name ..
                    '" (gun) has already been used by another prototype. Using it again may have unintended concequences. Set "inputs.ack_gun_warning = true" to ignore this warning.\n'
                    ..
                    'Cars use a secret gun entity for some properties. The same gun should not be shared across multiple entities unless they use identical textures.')
            end

            local gun_attachment_points = muzzle_attachment_points[math.min(index, #muzzle_attachment_points)];
            rp_art_util:set_muzzle_location_for_attack_parameters_using_raw_points(
                gun.attack_parameters, gun_attachment_points, gun.type)

            if settings.startup['rp_art_util_debug_final_output'].value then
                log('Applied "' .. rp_art.name .. '" sprites to "' .. get_entity_prototype_name(gun) .. '\n'
                    .. serpent.block(gun));
            end
        end
    end
end

function rp_art_util:use_sprites_for_car(entity_prototype, rp_art, inputs)
    assert(rp_art.type == 'car' or rp_art.type == 'tank',
        entity_prototype.name .. ' (' .. entity_prototype.type .. ') cannot use "' .. rp_art.type ..
        '" formatted sprites');
    assert(entity_prototype.type == 'car',
        entity_prototype.name .. ' (' .. entity_prototype.type .. ') has an invalid type');

    rp_art_util:use_sprites_for_entity(entity_prototype, rp_art, inputs)

    local footprint_size = inputs.footprint_size or
        rp_art_util:get_bounding_box_footprint_size(entity_prototype.collision_box);

    --entity_prototype.preparing_speed = self:calc_animation_speed(rp_art.preparing, entity_prototype.preparing_speed);
    entity_prototype.animation = self:to_factorio_animation_layers(rp_art.body, {
        layer_description_style = 'stripes',
        footprint_size = footprint_size,
        tint = inputs.tint,
        max_advance = 1.0 / rp_art.body.num_frames,
    });

    -- +1 frames because this is a looping animation and has a missing frame
    local distance_traveled_per_frame = rp_art.body.distance_moved_per_animation_cycle
        / (rp_art.body.num_frames + 1)
    distance_traveled_per_frame = distance_traveled_per_frame * (footprint_size / rp_art.original_footprint_size)
    local animation_speed = distance_traveled_per_frame
    entity_prototype.animation.animation_speed = 1 / animation_speed
    if entity_prototype.animation.hr_version then
        entity_prototype.animation.hr_version.animation_speed = animation_speed
    end

    entity_prototype.light_animation = nil -- TODO, must have same # frames as body animation

    entity_prototype.turret_animation = self:to_factorio_animation_layers(rp_art.turret, {
        layer_description_style = 'stripes',
        footprint_size = footprint_size,
        tint = inputs.tint,
    });

    self:add_tire_tracks_to_car(entity_prototype, rp_art, footprint_size)
    self:add_muffler_smoke_to_car(entity_prototype, rp_art, footprint_size)
    self:add_headlights_to_car(entity_prototype, rp_art, footprint_size)
    self:set_muzzle_positions_for_guns(entity_prototype, rp_art, footprint_size, inputs)

    entity_prototype.water_reflection = self:get_car_reflection(footprint_size / 2) -- vanilla car has rough footprint_size of 2
end

function rp_art_util:use_sprites_for_entity(entity_prototype, rp_art, inputs)
    rp_art_util:use_icon(entity_prototype, rp_art)
    if entity_prototype.minable and entity_prototype.minable.result then
        local item = data.raw['item'][entity_prototype.minable.result];
        if item and item.place_result == entity_prototype.name then
            rp_art_util:use_icon(item, rp_art)
        end
    end
end

--- Uses the rp_art icons on the entity_prototype.
-- @param entity_prototype The factorio entity prototype. All entity types are
--        (somewhat) supported. It uses a higher-res icon for technologies.
-- @param rp_art the art data returned from a `requre(rp_xyz_art)` call
function rp_art_util:use_icon(entity_prototype, rp_art)
    if not entity_prototype then
        error('"entity_prototype" cannot be null')
    end
    assert_is_rp_art_object(rp_art)

    entity_prototype.icon = nil;
    entity_prototype.icon_size = nil;
    entity_prototype.icon_mipmaps = nil;

    if entity_prototype.type == 'technology' then
        entity_prototype.icons = rp_art.technology_icons
    else
        entity_prototype.icons = rp_art.item_icons
        if self.item_subtypes[entity_prototype.type] then
            entity_prototype.pictures = nil
            entity_prototype.dark_background_icons = nil
            entity_prototype.dark_background_icon = nil
            entity_prototype.dark_background_icon_size = nil
            entity_prototype.dark_background_icon_mipmaps = nil
        end
    end
    return entity_prototype;
end

--[[
    Returns true if the table is a standard lua array.
    (starts at 1 and has no nil values)
]]
function rp_art_util:is_array(table)
    if not table then return false; end
    local max = 0
    local count = 0
    for k, v in pairs(table) do
        if type(k) == "number" then
            if k <= 0 then return false; end
            if k > max then max = k; end
            count = count + 1;
        else
            return false;
        end
    end
    return max == count;
end

function rp_art_util:calc_animation_speed(rp_animation, current_speed)
    return current_speed;
    --[[
    if rp_animation.duration_ticks <= 1 then return current_speed end
    if not current_speed then current_speed = 1; end
    if rp_animation.is_stretchable then
       return current_speed;
    end
    return 1.0 / (rp_animation.duration_ticks)
    ]]
end

--[[
    Turret animation speed is defined as: 1 ÷ attacking_speed = duration of the attacking_animation
]]
function rp_art_util:duration_ticks_to_turret_animation_speed(duration_ticks)
    if not duration_ticks or duration_ticks < 1 then
        duration_ticks = 1
    end
    return 1.0 / duration_ticks;
end

--[[
    Turret animation speed is defined as: 1 ÷ attacking_speed = duration of the attacking_animation
]]
function rp_art_util:duration_seconds_to_turret_animation_speed(duration_seconds)
    return self:duration_ticks_to_turret_animation_speed(duration_seconds * 60);
end

function rp_art_util:get_layer_lod_for_footprint(levels_of_detail, footprint_size)
    local best = nil;
    local best_score = nil;
    for _, value in pairs(levels_of_detail) do
        local score = value.footprint_size - footprint_size;
        -- If the LOD is smaller than what we're looking for, penalize it
        if score < 0 then score = score * -2; end
        if not best or score < best_score then
            best = value;
            best_score = score;
        end
    end
    return best;
end

function rp_art_util:to_factorio_animation_layer(rp_animation_layer, inputs)
    if not rp_animation_layer then return nil end
    local scale = inputs.footprint_size / rp_animation_layer.footprint_size;
    local ret = {
        width = rp_animation_layer.width,
        height = rp_animation_layer.height,
        frame_count = inputs.frame_count or rp_animation_layer.frame_count,
        run_mode = inputs.run_mode or 'forward',
        direction_count = rp_animation_layer.direction_count,
        shift = rp_art_util:mul_vector2(rp_animation_layer.shift, scale),
        axially_symmetrical = false,
        scale = scale,
        max_advance = inputs.max_advance,
        --apply_projection = false,
    }

    if rp_animation_layer.render_type == 'shadows' then
        ret.draw_as_shadow = true;
    elseif rp_animation_layer.render_type == 'emission' then
        ret.blend_mode = 'additive';
        ret.draw_as_light = true;
    elseif rp_animation_layer.render_type == 'tint' then
        if inputs.tint then
            ret.tint = inputs.tint
        else
            ret.apply_runtime_tint = true;
        end
        ret.flags = { 'mask' }
    end

    -- Some entity types & properties must use specific filename formats
    -- Ex: Artillery must use 'filename' for the base_picture and 'filenames' for everything else
    -- while other turret types use 'stripes' for most animations
    if inputs.layer_description_style == 'filename' then
        if #rp_animation_layer.filenames ~= 1 then
            error('"filename" format requires exactly one file, found ' .. #rp_animation_layer.filenames)
        end
        ret.filename = rp_animation_layer.filenames[1]
    elseif inputs.layer_description_style == 'filenames' then
        ret.line_length = inputs.frame_count or rp_animation_layer.line_length;
        ret.lines_per_file = rp_animation_layer.lines_per_file;
        ret.filenames = rp_animation_layer.filenames;
    elseif inputs.layer_description_style == 'stripes' then
        ret.stripes = {}
        for index, value in ipairs(rp_animation_layer.filenames) do
            ret.stripes[index] = {
                filename = value,
                width_in_frames = inputs.frame_count or rp_animation_layer.line_length,
                height_in_frames = rp_animation_layer.lines_per_file
            }
        end
    else
        error('"inputs.layer_description_style" must be "filename", "filenames", or "stripes"')
    end

    return ret;
end

function rp_art_util:to_factorio_animation_layers(rp_animation, inputs)
    if not rp_animation then
        return nil
    end
    if not inputs then
        error('"inputs must be set')
    end
    if not inputs.footprint_size then
        error('"inputs.footprint_size must be greater than zero')
    end
    local ret = {}
    for i, layer in ipairs(rp_animation.layers) do
        local normal_lod = rp_art_util:get_layer_lod_for_footprint(layer.levels_of_detail, inputs.footprint_size)
        local high_res_lod = rp_art_util:get_layer_lod_for_footprint(layer.levels_of_detail, inputs.footprint_size * 2)
        local normal = rp_art_util:to_factorio_animation_layer(normal_lod, inputs);
        normal.hr_version = rp_art_util:to_factorio_animation_layer(high_res_lod, inputs);
        table.insert(ret, normal);
    end
    return { layers = ret };
end

--[[
Returns the animation's 'normal' layer shift values, scaled for the appropriate footprint_size.
Some turrets use this to calculate the muzzle offsets
]]
function rp_art_util:get_animation_shift(animation, footprint_size)
    -- Projectile turrets pre-offset the turret axis by the attacking animation's shift
    -- So we need to offset the turret attachment points here by that shift value
    local normal_layer = self:get_matching_value(animation.layers, function(value)
        return value.render_type == 'normal'
    end);
    if normal_layer then
        local lod = rp_art_util:get_layer_lod_for_footprint(normal_layer.levels_of_detail, footprint_size)
        local scale = footprint_size / lod.footprint_size
        return rp_art_util:mul_vector2(lod.shift, scale)
    else
        log('Could not find "normal" layer for ' .. animation.name .. '\'s normal layer')
        return { 0, 0 }
    end
end

--[[
Returns a list of tables, each containing `{axis, offsets, average_offsets, circular_projectile_creation_specification}`.
One table is returned for each attachment point group matching the attach_type.
Most entity types only support a single "muzzle" attachment point group however multiple can be defined. You can assume the first one is the most important one if you need to make a decision.

*  num_directions - the number of rotations in the original animation
*  axis - is the rotation axis ({x,y} table)
*  offsets - the offset of the point from the axis when facing straight up (angle zero). Offsets contains one value for each attach point within the group. ({x,y} table)
*  average_offsets - only has a single value for the entire group. ({x,y} table)
*  circular_projectile_creation_specification - Can be copy-pasted into turrets and other things that use https://wiki.factorio.com/Types/CircularProjectileCreationSpecification
]]
function rp_art_util:get_attachment_pixel_positions(rp_art, footprint_size, animation, attach_type)
    if not rp_art then
        error('"rp_art" must be set')
    end
    if not footprint_size or footprint_size <= 0 then
        error('"footprint_size" must be greater than zero')
    end
    assert(animation and type(animation) == "table",
        '"animation" must be set. It is the lua table containing the animation information from the rp_art. Ex: artillery_turret_1.attacking')
    assert(attach_type,
        '"attach_type" must be set. It is the name of the type of attach point within the animation. Ex: "muzzle" and "muffler"')
    local ret = {};
    -- Find the turret's rotation axis with respect to the muzzle
    -- by taking the average position of the muzzle in all rotations.
    -- The muzzle's 'shift' is likely sightly above the turret's texture shift
    -- because the muzzle often sits above the turret's axis of rotation.
    local scale = footprint_size / (rp_art.original_footprint_size * 32);
    for _, ap_group in ipairs(animation.attachment_points[attach_type] or {}) do
        local point_sum_x = 0;
        local point_sum_y = 0;
        local num_points = 0;

        -- format:  https://wiki.factorio.com/Types/CircularProjectileCreationSpecification
        local circular_projectile_creation_specification = {}
        for _, ap_rot in ipairs(ap_group.rotations) do
            for _, points in ipairs(ap_rot.frames[1].points) do
                local p = points.pixel_position;
                point_sum_x = point_sum_x + p.x
                point_sum_y = point_sum_y + p.y
                num_points = num_points + 1

                circular_projectile_creation_specification[num_points] = {
                    ap_rot.rotation_deg / 360.0,
                    { p.x * scale, -(p.y * scale) }
                }
            end
        end

        local raw_axis = {
            x = (point_sum_x / num_points),
            y = (point_sum_y / num_points),
        }

        local axis = {
            x = raw_axis.x * scale,
            y = raw_axis.y * scale,
        };

        local offsets = {}
        local average_offsets = { x = 0.0, y = 0.0, z = 0.0 }
        for index, points in ipairs(ap_group.rotations[1].frames[1].points) do
            offsets[index] = {
                x = (points.pixel_position.x - raw_axis.x) * scale,
                y = (points.pixel_position.y - raw_axis.y) * scale,
            };
            average_offsets.x = average_offsets.x + offsets[index].x
            average_offsets.y = average_offsets.y + offsets[index].y
        end
        average_offsets.x = average_offsets.x / ap_group.num_points
        average_offsets.y = average_offsets.y / ap_group.num_points

        table.insert(ret, {
            num_directions = animation.num_directions,
            axis = axis,
            offsets = offsets,
            average_offsets = average_offsets,
            circular_projectile_creation_specification = circular_projectile_creation_specification,
        })
    end

    return ret;
end

--[[
Important: Y is UP, not Z

Returns a list of tables, each containing `{axis, offsets, average_offsets, circular_projectile_creation_specification}`.
One table is returned for each attachment point group matching the attach_type.
Most entity types only support a single "muzzle" attachment point group however multiple can be defined. You can assume the first one is the most important one if you need to make a decision.

*  num_directions - the number of rotations in the original animation
*  axis - is the rotation axis ({x,y,z} table)
*  offsets - the offset of the point from the axis when facing straight up (angle zero). Offsets contains one value for each attach point within the group. ({x,y,z} table)
*  average_offsets - only has a single value for the entire group. ({x,y,z} table)
*  circular_projectile_creation_specification - Can be copy-pasted into turrets and other things that use https://wiki.factorio.com/Types/CircularProjectileCreationSpecification
]]
function rp_art_util:get_attachment_raw_positions(rp_art, footprint_size, animation, attach_type)
    if not rp_art then
        error('"rp_art" must be set')
    end
    if not footprint_size or footprint_size <= 0 then
        error('"footprint_size" must be greater than zero')
    end
    assert(animation and type(animation) == "table",
        '"animation" must be set. It is the lua table containing the animation information from the rp_art. Ex: artillery_turret_1.attacking')
    assert(attach_type,
        '"attach_type" must be set. It is the name of the type of attach point within the animation. Ex: "muzzle" and "muffler"')
    local animation_shift = self:get_animation_shift(animation, footprint_size)
    local ret = {};

    -- Find the turret's rotation axis with respect to the muzzle
    -- by taking the average position of the muzzle in all rotations.
    -- The muzzle's 'shift' is likely sightly above the turret's texture shift
    -- because the muzzle often sits above the turret's axis of rotation.
    local scale = self:get_scale_factor(footprint_size, rp_art)
    for _, ap_group in ipairs(animation.attachment_points[attach_type] or {}) do
        local point_sum_x = 0;
        local point_sum_y = 0;
        local point_sum_z = 0;
        local num_points = 0;

        -- format:  https://wiki.factorio.com/Types/CircularProjectileCreationSpecification
        local circular_projectile_creation_specification = {}
        for _, ap_rot in ipairs(ap_group.rotations) do
            for _, points in ipairs(ap_rot.frames[1].points) do
                local p = points.raw_position;
                point_sum_x = point_sum_x + p.x
                point_sum_y = point_sum_y + p.y
                point_sum_z = point_sum_z + p.z
                num_points = num_points + 1

                circular_projectile_creation_specification[num_points] = {
                    ap_rot.rotation_deg / 360.0,
                    { p.x * scale, p.y * scale, p.z * scale }
                }
            end
        end

        local raw_axis = {
            x = (point_sum_x / num_points),
            y = (point_sum_y / num_points),
            z = (point_sum_z / num_points),
        }

        local axis = {
            x = raw_axis.x * scale,
            y = raw_axis.y * scale,
            z = raw_axis.z * scale,
        };

        local offsets = {}
        local average_offsets = { x = 0.0, y = 0.0, z = 0.0 }
        for index, points in ipairs(ap_group.rotations[1].frames[1].points) do
            local p = points.raw_position;
            offsets[index] = {
                x = p.x * scale,
                y = p.y * scale,
                z = p.z * scale,
            };
            average_offsets.x = average_offsets.x + offsets[index].x
            average_offsets.y = average_offsets.y + offsets[index].y
            average_offsets.z = average_offsets.z + offsets[index].z
        end
        average_offsets.x = average_offsets.x / ap_group.num_points
        average_offsets.y = average_offsets.y / ap_group.num_points
        average_offsets.z = average_offsets.z / ap_group.num_points

        table.insert(ret, {
            num_directions = animation.num_directions,
            axis = axis,
            offsets = offsets,
            average_offsets = average_offsets,
            circular_projectile_creation_specification = circular_projectile_creation_specification,
            animation_shift = { animation_shift[1], animation_shift[2] }
        })
    end

    return ret;
end

---Returns an AnimatedVector for the given attach point group and point within it
function rp_art_util:get_attachment_points_as_animated_vector(
    rp_art, footprint_size, animation, attach_type, attach_group_index, attach_point_index)
    --https://wiki.factorio.com/Types/AnimatedVector
    if not rp_art then
        error('"rp_art" must be set')
    end
    if not footprint_size or footprint_size <= 0 then
        error('"footprint_size" must be greater than zero')
    end
    assert(animation and type(animation) == "table",
        '"animation" must be set. It is the lua table containing the animation information from the rp_art. Ex: artillery_turret_1.attacking')
    assert(attach_type,
        '"attach_type" must be set. It is the name of the type of attach point within the animation. Ex: "muzzle" and "muffler"')

    attach_group_index = attach_group_index or 1
    attach_point_index = attach_point_index or 1


    local scale = self:get_scale_factor(footprint_size, rp_art)
    local ap_group = (animation.attachment_points[attach_type] or {})[attach_group_index]
    if not ap_group or attach_point_index > ap_group.num_points then
        return nil
    end

    local ret = {};
    for rot_index, ap_rot in ipairs(ap_group.rotations) do
        local animated_vector = {}
        ret[rot_index] = { frames = animated_vector }
        for frame_index, frame in ipairs(ap_rot.frames) do
            local p = frame.points[attach_point_index].raw_position
            animated_vector[frame_index] = rp_art_util:p3d_to_ortho_v2d(p.x * scale, p.y * scale, p.z * scale)
            -- These are 'shifts' so 'y' is negative
            animated_vector[frame_index][2] = -animated_vector[frame_index][2]
        end
    end

    return { rotations = ret };
end

function rp_art_util:get_reversed_animated_vector(vector)
    if not vector then
        return nil
    end
    local ret = {
        rotations = {},
        render_layer = vector.render_layer,
        direction_shift = vector.direction_shift,
    }
    for rot_index, rot in ipairs(vector.rotations) do
        local ret_frames = {}
        ret.rotations[rot_index] = {
            frames = ret_frames,
            render_layer = rot.render_layer
        }
        for frame_index = 1, #rot.frames, 1 do
            ret_frames[frame_index] = rot.frames[#rot.frames - frame_index + 1]
        end
    end
    return ret;
end

function rp_art_util:get_truncated_animated_vector(vector, length)
    if not vector then
        return nil
    end
    local ret = {
        rotations = {},
        render_layer = vector.render_layer,
        direction_shift = vector.direction_shift,
    }
    for rot_index, rot in ipairs(vector.rotations) do
        local ret_frames = {}
        ret.rotations[rot_index] = {
            frames = ret_frames,
            render_layer = rot.render_layer
        }
        for frame_index = 1, math.min(length, #rot.frames), 1 do
            ret_frames[frame_index] = rot.frames[frame_index]
        end
    end
    return ret;
end

--[[
    Updates the provided attack parameter's muzzle to match the animation's muzzle
]]
function rp_art_util:set_muzzle_location_for_attack_parameters(attack_parameters, rp_art, footprint_size, entity_type)
    local turret = rp_art_util:get_attachment_pixel_positions(rp_art, footprint_size, rp_art.attacking, 'muzzle')[1]
    if attack_parameters.type == 'projectile' then
        if entity_type == 'artillery-turret' then
            -- artillery turrets don't take the attacking animation 'shift' value into account when calculating the turret's rotation axis
            -- Other types do for some reason
            attack_parameters.projectile_center = {
                turret.axis.x,
                -turret.axis.y,
            };
            attack_parameters.projectile_creation_distance = turret.average_offsets.y;
            attack_parameters.projectile_creation_parameters = turret.circular_projectile_creation_specification;
        else
            -- Projectile turrets pre-offset the turret axis by the attacking animation's shift
            -- So we need to offset the turret attachment points here by that shift value
            local turret_animation_shift = { 0, 0 }
            local normal_layer = rp_art_util:get_matching_value(rp_art.attacking.layers, function(value)
                return value.render_type == 'normal'
            end);
            if normal_layer then
                local lod = rp_art_util:get_layer_lod_for_footprint(normal_layer.levels_of_detail, footprint_size)
                local scale = footprint_size / lod.footprint_size
                turret_animation_shift = rp_art_util:mul_vector2(lod.shift, scale)
            else
                log('Could not find "normal" layer for ' .. rp_art.name .. '\'s attacking animation')
            end

            -- These are treated as offsets, which means factorio *subtracts* the y axis
            -- It also takes these with respect to the animation shifts found above
            -- But the animation shifts are also subtracted, which means we actually want to add them
            -- when working with the calculated turret axis (which use positive units).
            -- This is a mess and I can't believe I reverse engineered this in my free time
            attack_parameters.projectile_center = {
                turret.axis.x + turret_animation_shift[1],
                -- Positive Y values are down for some reason, so flip it
                -(turret.axis.y + turret_animation_shift[2]),
            };

            attack_parameters.projectile_creation_distance = turret.average_offsets.y;
            attack_parameters.projectile_creation_parameters = turret.circular_projectile_creation_specification;
        end

        --[[
        local debug = {
            average_offsets = turret.average_offsets,
            axis = turret.axis,
            projectile_center = attack_parameters.projectile_center,
            projectile_creation_distance = attack_parameters.projectile_creation_distance,
            projectile_creation_parameters = attack_parameters.projectile_creation_parameters,
        };
        log(rp_art.name .. '\'s turret values = ' .. serpent.block(debug))
        ]]
    elseif attack_parameters.type == 'beam' then
        attack_parameters.source_direction_count = rp_art.attacking.num_directions;
        if attack_parameters.ammo_type
            and attack_parameters.ammo_type.action
            and attack_parameters.ammo_type.action.action_delivery then
            -- This appears to be the axis the turret (muzzle) spins on
            -- For some reason 'offset' variables are negated internally, so we
            -- need to negate them again for them to make sense
            attack_parameters.ammo_type.action.action_delivery.source_offset = {
                turret.axis.x,
                -turret.axis.y,
            };
        end
        -- This appears to be the offset from the turret axis to the muzzle
        attack_parameters.source_offset = {
            turret.average_offsets.x,
            -turret.average_offsets.y,
        };
    elseif attack_parameters.type == 'stream' then
        attack_parameters.gun_center_shift = {
            turret.axis.x,
            -turret.axis.y,
        };
        attack_parameters.gun_barrel_length = turret.average_offsets.y;
        if attack_parameters.ammo_type
            and attack_parameters.ammo_type.action
            and attack_parameters.ammo_type.action.action_delivery then
            attack_parameters.ammo_type.action.action_delivery.source_offset = {
                0, 0
            };
        end
    else
        error('Unrecognized attack parameter type "' .. attack_parameters.type .. '"');
    end

    if settings.startup['rp_art_util_debug_muzzle'].value then
        log('Calculated muzzle for attack parameters ' .. serpent.block(attack_parameters));
    end
end

--[[
    Updates the provided attack parameter's muzzle to match the animation's muzzle
]]
function rp_art_util:set_muzzle_location_for_attack_parameters_using_raw_points(attack_parameters, attachment_points,
                                                                                entity_type)
    if attack_parameters.type == 'projectile' then
        if #attachment_points.offsets > 1 then
            local axis2d = self:p3d_to_ortho_p2d(
                attachment_points.axis.x, attachment_points.axis.y, attachment_points.axis.z)
            -- this seems totally ignored
            attack_parameters.projectile_center = {
                axis2d.x,
                -axis2d.y,
            };
            attack_parameters.projectile_creation_distance = self:p3d_distance(
                attachment_points.average_offsets,
                attachment_points.axis);
            attack_parameters.projectile_orientation_offset = 0 -- rotates the location the projectile shoots from wrt to the turret
            attack_parameters.projectile_creation_parameters = {}
            for index, value in ipairs(attachment_points.circular_projectile_creation_specification) do
                local point2d = self:p3d_to_ortho_p2d(value[2][1], value[2][2], value[2][3])
                attack_parameters.projectile_creation_parameters[index] = {
                    value[1],
                    -- attachment points are in xyz format, convert to xz offset (-up/down axis)
                    {
                        point2d.x,
                        -point2d.y
                    },
                }
            end
        else
            local axis2d = self:p3d_to_ortho_p2d(
                attachment_points.axis.x, attachment_points.axis.y, attachment_points.axis.z)
            if entity_type == 'artillery-turret' then
                attack_parameters.projectile_center = {
                    (axis2d.x),
                    -(axis2d.y),
                };
            else
                attack_parameters.projectile_center = {
                    (axis2d.x - attachment_points.animation_shift[1]),
                    -(axis2d.y + attachment_points.animation_shift[2]),
                };
            end
            local muzzle_offset_from_axis = self:p3d_sub(
                attachment_points.offsets[1],
                attachment_points.axis)
            attack_parameters.projectile_creation_distance = self:p3d_length(muzzle_offset_from_axis);
            attack_parameters.projectile_orientation_offset =
                -(math.atan(muzzle_offset_from_axis.z, muzzle_offset_from_axis.x) / (math.pi * 2) - 0.25)
        end
    elseif attack_parameters.type == 'beam' then
        attack_parameters.source_direction_count = attachment_points.num_directions;
        if attack_parameters.ammo_type
            and attack_parameters.ammo_type.action
            and attack_parameters.ammo_type.action.action_delivery then
            -- This appears to be the axis the turret (muzzle) spins on
            -- For some reason 'offset' variables are negated internally, so we
            -- need to negate them again for them to make sense
            local point2d = self:p3d_to_ortho_p2d(attachment_points.axis.x, attachment_points.axis.y,
                attachment_points.axis.z)
            attack_parameters.ammo_type.action.action_delivery.source_offset = {
                point2d.x,
                -point2d.y,
            };
        end
        -- This appears to be the offset from the turret axis to the muzzle
        attack_parameters.source_offset = {
            attachment_points.average_offsets.x - attachment_points.axis.x,
            -attachment_points.average_offsets.z - attachment_points.axis.z,
        };
    elseif attack_parameters.type == 'stream' then
        attack_parameters.gun_center_shift = {
            attachment_points.axis.x,
            -attachment_points.axis.z,
        };
        attack_parameters.gun_barrel_length = attachment_points.average_offsets.z - attachment_points.axis.z;
        if attack_parameters.ammo_type
            and attack_parameters.ammo_type.action
            and attack_parameters.ammo_type.action.action_delivery then
            attack_parameters.ammo_type.action.action_delivery.source_offset = {
                0, 0
            };
        end
        attack_parameters.projectile_creation_parameters = {}
        for index, value in ipairs(attachment_points.circular_projectile_creation_specification) do
            attack_parameters.projectile_creation_parameters[index] = {
                value[1],
                -- attachment points are in xyz format, convert to xz offset (-up/down axis)
                self:p2d_to_offset(self:p3d_to_ortho_p2d(value[2][1], value[2][2], value[2][3]))
            }
        end
    else
        error('Unrecognized attack parameter type "' .. attack_parameters.type .. '"');
    end

    if settings.startup['rp_art_util_debug_muzzle'].value then
        log('Calculated muzzle for attack parameters ' .. serpent.block(attack_parameters));
    end
end

--[[
    Updates the provided attack parameter's muzzle to match the animation's muzzle
]]
function rp_art_util:set_muzzle_location_for_action_delivery(action_delivery, rp_art, footprint_size)
    local turret = rp_art_util:get_attachment_pixel_positions(rp_art, footprint_size, rp_art.attacking, 'muzzle')[1]
    if action_delivery.type == 'instant' then
        -- TODO
    elseif action_delivery.type == 'projectile' then
        -- TODO
    elseif action_delivery.type == 'flame-thrower' then
        -- TODO
    elseif action_delivery.type == 'beam' then
        action_delivery.source_direction_count = rp_art.attacking.num_directions;
        -- This appears to be the axis the turret (muzzle) spins on
        -- For some reason 'offset' variables are negated internally, so we
        -- need to negate them again for them to make sense
        action_delivery.source_offset = {
            turret.axis.x,
            -turret.axis.y,
        };
    elseif action_delivery.type == 'stream' then
        -- TODO Set projectile launch point
    elseif action_delivery.type == 'artillery' then
        -- TODO
    else
        error('Unrecognized action_delivery type "' .. action_delivery.type .. '"');
    end

    if settings.startup['rp_art_util_debug_muzzle'].value then
        log('Calculated muzzle for action delivery ' .. serpent.block(action_delivery));
    end
end

function rp_art_util:mul_vector2(vector, value)
    if not vector then
        return { 0, 0 };
    end
    return { vector[1] * value, vector[2] * value };
end

function rp_art_util:scale_animation(animation, scale_factor)
    if not animation or scale_factor == 1 then return; end
    if not scale_factor then
        error('"scale_factor" cannot be null');
    end
    if animation.layers then
        for _, value in pairs(animation.layers) do
            rp_art_util:scale_animation(value, scale_factor);
        end
    elseif animation.sheet then
        rp_art_util:scale_animation(animation.sheet, scale_factor);
    elseif animation.sheets then
        rp_art_util:scale_animation(animation.sheets, scale_factor);
    elseif animation.filename or animation.filenames or animation.stripes then
        animation.scale = (animation.scale or 1) * scale_factor;
        animation.shift = rp_art_util:mul_vector2(animation.shift, scale_factor);
        if animation.hr_version then
            rp_art_util:scale_animation(animation.hr_version, scale_factor);
        end
    elseif rp_art_util:is_array(animation) then
        -- Beams use a basic array instead of the 'layers' property for some reason
        -- This could also happen if this was called on the 'layers' property directly
        for key, value in pairs(animation) do
            rp_art_util:scale_animation(value, scale_factor)
        end
    else
        error('Unrecognized animation type\n' .. serpent.block(animation));
    end
end

function rp_art_util:scale_entity_prototype(entity_prototype, scale_factor)
    if not entity_prototype then
        error('"entity_prototype" cannot be null')
    end
    if not scale_factor then
        error('"scale_factor" cannot be null')
    end
    if scale_factor == 1 then return; end
    --[[
    log('Scaling "' ..
        entity_prototype.name .. '" ('..entity_prototype.type..') sprites by ' .. scale_factor .. '\n'
        .. serpent.block(entity_prototype));
        ]]
    if entity_prototype.type == 'beam' then
        rp_art_util:scale_animation(entity_prototype.body, scale_factor);
        rp_art_util:scale_animation(entity_prototype.head, scale_factor);
        rp_art_util:scale_animation(entity_prototype.tail, scale_factor);
        rp_art_util:scale_animation(entity_prototype.body_light, scale_factor);
        rp_art_util:scale_animation(entity_prototype.ending, scale_factor);
        rp_art_util:scale_animation(entity_prototype.ending_light, scale_factor);
        if entity_prototype.ground_light_animations then
            rp_art_util:scale_animation(entity_prototype.ground_light_animations.start, scale_factor);
            rp_art_util:scale_animation(entity_prototype.ground_light_animations.ending, scale_factor);
            rp_art_util:scale_animation(entity_prototype.ground_light_animations.head, scale_factor);
            rp_art_util:scale_animation(entity_prototype.ground_light_animations.tail, scale_factor);
            rp_art_util:scale_animation(entity_prototype.ground_light_animations.body, scale_factor);
        end
        if entity_prototype.light_animations then
            rp_art_util:scale_animation(entity_prototype.light_animations.start, scale_factor);
            rp_art_util:scale_animation(entity_prototype.light_animations.ending, scale_factor);
            rp_art_util:scale_animation(entity_prototype.light_animations.head, scale_factor);
            rp_art_util:scale_animation(entity_prototype.light_animations.tail, scale_factor);
            rp_art_util:scale_animation(entity_prototype.light_animations.body, scale_factor);
        end
        rp_art_util:scale_animation(entity_prototype.start, scale_factor);
        rp_art_util:scale_animation(entity_prototype.start_light, scale_factor);
        rp_art_util:scale_animation(entity_prototype.tail_light, scale_factor);
        entity_prototype.target_offset = rp_art_util:mul_vector2(entity_prototype.target_offset, scale_factor);
    end
    --[[
    log('Scaled "' ..
        entity_prototype.name .. '" (' .. entity_prototype.type .. ') sprites by ' .. scale_factor .. '\n'
        .. serpent.block(entity_prototype));
        ]]
end

function rp_art_util:get_bounding_box_footprint_size(bb)
    if not bb then return 1 end
    return math.ceil(math.abs(bb[2][1] - bb[1][1]))
end

function rp_art_util:get_matching_value(t, predicate)
    for key, value in pairs(t) do
        if predicate(value) then
            return value
        end
    end
    return nil
end

return rp_art_util;
