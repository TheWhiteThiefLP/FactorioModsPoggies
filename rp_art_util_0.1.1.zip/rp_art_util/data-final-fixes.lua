local util = require('util')

if settings.startup['rp_art_util_debug_particle_positions'].value then
    local target = {
        filename = '__core__/graphics/cross-select-x32.png',
        size = 32,
        scale = 1,
        draw_as_glow = true,
    }

    local function create_target_animation_variations(original_animation)
        if not original_animation then
            return nil
        end

        local main_layer = original_animation[1] or original_animation
        local layer = util.table.deepcopy(target)
        local ret = { layer }
        table.insert(ret, layer)

        layer.animation_speed = main_layer.animation_speed
        local size = math.max(main_layer.width or main_layer.size or 32, main_layer.height or main_layer.size or 32)
        layer.scale = (size * (main_layer.scale or 1)) / (layer.size * 2)
        if main_layer.tint then
            layer.tint = util.table.deepcopy(main_layer.tint)
            layer.tint.a = nil
        end
        if main_layer.flags then
            layer.flags = util.table.deepcopy(main_layer.flags)
        end
        if main_layer.frame_count then
            layer.frame_sequence = {}
            for index = 1, main_layer.frame_count, 1 do
                layer.frame_sequence[index] = 1
            end
        end

        return ret;
    end

    local function create_target_animation(original_animation)
        local ret = util.table.deepcopy(target)
        original_animation = original_animation or {}
        ret.animation_speed = 1
        local size = math.max(original_animation.width or original_animation.size or 32,
            original_animation.height or original_animation.size or 32)
        ret.scale = (size * (original_animation.scale or 1)) / (ret.size * 2)
        if original_animation.tint then
            ret.tint = util.table.deepcopy(original_animation.tint)
            ret.tint.a = nil
        end
        if original_animation.flags then
            ret.flags = util.table.deepcopy(original_animation.flags)
        end
        if original_animation.frame_count then
            ret.frame_sequence = {}
            for index = 1, original_animation.frame_count, 1 do
                ret.frame_sequence[index] = 1
            end
        end

        return ret;
    end

    for _, entity_prototype in pairs(data.raw['trivial-smoke'] or {}) do
        entity_prototype.animation = create_target_animation(entity_prototype.animation)
        entity_prototype.fade_in_duration = 0
        entity_prototype.fade_away_duration = 0
    end

    for _, entity_prototype in pairs(data.raw['optimized-particle'] or {}) do
        --local original_animation = entity_prototype.pictures
        entity_prototype.pictures = create_target_animation_variations(entity_prototype.pictures)
        entity_prototype.shadows = nil
    end

    for _, entity_prototype in pairs(data.raw['explosion'] or {}) do
        entity_prototype.animations = create_target_animation_variations(entity_prototype.animations)
    end
end

if settings.startup['rp_art_util_debug_add_clock_sprites'].value then
    local function find_layer_matching(layers, condition)
        for index, layer in ipairs(layers or {}) do
            if condition(layer) then
                return layer
            end
        end
        return nil
    end

    local function find_main_layer(layers)
        return find_layer_matching(layers, function(layer)
            return not (layer.draw_as_glow
                or layer.draw_as_shadow
                or layer.draw_as_light
                or layer.apply_runtime_tint)
        end)
    end

    local function get_layer_size(layer)
        if layer.size then
            if type(layer.size) == 'table' then
                return layer.size
            end
            return { layer.size, layer.size }
        end
        return { layer.width, layer.height }
    end

    local function add_debug_clock_to_layers(entity_prototype, animation_property, tint, include_shift)
        assert(entity_prototype, '"entity_prototype" cannot be null')
        assert(animation_property, '"animation_property" cannot be null')
        local layers = entity_prototype[animation_property]
        if not layers then
            log(entity_prototype.name ..
                '(' .. entity_prototype.type .. ') does not have field named "' .. animation_property .. '"')
            return
        end
        if layers.north then
            log('TODO: ' .. entity_prototype.name ..
                '(' .. entity_prototype.type .. ') is not supported')
            return
        elseif layers.layers then
            layers = layers.layers
        else
            layers = { layers }
            entity_prototype[animation_property] = {
                layers = layers
            }
        end
        local main_layer = find_main_layer(layers)
        if not main_layer then
            log(entity_prototype.name ..
                '(' .. entity_prototype.type .. ').' .. animation_property .. ' does not have a main layer')
            return
        end
        local size = get_layer_size(main_layer)
        local scale = main_layer.scale or 1
        local real_size = (math.max(size[1] or 1, size[2] or 1) * scale) / 32
        local frame_sequence = {}
        for i = 1, (main_layer.frame_count or 1), 1 do
            frame_sequence[i] = 1
        end
        local my_size = 128
        local shift = nil
        if include_shift and main_layer.shift then
            shift = util.table.deepcopy(main_layer.shift)
        end
        table.insert(layers, {
            filename = '__rp_art_util__/clock.png',
            size = my_size,
            scale = real_size * (32 / my_size),
            shift = shift,
            direction_count = 64,
            line_length = 8,
            frame_count = 1,
            frame_sequence = frame_sequence,
            max_advance = main_layer.max_advance,
            tint = tint,
            draw_as_glow = true,
        })

        log(entity_prototype.name ..
            '(' .. entity_prototype.type .. ').' .. animation_property .. ' = ' .. serpent.block(layers))
        return
    end

    local tint_white = { 1, 1, 1, 1 }
    local tint_red = { 1, 0, 0, 1 }
    local tint_green = { 0, 1, 0, 1 }
    local tint_blue = { 0, 0, 1, 1 }

    for _, entity_prototype in pairs(data.raw['car'] or {}) do
        log('Adding debug clock to ' .. entity_prototype.name .. '(' .. entity_prototype.type .. ')')
        add_debug_clock_to_layers(entity_prototype, 'animation', tint_white, true)
        add_debug_clock_to_layers(entity_prototype, 'turret_animation', tint_blue, false)
        add_debug_clock_to_layers(entity_prototype, 'turret_animation', tint_red, true)
    end

    for _, entity_type in ipairs({ 'turret', 'ammo-turret', 'electric-trurret', 'fluid-turret' }) do
        for _, entity_prototype in pairs(data.raw[entity_type] or {}) do
            log('Adding debug clock to ' .. entity_prototype.name .. '(' .. entity_prototype.type .. ')')
            add_debug_clock_to_layers(entity_prototype, 'attacking_animation', tint_blue, false)
            add_debug_clock_to_layers(entity_prototype, 'attacking_animation', tint_red, true)
        end
    end
end
