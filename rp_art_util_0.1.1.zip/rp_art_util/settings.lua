data:extend({
    {
        type = "string-setting",
        name = "rp_art_util_turret_tint_mode",
        order = "a",
        setting_type = "startup",
        allowed_values = { "player_color", "icon_color" },
        default_value = "player_color",
    },
    {
        type = "bool-setting",
        name = "rp_art_util_debug_final_output",
        order = "z",
        setting_type = "startup",
        default_value = false,
    }, {
        type = "bool-setting",
        name = "rp_art_util_debug_muzzle",
        order = "z",
        setting_type = "startup",
        default_value = false,
    },
    {
        type = "bool-setting",
        name = "rp_art_util_debug_particle_positions",
        order = "z",
        setting_type = "startup",
        default_value = false,
    },
    {
        type = "bool-setting",
        name = "rp_art_util_debug_add_clock_sprites",
        order = "z",
        setting_type = "startup",
        default_value = false,
    },
})
