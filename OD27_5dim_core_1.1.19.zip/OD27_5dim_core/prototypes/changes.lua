if settings.startup["5d-stack-artillery-bullets"].value then
    data.raw.ammo["artillery-shell"].stack_size = 5
end