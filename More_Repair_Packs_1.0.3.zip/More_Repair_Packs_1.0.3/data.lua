-- require("")

require("prototypes/items/copper-repair-pack")
require("prototypes/recipes/copper-repair-recipe")


require("prototypes/technologys/steel-repair-tech")

require("prototypes/items/steel-repair-pack")
require("prototypes/recipes/steel-repair-recipe")


require("prototypes/technologys/field-repair-tech")

require("prototypes/items/field-repair-pack")
require("prototypes/recipes/field-repair-recipe")


require("prototypes/technologys/multitool-repair-tech")

require("prototypes/items/multitool-repair-pack")
require("prototypes/recipes/multitool-repair-recipe")