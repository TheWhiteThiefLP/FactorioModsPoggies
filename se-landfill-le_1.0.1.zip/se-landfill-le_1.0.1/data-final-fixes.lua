
local data_util = require( "__space-exploration__.data_util" )

local function landfill_recipe( name, count )
  data:extend({
    {
      type = "recipe",
      name = "landfill-" .. name,
      energy_required = 1,
      enabled = false,
      category = "hard-recycling",
      icons = {
        { icon = data.raw.item.landfill.icon, icon_size = data.raw.item.landfill.icon_size },
        { icon = data.raw.item[ name ].icon, icon_size = data.raw.item[ name ].icon_size, scale = 0.33*64 / data.raw.item[ name ].icon_size }
      },
      ingredients =
      {
        { name, count }
      },
      result = "landfill",
      result_count = 1,
      order = "z-b-" .. name,
      allow_decomposition = false,
    }
  })
  data_util.tech_lock_recipes( "se-recycling-facility", { "landfill-" .. name } )
end

landfill_recipe( "coal", 50 )
landfill_recipe( "uranium-ore", 50 )
landfill_recipe( "se-cryonite", 50 )
landfill_recipe( "se-vitamelange", 50 )
landfill_recipe( "se-vulcanite", 50 )

local recycling = data.raw.technology[ "se-recycling-facility" ]
if recycling and settings.startup[ "selle-shift" ].value then
  for _, effect in pairs( recycling.effects ) do
    if effect.type == "unlock-recipe" then
      local recipe = data.raw.recipe[ effect.recipe ]
      if recipe and string.sub( recipe.name, 1, 9 ) == "landfill-" and recipe.icons and recipe.icons[ 2 ] then
        recipe.icons[ 2 ].shift = { x = 8, y = -8 }
      end
    end
  end
end
