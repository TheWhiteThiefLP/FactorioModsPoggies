
data:extend( {
  {
    type = "bool-setting",
    name = "selle-shift",
    setting_type = "startup",
    default_value = false,
    order = "a1"
  }
} )
