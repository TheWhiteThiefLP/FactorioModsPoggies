-- step 1
Event = {addListener = function() end}

-- step 2
local Zonelist = require('__space-exploration__.scripts.zonelist')

-- step 3
Event = nil

-- step 4
return Zonelist
