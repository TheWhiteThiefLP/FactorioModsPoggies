data:extend({--  Recipes

  {--  Straight Space Pipe Recipe
    type="recipe",
    name="space-pipe-straight",
    enabled=false,
    energy_required=0.05,
    ingredients={{"se-space-pipe",1}},
    result="space-pipe-straight"
  },

  {--  T-Junction Space Pipe Recipe
    type="recipe",
    name="space-pipe-t-junction",
    enabled=false,
    energy_required=0.05,
    ingredients={{"se-space-pipe",1}},
    result="space-pipe-t-junction"
  },
  
  {--  Elbow Space Pipe Recipe
    type="recipe",
    name="space-pipe-elbow",
    enabled=false,
    energy_required=0.05,
    ingredients={{"se-space-pipe",1}},
    result="space-pipe-elbow"
  },
    
})
