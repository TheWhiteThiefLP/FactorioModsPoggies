data:extend({--  Mod Settings

    {--  Should Arrows On Pipe Junctions Be Disabled?
        name="se-flow-bridge-is-pipe-arrows-disabled",
        type="bool-setting",
        setting_type="startup",
        default_value=true
    }

})