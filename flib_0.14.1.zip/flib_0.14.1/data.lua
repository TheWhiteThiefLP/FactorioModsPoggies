require("prototypes.sprite")
require("prototypes.style")
require("prototypes.technology-slot-style")
