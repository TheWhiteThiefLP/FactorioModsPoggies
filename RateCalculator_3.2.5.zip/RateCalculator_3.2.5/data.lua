require("prototypes.custom-input")
require("prototypes.item")
require("prototypes.shortcut")
require("prototypes.sprite")
require("prototypes.style")

-- require("prototypes.debug")
