AAILoaders.make_tier{ -- Advanced loader
  name = "kr-advanced",
  transport_belt = "kr-advanced-transport-belt",
  color = {34, 236, 23},
  fluid = "lubricant",
  fluid_per_minute = "0.225",
  technology = {
    prerequisites = { "kr-logistic-4", },
    unit = {
      count = 350,
      ingredients = {
        { "automation-science-pack", 1 },
        { "logistic-science-pack", 1 },
        { "chemical-science-pack", 1 },
        { "production-science-pack", 1 },
        { "utility-science-pack", 1 }
      },
      time = 60
    }
  },
  recipe = {
    ingredients = {
      {"kr-advanced-transport-belt", 1},
      {"aai-express-loader", 1},
      {"rare-metals", 5},
      {"steel-gear-wheel", 5},
    },
    energy_required = 2
  },
  unlubricated_recipe = {
    ingredients = {
      {"kr-advanced-transport-belt", 1},
      {"aai-express-loader", 1},
      {"rare-metals", 50},
      {"steel-gear-wheel", 50},
    },
    energy_required = 10
  }
}

AAILoaders.make_tier{ -- Superior loader
  name = "kr-superior",
  transport_belt = "kr-superior-transport-belt",
  color = {210, 1, 247},
  fluid = "lubricant",
  fluid_per_minute = "0.25",
  technology = {
    prerequisites = { "kr-logistic-5", },
    unit = {
      count = 450,
      ingredients = {
        { "production-science-pack", 1 },
        { "utility-science-pack", 1 },
        { "advanced-tech-card", 1 }
      },
      time = 60
    }
  },
  recipe = {
    ingredients = {
      {"kr-superior-transport-belt", 1},
      {"aai-kr-advanced-loader", 1},
      {"imersium-gear-wheel", 5},
      {"imersium-plate", 5},
    },
    energy_required = 2
  },
  unlubricated_recipe = {
    ingredients = {
      {"kr-superior-transport-belt", 1},
      {"aai-kr-advanced-loader", 1},
      {"imersium-gear-wheel", 50},
      {"imersium-plate", 50},
    },
    energy_required = 10
  }
}
