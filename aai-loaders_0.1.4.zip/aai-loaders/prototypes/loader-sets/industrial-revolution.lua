AAILoaders.make_tier{
  name = "", -- empty name will create "aai-loader"
  transport_belt = "transport-belt",
  color = {255, 217, 85},
  fluid = "lubricant",
  fluid_per_minute = "0.1",
  fluid_technology_prerequisites = {"lubricant"},
  technology = {
    prerequisites = {"logistics"},
    unit = {
      count = 30,
      ingredients = {
        {"automation-science-pack", 1},
        {"logistic-science-pack", 1}
      },
      time = 15
    }
  },
  recipe = {
    ingredients = {
      {"transport-belt", 1},
      {"tin-gear-wheel", 4},
      {"iron-motor", 2}
    },
    energy_required = 2
  },
  unlubricated_recipe = {
    ingredients = {
      {"transport-belt", 1},
      {"tin-gear-wheel", 40},
      {"iron-motor", 20}
    },
    energy_required = 10
  },
  upgrade = "aai-fast-loader", -- not yet defined
  localise = false -- we have baked in localisation, if you don't you might want to set this to true.
}

AAILoaders.make_tier{
  name = "fast",
  transport_belt = "fast-transport-belt",
  color = {255, 24, 38},
  fluid = "lubricant",
  fluid_per_minute = "0.15",
  technology = {
    prerequisites = {"logistics-2", "aai-loader"},
    unit = {
      count = 250,
      ingredients = {
        {"automation-science-pack", 1},
        {"logistic-science-pack", 1},
        {"chemical-science-pack", 1}
      },
      time = 30
    }
  },
  recipe = {
    ingredients = {
      {"fast-transport-belt", 1},
      {"electronic-circuit", 4},
      {"iron-gear-wheel", 4},
      {"electric-engine-unit", 2}
    },
    energy_required = 2
  },
  unlubricated_recipe = {
    ingredients = {
      {"fast-transport-belt", 1},
      {"electronic-circuit", 40},
      {"iron-gear-wheel", 40},
      {"electric-engine-unit", 20}
    },
    energy_required = 10
  },
  upgrade = "aai-express-loader"
}

AAILoaders.make_tier{
  name = "express",
  transport_belt = "express-transport-belt",
  color = {90, 190, 255},
  fluid = "lubricant",
  fluid_per_minute = "0.2",
  technology = {
    prerequisites = {"logistics-3", "aai-fast-loader"},
    unit = {
      count = 350,
      ingredients = {
        {"automation-science-pack", 1},
        {"logistic-science-pack", 1},
        {"chemical-science-pack", 1},
        {"production-science-pack", 1}
      },
      time = 15
    }
  },
  recipe = {
    crafting_category = "crafting-with-fluid",
    ingredients = {
      {"express-transport-belt", 1},
      {"electric-engine-unit", 4},
      {"steel-gear-wheel", 4},
      {"advanced-circuit", 2}
    },
    energy_required = 2
  },
  unlubricated_recipe = {
    crafting_category = "crafting-with-fluid",
    ingredients = {
      {"express-transport-belt", 1},
      {"electric-engine-unit", 40},
      {"steel-gear-wheel", 40},
      {"advanced-circuit", 20}
    },
    energy_required = 10
  }
}

if data.raw.technology["aai-loader"] then data.raw.technology["aai-loader"].IR_native = true end
if data.raw.technology["aai-fast-loader"] then data.raw.technology["aai-fast-loader"].IR_native = true end
if data.raw.technology["aai-express-loader"] then data.raw.technology["aai-express-loader"].IR_native = true end
