---@diagnostic disable: redundant-parameter
local sprite_shift = {0, -0.15} -- {0.15625, 0.0703125}
local shadow_shift = {0.4, 0.15}
local operating_mode = settings.startup["aai-loaders-mode"].value
local graphics_path = "__aai-loaders__/graphics/"
local no_lubricant_multiplier = 10
local dark_suffix = "_dark"
local blank_image = {filename=graphics_path.."entity/loader/loader_empty.png", size=1}

-- Add item subgroup
data:extend{
  {
    type = "item-subgroup",
    name = "loader",
    group = "logistics",
    order = "b[belt]-d"
  },
}

local pipecovers = pipecoverspictures()
pipecovers.north = blank_image

local function get_backsprite(spritename)
  return {
    priority = "high",
    filename = graphics_path .. "entity/loader/" .. spritename,
    line_length = 1,
    width = 49,
    height = 59,
    frame_count = 1,
    direction_count = 1,
    shift = sprite_shift,
    hr_version =
    {
      priority = "high",
      filename = graphics_path .. "entity/loader/hr_" .. spritename,
      line_length = 1,
      width = 99,
      height = 117,
      frame_count = 1,
      direction_count = 1,
      shift = sprite_shift,
      scale = 0.5
    }
  }
end

local function get_fluid(input)
  return input.fluid or "lubricant"
end

local function get_consumption(input)
  return math.ceil(math.max(0.1, input.fluid_per_minute or 1) * 100) / 100
end

local function make_loader_entity(input)
  local suffix = input.dark and dark_suffix or ""
  local structure = input.structure or "loader"
  local localised_description = operating_mode == "lubricated" and
    {"entity-description.aai-loader-lubricated-shared", get_consumption(input), get_fluid(input)} or
    {"entity-description.aai-loader-expensive-shared"}

  local entity = {
    name = input.name,
    type = "loader-1x1",
    icons = {
      {
        icon = graphics_path .. "icons/" .. (input.icon or "loader") .. suffix .. ".png",
        icon_size = 64
      },
      {
        icon = graphics_path .. "icons/" .. (input.icon or "loader") .. "_mask" .. suffix .. ".png",
        icon_size = 64,
        tint = input.color
      }
    },
    localised_name = input.localised_name,
    localised_description = localised_description,
    icon_size = 64,
    flags = {"placeable-neutral", "player-creation", "fast-replaceable-no-build-while-moving"},
    minable = {
      mining_time = 0.25, -- too fast?
      result = input.name
    },
    max_health = 300,
    filter_count = 5,
    corpse = "small-remnants",
    resistances = {
      {
        type = "fire",
        percent = 90
      }
    },
    collision_box = { {-0.4, -0.45}	, {0.4, 0.45} },
    selection_box = { {-0.5, -0.5}	, {0.5, 0.5} 	},
    drawing_box = { {-0.4, -0.4}	, {0.4, 0.4} 	},
    animation_speed_coefficient = 32,
    container_distance = 0.75, -- Default: 1.5
    -- belt_distance = 0.5, --Default1x1: 0.0  --Default2x1: 0.5
    belt_length = 0.5, -- Default: 0.5
    structure_render_layer = "object",
    -- structure_render_layer = "transport-belt-circuit-connector", --Default:"lower-object"
    belt_animation_set = input.transport_belt.belt_animation_set,
    fast_replaceable_group = input.fast_replaceable_group or "transport-belt",
    next_upgrade = input.upgrade,
    speed = input.speed or input.transport_belt.speed,
    order = input.order or (string.format("d[loader]-a%02d[%s]", input.count, input.name)),
    se_allow_in_space = input.se_allow_in_space,
    -- Integration Patch to render tiny pieces behind the belt
    integration_patch_render_layer = "decals",
    integration_patch = {
      north = get_backsprite(structure .. "_empty.png"),
      east = get_backsprite(structure .. "_side.png"),
      south = get_backsprite(structure .. "_empty.png"),
      west = get_backsprite(structure .. "_side.png"),
    },
    structure = {
      direction_in = {
        sheets = {
           {
            filename = graphics_path .. "entity/loader/" .. structure .. "_shadows.png",
            priority = "extra-high",
            shift = shadow_shift,
            width = 69,
            height = 39,
            draw_as_shadow = true,
            hr_version = {
              filename = graphics_path .. "entity/loader/hr_" .. structure .. "_shadows.png",
              priority = "extra-high",
              shift = shadow_shift,
              width = 138,
              height = 79,
              scale = 0.5,
              draw_as_shadow = true
            }
          },
          {
            filename = graphics_path .. "entity/loader/" .. structure .. suffix .. ".png",
            priority = "extra-high",
            shift = sprite_shift,
            width = 49,
            height = 58,
            hr_version = {
              filename = graphics_path .. "entity/loader/hr_" .. structure .. suffix .. ".png",
              priority = "extra-high",
              shift = sprite_shift,
              width = 99,
              height = 117,
              scale = 0.5
            }
          },
          {
            filename = graphics_path .. "entity/loader/" .. structure .. "_tint" .. suffix .. ".png",
            priority = "extra-high",
            shift = sprite_shift,
            width = 49,
            height = 58,
            tint = input.color,
            hr_version = {
              filename = graphics_path .. "entity/loader/hr_" .. structure .. "_tint" .. suffix .. ".png",
              priority = "extra-high",
              shift = sprite_shift,
              width = 99,
              height = 117,
              scale = 0.5,
              tint = input.color
            }
          },
        }
      },
      direction_out = {
        sheets = {
          {
            filename = graphics_path .. "entity/loader/" .. structure .. "_shadows.png",
            priority = "extra-high",
            shift = shadow_shift,
            width = 69,
            height = 39,
            y = 39,
            draw_as_shadow = true,
            hr_version = {
              filename = graphics_path .. "entity/loader/hr_" .. structure .. "_shadows.png",
              priority = "extra-high",
              shift = shadow_shift,
              width = 138,
              height = 79,
              y = 79,
              scale = 0.5,
              draw_as_shadow = true,
            }
          },
          {
            filename = graphics_path .. "entity/loader/" .. structure .. suffix .. ".png",
            priority = "extra-high",
            shift = sprite_shift,
            width = 49,
            height = 58,
            y = 59,
            hr_version = {
              filename = graphics_path .. "entity/loader/hr_" .. structure .. suffix .. ".png",
              priority = "extra-high",
              shift = sprite_shift,
              width = 99,
              height = 117,
              y = 117,
              scale = 0.5
            }
          },
          {
            filename = graphics_path .. "entity/loader/" .. structure .. "_tint" .. suffix .. ".png",
            priority = "extra-high",
            shift = sprite_shift,
            width = 49,
            height = 58,
            tint = input.color,
            y = 59,
            hr_version = {
              filename = graphics_path .. "entity/loader/hr_" .. structure .. "_tint" .. suffix .. ".png",
              priority = "extra-high",
              shift = sprite_shift,
              width = 99,
              height = 117,
              scale = 0.5,
              y = 117,
              tint = input.color
            }
          }
        }
      }
    }
  }

  data:extend {entity}

  return data.raw['loader-1x1'][input.name]
end

local function make_loader_pipe(input)
  local suffix = input.dark and dark_suffix or ""
  local fluid = get_fluid (input)
  local consumption = get_consumption(input)
  local pipe = {
    type = "storage-tank",
    name = input.name .. "-pipe",
    icons = {
      {
        icon = graphics_path .. "icons/" .. (input.icon or "loader")  .. suffix .. ".png",
        icon_size = 64
      },
      {
        icon = graphics_path .. "icons/" .. (input.icon or "loader") .. "_mask" .. suffix .. ".png",
        icon_size = 64,
        tint = input.color
      }
    },
    scale_info_icons = false,
    render_layer = "higher-object-above",
    flags = {"placeable-player", "player-creation", "placeable-off-grid", "not-deconstructable", "not-blueprintable", "hide-alt-info"},
    max_health = 100,
    order = "zz",
    collision_box = {{-0.4, -0.4}, {0.4, 0.4}},
    collision_mask = {},
    selection_box = {{-0.4, -0.4}, {0.4, 0.4}},
    selectable_in_game = false,
    fluid_box =
    {
      base_area = 1 + consumption / 100, -- gets multiplied by 100 by engine
      base_level = 0,
      height = 1,
      pipe_covers = table.deepcopy(pipecovers),
      pipe_connections = {{position={-1, 0}}, {position={1, 0}}},
      filter = fluid
    },
    two_direction_only = false,
    window_bounding_box = {{-0.0, 0.0}, {0.0, 1.0}},
    pictures = {
      picture = {
        east = {
          filename = "__aai-loaders__/graphics/entity/loader/pipe-straight-vertical" .. suffix .. ".png",
          priority = "extra-high",
          width = 64,
          height = 64,
          hr_version =
          {
            filename = "__aai-loaders__/graphics/entity/loader/hr-pipe-straight-vertical" .. suffix .. ".png",
            priority = "extra-high",
            width = 128,
            height = 128,
            scale = 0.5
          }
        },
        west = {
          filename = "__aai-loaders__/graphics/entity/loader/pipe-straight-vertical" .. suffix .. ".png",
          priority = "extra-high",
          width = 64,
          height = 64,
          hr_version =
          {
            filename = "__aai-loaders__/graphics/entity/loader/hr-pipe-straight-vertical" .. suffix .. ".png",
            priority = "extra-high",
            width = 128,
            height = 128,
            scale = 0.5
          }
        },
        north = blank_image,
        south = blank_image,
      },
      window_background = blank_image,
      fluid_background = blank_image,
      flow_sprite = blank_image,
      gas_flow = blank_image,
    },
    flow_length_in_ticks = 360,
    se_allow_in_space = true,  -- space-tile collision mask prevents fast-replacing loader
  }

  data:extend{pipe}

  return data.raw['storage-tank'][input.name .. "-pipe"]
end

local function make_loader_recipe(input)
  if not input.recipe then return end

  local recipe_template = table.deepcopy(input.recipe)

  if operating_mode == "expensive" then
    if input.unlubricated_recipe then
      recipe_template = table.deepcopy(input.unlubricated_recipe)
    else
      -- multiply
      for _, set in pairs({recipe_template, recipe_template.normal, recipe_template.expensive}) do
        if set and set.ingredients then
          for _, ingredient in pairs(set.ingredients) do
            if ingredient.amount then
              ingredient.amount = ingredient.amount * no_lubricant_multiplier
            else
              ingredient[2] = (ingredient[2] or 1) * no_lubricant_multiplier
            end
          end
        end
      end
    end
  end

  local recipe = {
    name = recipe_template.name or input.name,
    type = "recipe",
    category = recipe_template.crafting_category,
    order = input.order or string.format("d[loader]-a%02d[%s]", input.count, input.name),
    localised_name = input.localised_name
  }

  if recipe_template.normal and recipe_template.expensive then
    recipe.normal = {
      ingredients = recipe_template.normal.ingredients or {},
      enabled = false,
      energy_required = recipe_template.normal.energy_required,
      result = input.name
    }
    recipe.expensive = {
      ingredients = recipe_template.expensive.ingredients or {},
      enabled = false,
      energy_required = recipe_template.expensive.energy_required,
      result = input.name
    }
  else
    recipe.ingredients = recipe_template.ingredients or {}
    recipe.enabled = false
    recipe.energy_required = recipe_template.energy_required
    recipe.result = input.name
  end

  data:extend{recipe}

  return data.raw.recipe[recipe.name]
end

local function make_loader_tech(input)
  local suffix = input.dark and dark_suffix or ""
  local name = input.technology and input.technology.name or input.name

  if not data.raw.technology[name] and input.technology then
    local localised_description = operating_mode == "lubricated" and
      {"technology-description.aai-loader-lubricated-shared", get_consumption(input), get_fluid(input)} or
      {"technology-description.aai-loader-expensive-shared"}

    local tech = {
      name = name,
      type = "technology",
      icons = {
        {
          icon = graphics_path .. "technology/loader-tech-icon" .. suffix .. ".png" ,
          icon_size = 256
        },
        {
          icon = graphics_path .. "technology/loader-tech-icon_mask" .. suffix .. ".png",
          icon_size = 256, tint = input.color}
      },
      order = input.order or string.format("d[loader]-a%02d[%s]", input.count, input.name),
      localised_name = input.localised_name,
      localised_description = localised_description
    }

    if input.technology.normal and input.technology.expensive then
      tech.normal = {
        unit = input.technology.normal.unit,
        upgrade = false,
        prerequisites = input.technology.normal.prerequisites or {}
      }
      tech.expensive = {
        unit = input.technology.expensive.unit,
        upgrade = false,
        prerequisites = input.technology.expensive.prerequisites or {}
      }
    else
      tech.unit = input.technology.unit
      tech.upgrade = false
      tech.prerequisites = input.technology.prerequisites or {}
    end

    if operating_mode == "lubricated" and input.fluid_technology_prerequisites then
      for _, prereq in pairs(input.fluid_technology_prerequisites) do
        if tech.prerequisites then
          table.insert(tech.prerequisites, prereq)
        end
        if tech.normal then
          table.insert(tech.normal.prerequisites, prereq)
        end
        if tech.expensive then
          table.insert(tech.expensive.prerequisites, prereq)
        end
      end
    end

    data:extend{tech}

    return data.raw.technology[name]
  else
    return data.raw.technology[name]
  end
end

local function make_loader_item(input)
  local suffix = input.dark and dark_suffix or ""
  local localised_description = operating_mode == "lubricated" and
    {"entity-description.aai-loader-lubricated-shared", get_consumption(input), get_fluid(input)} or
    {"entity-description.aai-loader-expensive-shared"}

  data:extend{
    {
      name = input.name,
      type = "item",
      icons = {
        {
          icon = graphics_path .. "icons/" .. (input.icon or "loader") .. suffix .. ".png",
          icon_size = 64
        },
        {
          icon = graphics_path .. "icons/" .. (input.icon or "loader") .. "_mask" .. suffix .. ".png",
          icon_size = 64,
          tint = input.color
        }
      },
      localised_name = input.localised_name,
      localised_description = localised_description,
      stack_size = 50,
      subgroup = input.subgroup or "loader",
      order = input.order or string.format("d[loader]-a%02d[%s]", input.count, input.name),
      place_result = input.name
    }
  }
  return data.raw.item[input.name]
end

AAILoaders = AAILoaders or {}
AAILoaders.loader_count = 0

function AAILoaders.make_tier(input)
  -- Do nothing if in graphics-only mode
  if operating_mode == "graphics-only" then return end

  if not input.name then
    debug_log("AAI Loader Error: name field is required.")
    return
  end

  debug_log("Beginning to create AAI Loader: " .. input.name)

  if input.name == "" then
    -- Basic loader will get this name
    input.name = "aai-loader"
  else
    input.name = "aai-" .. input.name .. "-loader"
  end

  if not input.transport_belt then
    debug_log ("Error: no transport belt name provided; `transport_belt` field is required.")
    return
  elseif not data.raw['transport-belt'][input.transport_belt] then
    debug_log ("Error: bad transport belt name provided; `transport_belt` field is required.")
    return
  end
  input.transport_belt = data.raw['transport-belt'][input.transport_belt]

  if not input.recipe then
    debug_log ("Error: `recipe` field is required.")
    return
  end

  if not input.speed then
    debug_log ("No speed input provided: using value from transport belt.")
  end

  if not input.color then
    debug_log ("No color input provided: using default color.")
    input.color = { r = 1.0, g = 1.0, b = 1.0 }
  end

  if not input.technology then
    if not data.raw.technology[input.name] then
      debug_log("No technology input provided: loaders won't be avaivable to unlock.")
    else
      debug_log(string.format("No `technology` field provided: loaders will be added to existing tecnology: %s.", input.name))
    end
  end

  if input.localise then
    input.localised_name = {
      "aai-loader.loader-name",
      (input.transport_belt.localised_name or {"entity-name." .. input.transport_belt.name})
    }
  end
  --refine the escape clauses some more? add validation to the input beyond it's existance?

  AAILoaders.loader_count = AAILoaders.loader_count + 1
  input.count = AAILoaders.loader_count

  local entity = make_loader_entity(input)
  local item = make_loader_item(input)
  local recipe = make_loader_recipe(input)
  local tech = make_loader_tech(input)

  if operating_mode == "lubricated" then
    make_loader_pipe(input)
  end

  if tech and recipe then
    if tech.normal and tech.expensive then
      tech.normal.effects = tech.normal.effects or {}
      table.insert(tech.normal.effects, {type="unlock-recipe", recipe=recipe.name})

      tech.expensive.effects = tech.expensive.effects or {}
      table.insert(tech.expensive.effects, {type="unlock-recipe", recipe=recipe.name})
    else
      tech.effects = tech.effects or {}
      table.insert(tech.effects, {type="unlock-recipe", recipe=recipe.name})
    end
  end

  return {loader=entity, item=item, recipe=recipe, technology=tech}
end
