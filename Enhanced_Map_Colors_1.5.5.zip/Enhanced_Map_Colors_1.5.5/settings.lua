data:extend({
	{
		type = "bool-setting",
		name = "Use-Mod-Color-for-pipes",
		setting_type = "startup", --"startup", "runtime-global", "runtime-per-user"
		default_value = true
	},
	-- {
		-- type = "bool-setting",
		-- name = "Use-Mod-Color-for-beacons",
		-- setting_type = "startup", --"startup", "runtime-global", "runtime-per-user"
		-- default_value = true
	-- },
	{
		type = "bool-setting",
		name = "Use-Mod-Color-for-heat-pipes",
		setting_type = "startup", --"startup", "runtime-global", "runtime-per-user"
		default_value = true
	},
	{
		type = "bool-setting",
		name = "Use-Mod-Color-for-roboports",
		setting_type = "startup", --"startup", "runtime-global", "runtime-per-user"
		default_value = true
	},
	{
		type = "bool-setting",
		name = "Use-Mod-Color-for-steam-generators",
		setting_type = "startup", --"startup", "runtime-global", "runtime-per-user"
		default_value = true
	}
})