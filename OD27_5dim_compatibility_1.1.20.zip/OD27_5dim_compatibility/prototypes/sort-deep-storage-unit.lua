-- Memory Unit
if(data.raw.item["memory-unit"] ~= nil) then
    data.raw.item["memory-unit"].subgroup = "store-solid"
    data.raw.item["memory-unit"].order = "i"
end