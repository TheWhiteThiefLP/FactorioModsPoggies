-- Loaders
if(data.raw.item["5d-transport-belt-04-loader"] ~= nil) then
    data.raw.item["5d-transport-belt-04-loader"].subgroup = "transport-dead-loader"
    data.raw.item["5d-transport-belt-04-loader"].order = "d"
end

if(data.raw.item["5d-transport-belt-05-loader"] ~= nil) then
    data.raw.item["5d-transport-belt-05-loader"].subgroup = "transport-dead-loader"
    data.raw.item["5d-transport-belt-05-loader"].order = "e"
end

if(data.raw.item["5d-transport-belt-06-loader"] ~= nil) then
    data.raw.item["5d-transport-belt-06-loader"].subgroup = "transport-dead-loader"
    data.raw.item["5d-transport-belt-06-loader"].order = "f"
end

if(data.raw.item["5d-transport-belt-07-loader"] ~= nil) then
    data.raw.item["5d-transport-belt-07-loader"].subgroup = "transport-dead-loader"
    data.raw.item["5d-transport-belt-07-loader"].order = "g"
end

if(data.raw.item["5d-transport-belt-08-loader"] ~= nil) then
    data.raw.item["5d-transport-belt-08-loader"].subgroup = "transport-dead-loader"
    data.raw.item["5d-transport-belt-08-loader"].order = "h"
end

if(data.raw.recipe["5d-transport-belt-04-loader"] ~= nil) then
    data.raw.recipe["5d-transport-belt-04-loader"].subgroup = "transport-dead-loader"
    data.raw.recipe["5d-transport-belt-04-loader"].order = "d"
end

if(data.raw.recipe["5d-transport-belt-05-loader"] ~= nil) then
    data.raw.recipe["5d-transport-belt-05-loader"].subgroup = "transport-dead-loader"
    data.raw.recipe["5d-transport-belt-05-loader"].order = "e"
end

if(data.raw.recipe["5d-transport-belt-06-loader"] ~= nil) then
    data.raw.recipe["5d-transport-belt-06-loader"].subgroup = "transport-dead-loader"
    data.raw.recipe["5d-transport-belt-06-loader"].order = "f"
end

if(data.raw.recipe["5d-transport-belt-07-loader"] ~= nil) then
    data.raw.recipe["5d-transport-belt-07-loader"].subgroup = "transport-dead-loader"
    data.raw.recipe["5d-transport-belt-07-loader"].order = "g"
end

if(data.raw.recipe["5d-transport-belt-08-loader"] ~= nil) then
    data.raw.recipe["5d-transport-belt-08-loader"].subgroup = "transport-dead-loader"
    data.raw.recipe["5d-transport-belt-08-loader"].order = "h"
end

-- Beltbox
if(data.raw.item["5d-transport-belt-04-beltbox"] ~= nil) then
    data.raw.item["5d-transport-belt-04-beltbox"].subgroup = "transport-dead-beltbox"
    data.raw.item["5d-transport-belt-04-beltbox"].order = "d"
end

if(data.raw.item["5d-transport-belt-05-beltbox"] ~= nil) then
    data.raw.item["5d-transport-belt-05-beltbox"].subgroup = "transport-dead-beltbox"
    data.raw.item["5d-transport-belt-05-beltbox"].order = "e"
end

if(data.raw.item["5d-transport-belt-06-beltbox"] ~= nil) then
    data.raw.item["5d-transport-belt-06-beltbox"].subgroup = "transport-dead-beltbox"
    data.raw.item["5d-transport-belt-06-beltbox"].order = "f"
end

if(data.raw.item["5d-transport-belt-07-beltbox"] ~= nil) then
    data.raw.item["5d-transport-belt-07-beltbox"].subgroup = "transport-dead-beltbox"
    data.raw.item["5d-transport-belt-07-beltbox"].order = "g"
end

if(data.raw.item["5d-transport-belt-08-beltbox"] ~= nil) then
    data.raw.item["5d-transport-belt-08-beltbox"].subgroup = "transport-dead-beltbox"
    data.raw.item["5d-transport-belt-08-beltbox"].order = "h"
end

if(data.raw.recipe["5d-transport-belt-04-beltbox"] ~= nil) then
    data.raw.recipe["5d-transport-belt-04-beltbox"].subgroup = "transport-dead-beltbox"
    data.raw.recipe["5d-transport-belt-04-beltbox"].order = "d"
end

if(data.raw.recipe["5d-transport-belt-05-beltbox"] ~= nil) then
    data.raw.recipe["5d-transport-belt-05-beltbox"].subgroup = "transport-dead-beltbox"
    data.raw.recipe["5d-transport-belt-05-beltbox"].order = "e"
end

if(data.raw.recipe["5d-transport-belt-06-beltbox"] ~= nil) then
    data.raw.recipe["5d-transport-belt-06-beltbox"].subgroup = "transport-dead-beltbox"
    data.raw.recipe["5d-transport-belt-06-beltbox"].order = "f"
end

if(data.raw.recipe["5d-transport-belt-07-beltbox"] ~= nil) then
    data.raw.recipe["5d-transport-belt-07-beltbox"].subgroup = "transport-dead-beltbox"
    data.raw.recipe["5d-transport-belt-07-beltbox"].order = "g"
end

if(data.raw.recipe["5d-transport-belt-08-beltbox"] ~= nil) then
    data.raw.recipe["5d-transport-belt-08-beltbox"].subgroup = "transport-dead-beltbox"
    data.raw.recipe["5d-transport-belt-08-beltbox"].order = "h"
end