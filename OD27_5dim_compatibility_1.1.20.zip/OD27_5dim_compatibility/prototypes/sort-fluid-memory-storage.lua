-- Memory Unit
if(data.raw.item["fluid-memory-unit"] ~= nil) then
    data.raw.item["fluid-memory-unit"].subgroup = "liquid-misc"
    data.raw.item["fluid-memory-unit"].order = "a"
end