data:extend(
{
  {
    type = "bool-setting",
    name = "bobmods-recursive-circuitred",
    setting_type = "startup",
    default_value = true,
  },
})