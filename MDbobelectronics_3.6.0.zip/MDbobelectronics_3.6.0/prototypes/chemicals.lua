data:extend(
{
  {
    type = "fluid",
    name = "ferric-chloride-solution",
    icon = "__MDbobelectronics__/graphics/icons/ferric-chloride-solution.png",
    icon_size = 32,
    default_temperature = 25,
    heat_capacity = "1KJ",
    base_color = {r=0.7, g=0.6, b=0.2},
    flow_color = {r=0.5, g=0.5, b=0.5},
    max_temperature = 100,
    pressure_to_speed_ratio = 0.4,
    flow_to_energy_ratio = 0.59,
    order = "a[fluid]-g[ferric-chloride-solution]"
  },

  {
    type = "recipe",
    name = "ferric-chloride-solution",
    icon = "__MDbobelectronics__/graphics/icons/ferric-chloride-solution.png",
    icon_size = 32,
    subgroup = "bob-resource-chemical",
    order = "x[fluid-chemistry]-a[ferric-chloride-solution]",
    category = "chemistry",
    enabled = false,
    energy_required = 2.5,
    ingredients =
    {
      {type="item", name="iron-ore", amount=1},
      {type="fluid", name="water", amount=30},
    },
    results=
    {
      {type="fluid", name="ferric-chloride-solution", amount=50}
    },
    crafting_machine_tint =
    {
      primary = {r = 0.7, g = 0.6, b = 0.2, a = 0.000},
      secondary = {r = 0.2, g = 0.7, b = 0.0, a = 0.000},
      tertiary = {r = 0.0, g = 0.7, b = 0.7, a = 0.000},
    },
    allow_decomposition = false
  },
}
)



