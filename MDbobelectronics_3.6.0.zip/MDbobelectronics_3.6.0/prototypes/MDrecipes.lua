



--recycling doesnt detect recipe change, doing it manually
if mods["space-exploration"] then

	if mods["Krastorio2"] then
	bobmods.lib.recipe.remove_result("se-recycle-radar", "electronic-circuit")
	bobmods.lib.recipe.add_result("se-recycle-radar", "automation-core")
	
	else

	bobmods.lib.recipe.remove_result("se-recycle-radar", "electronic-circuit")
	bobmods.lib.recipe.add_result("se-recycle-radar", {"basic-circuit-board", 6})
	end
--fix for krastorio/spaceex radar recipe glitch
end



--insulated-cable
if mods["bzsilicon"] then
	bobmods.lib.recipe.add_ingredient("optical-fiber", {"insulated-cable", 1})
	
	--seems that new version of bzsilicon adds this ingredient which interfears
	if data.raw.item["silicon"] then
	bobmods.lib.recipe.remove_ingredient("processing-unit", "silicon")
	end
	
else
	data.raw.recipe["red-wire"].ingredients = {{"insulated-cable", 1}}
	data.raw.recipe["green-wire"].ingredients = {{"insulated-cable", 1}}
end
------------------------------------------------------------------------------------------------------------------------------------------------




if settings.startup["bobmods-recursive-circuitred"].value == true then

if mods["space-exploration"] and not mods["Krastorio2"] then

bobmods.lib.recipe.set_ingredient("advanced-circuit", {"electronic-circuit", 2})

bobmods.lib.recipe.set_ingredient("processing-unit", {"advanced-circuit", 2})
bobmods.lib.recipe.set_ingredient("processing-unit", {"electronic-circuit", 20})

bobmods.lib.recipe.set_ingredient("se-processing-unit-holmium", {"advanced-circuit", 1})
bobmods.lib.recipe.set_ingredient("se-processing-unit-holmium", {"electronic-circuit", 10})

bobmods.lib.recipe.set_ingredient("advanced-processing-unit", {"processing-unit", 1})
end

if mods["Krastorio2"] and not mods["space-exploration"] then

bobmods.lib.recipe.set_ingredient("advanced-circuit", {"electronic-circuit", 4})
bobmods.lib.recipe.set_ingredient("processing-unit", {"advanced-circuit", 6})
bobmods.lib.recipe.set_ingredient("advanced-processing-unit", {"processing-unit", 1})
end

if mods["Krastorio2"] and mods["space-exploration"] then

bobmods.lib.recipe.set_ingredient("advanced-circuit", {"electronic-circuit", 4})

bobmods.lib.recipe.set_ingredient("processing-unit", {"advanced-circuit", 6})
bobmods.lib.recipe.set_ingredient("se-processing-unit-holmium", {"advanced-circuit", 3})

bobmods.lib.recipe.set_ingredient("advanced-processing-unit", {"processing-unit", 1})
end

if not mods["Krastorio2"] and not mods["space-exploration"] then
bobmods.lib.recipe.set_ingredient("advanced-circuit", {"electronic-circuit", 2})

bobmods.lib.recipe.set_ingredient("processing-unit", {"advanced-circuit", 2})
bobmods.lib.recipe.set_ingredient("processing-unit", {"electronic-circuit", 20})

bobmods.lib.recipe.set_ingredient("advanced-processing-unit", {"processing-unit", 1})
end


--change results
if mods["Krastorio2"] then
--bobmods.lib.recipe.set_result("electronic-circuit", {"electronic-circuit", 1})
bobmods.lib.recipe.set_result("advanced-circuit", {"advanced-circuit", 2})
bobmods.lib.recipe.set_result("processing-unit", {"processing-unit", 2})
bobmods.lib.recipe.set_result("se-processing-unit-holmium", {"processing-unit", 2})
end


--if not then make sure to remove
else

bobmods.lib.recipe.remove_ingredient("advanced-circuit", "electronic-circuit")

bobmods.lib.recipe.remove_ingredient("processing-unit", "advanced-circuit")
bobmods.lib.recipe.remove_ingredient("processing-unit", "electronic-circuit")

bobmods.lib.recipe.remove_ingredient("se-processing-unit-holmium", "advanced-circuit")
bobmods.lib.recipe.remove_ingredient("se-processing-unit-holmium", "electronic-circuit")

--just in case go back to 1 result
bobmods.lib.recipe.set_result("advanced-circuit", {"advanced-circuit", 1})
bobmods.lib.recipe.set_result("processing-unit", {"processing-unit", 1})

if mods["space-exploration"] and not mods["Krastorio2"] then bobmods.lib.recipe.set_result("se-processing-unit-holmium", {"processing-unit", 2}) end

end


if mods["Krastorio2"] then
bobmods.lib.recipe.add_ingredient("advanced-circuit", {"electronic-components", 2})
bobmods.lib.recipe.add_ingredient("advanced-processing-unit", {"rare-metals", 5})
bobmods.lib.recipe.add_ingredient("advanced-processing-unit", {"processing-electronics", 2})
bobmods.lib.recipe.add_ingredient("advanced-processing-unit", {type="fluid", name="nitric-acid", amount=10})

bobmods.lib.recipe.add_ingredient("kr-advanced-assembling-machine", {"advanced-processing-unit", amount=2})
bobmods.lib.recipe.add_ingredient("kr-advanced-furnace", {"advanced-processing-unit", amount=5})
end










------------------------------------------------------------------------------------------------------------------------------------------------
--add circuits to recipes
if mods["space-exploration"] then

bobmods.lib.recipe.add_ingredient("se-processing-unit-holmium", {"basic-electronic-components", 1})
bobmods.lib.recipe.add_ingredient("se-processing-unit-holmium", {"BOBMD-electronic-components", 2})
bobmods.lib.recipe.add_ingredient("se-processing-unit-holmium", {"intergrated-electronics", 1})
bobmods.lib.recipe.add_ingredient("se-processing-unit-holmium", {"superior-circuit-board", 1})
bobmods.lib.recipe.add_ingredient("processing-unit", {type="fluid", name="sulfuric-acid", amount=4})


bobmods.lib.recipe.add_ingredient("se-space-assembling-machine", {"advanced-processing-unit", amount=2})
bobmods.lib.recipe.replace_ingredient("se-spaceship-console", "processing-unit", "advanced-processing-unit")
bobmods.lib.recipe.add_ingredient("se-space-supercomputer-2", {"advanced-processing-unit", amount=150})
bobmods.lib.recipe.replace_ingredient("se-space-supercomputer-3", "processing-unit", "advanced-processing-unit")


--SE 0.6 it no longer makes sense
--[[
bobmods.lib.recipe.replace_ingredient("speed-module-6", "processing-unit", "advanced-processing-unit")
bobmods.lib.recipe.replace_ingredient("speed-module-7", "processing-unit", "advanced-processing-unit")
bobmods.lib.recipe.replace_ingredient("productivity-module-6", "processing-unit", "advanced-processing-unit")
bobmods.lib.recipe.replace_ingredient("productivity-module-7", "processing-unit", "advanced-processing-unit")
bobmods.lib.recipe.replace_ingredient("effectivity-module-6", "processing-unit", "advanced-processing-unit")
bobmods.lib.recipe.replace_ingredient("effectivity-module-7", "processing-unit", "advanced-processing-unit")
]]


--SE 0.6 force circuits back to my own tab

if data.raw.item["electronic-circuit"] then data.raw.item["electronic-circuit"].subgroup = "bob-electronic-boards" end
if data.raw.item["advanced-circuit"] then data.raw.item["advanced-circuit"].subgroup = "bob-electronic-boards" end
if data.raw.item["processing-unit"] then data.raw.item["processing-unit"].subgroup = "bob-electronic-boards" end
if data.raw.item["se-processing-unit-holmium"] then data.raw.item["se-processing-unit-holmium"].subgroup = "bob-electronic-boards" end

end

--progression fix for krastorio:
if data.raw.fluid["hydrogen-chloride"] then

bobmods.lib.tech.add_recipe_unlock("kr-fluids-chemistry", "hydrogen-chloride")
bobmods.lib.tech.remove_recipe_unlock("kr-advanced-chemistry", "hydrogen-chloride")
end



if data.raw.item["electronic-circuit"] then 
bobmods.lib.recipe.set_ingredients("electronic-circuit", {{"basic-circuit-board", 1}, {"basic-electronic-components", 5}})
end





