data:extend(
{
  {
    type = "recipe-category",
    name = "crafting-machine"
  },
  {
    type = "recipe-category",
    name = "electronics"
  },
  {
    type = "recipe-category",
    name = "electronics-machine"
  },
  {
    type = "item-group",
    name = "bob-intermediate-products",
    order = "c-i",
    inventory_order = "a-c",
    icon = "__MDbobelectronics__/graphics/icons/technology/intermediates.png",
    icon_size = 64,
  },
  
  ---
  {
    type = "item-subgroup",
    name = "bob-resource-chemical",
    group = "bob-intermediate-products",
    order = "e-a1"
  },

  {
    type = "item-subgroup",
    name = "bob-electronic-components",
    group = "bob-intermediate-products",
    order = "e-a2"
  },
  {
    type = "item-subgroup",
    name = "bob-boards",
    group = "bob-intermediate-products",
    order = "e-a3"
  },
  {
    type = "item-subgroup",
    name = "bob-electronic-boards",
    group = "bob-intermediate-products",
    order = "e-a4"
  },
  {
    type = "item-subgroup",
    name = "bob-resource",
    group = "bob-intermediate-products",
    order = "e-a5"
  },
}
)
