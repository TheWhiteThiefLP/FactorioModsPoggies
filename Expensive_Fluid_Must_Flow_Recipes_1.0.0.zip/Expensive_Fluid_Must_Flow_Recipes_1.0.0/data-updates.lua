-- Helper functions, thanks to https://forums.factorio.com/viewtopic.php?t=102165&p=566460
local function replace_in_difficulty(ingredients, old, new)
	if not (ingredients and old and new) then
		return
	end

	for i, ingredient in pairs(ingredients) do
		if ingredient[1] == old then
			ingredient[1] = new
		elseif ingredient.name == old then
			ingredient.name = new
		end
	end
end

function ReplaceAllIngredientItemOfRecipesWithItem(recipes, old, new)
	for i, recipe in pairs(recipes) do
		replace_in_difficulty(data.raw.recipe[recipe].ingredients, old, new)
		replace_in_difficulty(data.raw.recipe[recipe].normal and recipe.normal.ingredients, old, new)
		replace_in_difficulty(data.raw.recipe[recipe].expensive and recipe.expensive.ingredients, old, new)
	end
end

-- Update recipes
local recipes = {
	"duct-small", 
	"duct-t-junction", 
	"duct-curve", 
	"duct-cross", 
	"duct-underground", 
	"non-return-duct", 
	"duct-end-point-intake", 
	"duct-end-point-outtake"
}

if not settings.startup["fmf-enable-duct-auto-join"].value then
	table.insert(recipes, "duct")
	table.insert(recipes, "duct-long")
end


ReplaceAllIngredientItemOfRecipesWithItem(recipes, "iron-plate", "steel-plate")
ReplaceAllIngredientItemOfRecipesWithItem(recipes, "engine-unit", "electric-engine-unit")

if mods["Krastorio2"] then
	ReplaceAllIngredientItemOfRecipesWithItem(recipes, "iron-gear-wheel", "steel-gear-wheel")
	ReplaceAllIngredientItemOfRecipesWithItem(recipes, "pipe", "kr-steel-pipe")
end

if mods["bztitanium"] then
	ReplaceAllIngredientItemOfRecipesWithItem(recipes, "steel-plate", "titanium-plate")
end

-- Update technologies
table.insert(data.raw.technology["Ducts"].prerequisites, "electric-engine")
table.insert(data.raw.technology["Ducts"].prerequisites, "steel-processing")

if mods["bztitanium"] then
	table.insert(data.raw.technology["Ducts"].prerequisites, "titanium-processing")
end