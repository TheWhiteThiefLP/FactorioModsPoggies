
-- settings

data:extend({
    {
        type = "bool-setting",
        name = "ir2rb-arrows",
		order = "a",
        setting_type = "startup",
        default_value = true,
    },
    {
        type = "bool-setting",
        name = "ir2rb-rails",
		order = "b",
        setting_type = "startup",
        default_value = false,
    },
    {
        type = "bool-setting",
        name = "ir3-materials",
		order = "c",
        setting_type = "startup",
        default_value = false,
		hidden = (mods["IndustrialRevolution3"] == nil),
    },
})