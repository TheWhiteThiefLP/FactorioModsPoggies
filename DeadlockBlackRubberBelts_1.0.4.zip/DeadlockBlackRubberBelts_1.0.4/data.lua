------------------------------------------------------------------------------------------------------------------------------------------------------

-- BELTS: reskins
-- many Bothans died to bring us these shenanigans

------------------------------------------------------------------------------------------------------------------------------------------------------

local IR2RB = require("code.functions")

local alternate_bases = mods["IndustrialRevolution3"] and settings.startup["ir3-materials"].value and not settings.startup["ir2rb-rails"].value

local belts = {
	["transport"] = { hue = 0.11, base = alternate_bases and "copper" or "steel" },
	["fast-transport"] = { hue = 0, base = alternate_bases and "iron" or "steel" },
	["express-transport"] = { hue = 0.54, base = "steel" },
}

for belt,beltdata in pairs(belts) do

	local tint = IR2RB.hsva2rgba(beltdata.hue,0.8,1)
	local prototype = data.raw["transport-belt"][belt.."-belt"]
	if prototype then
		prototype.belt_animation_set.animation_set = IR2RB.get_belt_animation_set(tint, beltdata.base)
		prototype.corpse = "small-remnants"
		IR2RB.replace_item_icon(belt.."-belt", "rubber-belt-"..beltdata.base)
		if settings.startup["ir2rb-arrows"].value then IR2RB.add_mask_to_item_icon(belt.."-belt", "rubber-belt-mask", tint) end
		if settings.startup["ir2rb-rails"].value then IR2RB.add_mask_to_item_icon(belt.."-belt", "rubber-rail-mask", tint) end
		IR2RB.copy_item_icons_to_entity("transport-belt", belt.."-belt")
	end
	
end

local tab = data.raw["item-group"]["logistics"]
if tab then
	tab.icon = IR2RB.get_icon_path("logistics", "item-group")
	tab.icon_size = 256
	tab.icon_mipmaps = 4
	tab.icons = nil
end

------------------------------------------------------------------------------------------------------------------------------------------------------
