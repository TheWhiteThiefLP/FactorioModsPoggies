No Wall Repair 
====================

Disable repair for walls. This will prevent bots from sitting on walls 'repairing' them and taking damage / dying needlessly.

