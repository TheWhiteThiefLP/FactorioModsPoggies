data.raw["pipe-to-ground"]["se-space-pipe-to-ground"].fluid_box.pipe_connections[2].max_underground_distance = 32
data.raw["underground-belt"]["se-space-underground-belt"].max_distance = 16