data:extend({
	{
		type = "int-setting",
		name = "snip-light-artillery-damage-amount",
		setting_type = "startup",
		default_value = 100,
		minimum_value = 0
	},
	{
		type = "string-setting",
		name = "snip-light-artillery-damage-type",
		setting_type = "startup",
		default_value = "physical",
		allowed_values = {"physical", "impact", "fire", "acid", "poison", "explosion", "laser", "electric"}
	},
	{
		type = "double-setting",
		name = "snip-light-artillery-damage-radius",
		setting_type = "startup",
		default_value = 2.0,
		minimum_value = 0.1
	},
	{
		type = "int-setting",
		name = "snip-light-artillery-min-range",
		setting_type = "startup",
		default_value = 32,
		minimum_value = 0
	},
	{
		type = "int-setting",
		name = "snip-light-artillery-auto-range",
		setting_type = "startup",
		default_value = 168
	},
	{
		type = "double-setting",
		name = "snip-light-artillery-manual-range-modifier",
		setting_type = "startup",
		default_value = 2.5,
		minimum_value = 1
	},
	{
		type = "int-setting",
		name = "snip-light-artillery-attack-cooldown",
		setting_type = "startup",
		default_value = 200
	}
})