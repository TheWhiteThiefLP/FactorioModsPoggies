require("prototypes.light-artillery-ammo")
require("prototypes.light-artillery")
require("prototypes.technology")