----Light Artillery Cannon----
local snipArtilleryGun = table.deepcopy(data.raw["gun"]["artillery-wagon-cannon"])

snipArtilleryGun.name = "snip-artillery-gun"

local attack_parameters = snipArtilleryGun.attack_parameters

attack_parameters.cooldown = settings.startup["snip-light-artillery-attack-cooldown"].value
attack_parameters.min_range = settings.startup["snip-light-artillery-min-range"].value
attack_parameters.range = settings.startup["snip-light-artillery-auto-range"].value

data:extend{snipArtilleryGun}

----Light Artillery Turret----

local snipArtilleryEntity = table.deepcopy(data.raw["artillery-turret"]["artillery-turret"])

snipArtilleryEntity.name = "snip-artillery-turret"
snipArtilleryEntity.minable = {mining_time = 6, result = "snip-artillery-turret"}
snipArtilleryEntity.turret_rotation_speed = 0.002
snipArtilleryEntity.turn_after_shooting_cooldown = 30
snipArtilleryEntity.gun = "snip-artillery-gun"
snipArtilleryEntity.ammo_stack_limit = 50
snipArtilleryEntity.automated_ammo_count = 10
snipArtilleryEntity.max_health = 750
snipArtilleryEntity.manual_range_modifier = settings.startup["snip-light-artillery-manual-range-modifier"].value

data:extend{snipArtilleryEntity}

local rp_art_util = require("__rp_art_util__/rp_art_util");
local turret_art = require("__rp_artillery_turret_1_art__/artillery_turret_1");
rp_art_util:use_sprites(data.raw["artillery-turret"]["snip-artillery-turret"], turret_art);

----Light Artillery Item----

local snipArtilleryItem = table.deepcopy(data.raw["item"]["artillery-turret"])

snipArtilleryItem.name = "snip-artillery-turret"
snipArtilleryItem.place_result = "snip-artillery-turret"
snipArtilleryItem.stack_size = 10

data:extend{snipArtilleryItem}

rp_art_util:use_icon(data.raw["item"]["snip-artillery-turret"], turret_art);

----Light Artillery Recipe----

local snipArtilleryRecipe = table.deepcopy(data.raw.recipe["artillery-turret"])

snipArtilleryRecipe.name = "snip-artillery-turret"
snipArtilleryRecipe.result = "snip-artillery-turret"
snipArtilleryRecipe.ingredients = 
{
	{"steel-plate", 30},
	{"stone-brick", 60},
	{"iron-gear-wheel", 20},
	{"electronic-circuit", 20}
}

data:extend{snipArtilleryRecipe}

----Light Artillery Wagon Entity----
local snipArtilleryWagon = table.deepcopy(data.raw["artillery-wagon"]["artillery-wagon"])

snipArtilleryWagon.name = "snip-artillery-wagon"
snipArtilleryWagon.gun = "snip-artillery-gun"
snipArtilleryWagon.manual_range_modifier = 2.5
snipArtilleryWagon.minable = {mining_time = 0.5, result = "snip-artillery-wagon"}
snipArtilleryWagon.weight = 2000

data:extend{snipArtilleryWagon}

----Light Artillery Wagon Item----
local snipArtilleryWagonItem = table.deepcopy(data.raw["item-with-entity-data"]["artillery-wagon"])

snipArtilleryWagonItem.name = "snip-artillery-wagon"
snipArtilleryWagonItem.place_result = "snip-artillery-wagon"

data:extend{snipArtilleryWagonItem}

----Light Artillery Wagon Recipe----
local snipArtilleryWagonRecipe = table.deepcopy(data.raw.recipe["artillery-wagon"])

snipArtilleryWagonRecipe.name = "snip-artillery-wagon"
snipArtilleryWagonRecipe.result = "snip-artillery-wagon"
snipArtilleryWagonRecipe.ingredients =
{
	{"steel-plate", 40},
	{"iron-gear-wheel", 10},
	{"electronic-circuit", 20},
	{"engine-unit", 32},
	{"pipe", 8}
}

data:extend{snipArtilleryWagonRecipe}

----Change the artillery targeting remote crafting recipe----
data.raw["recipe"]["artillery-targeting-remote"].ingredients =
{
	{"advanced-circuit", 1},
	{"radar", 1}
}