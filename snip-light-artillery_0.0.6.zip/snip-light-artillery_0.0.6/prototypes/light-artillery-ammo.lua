----Item----
local snipArtilleryAmmo = table.deepcopy(data.raw["ammo"]["artillery-shell"])

snipArtilleryAmmo.name = "snip-light-artillery-ammo"
snipArtilleryAmmo.ammo_type.action.action_delivery.projectile = "snip-light-artillery-projectile"
snipArtilleryAmmo.stack_size = 25

data:extend{snipArtilleryAmmo}

----Recipe----
local snipArtilleryAmmoRecipe = table.deepcopy(data.raw.recipe["artillery-shell"])

snipArtilleryAmmoRecipe.name = "snip-light-artillery-ammo"
snipArtilleryAmmoRecipe.result = "snip-light-artillery-ammo"
snipArtilleryAmmoRecipe.ingredients =
{
	{"steel-plate", 2},
	{"explosives", 1},
	{"copper-plate", 5},
}
snipArtilleryAmmoRecipe.category = "advanced-crafting"
snipArtilleryAmmoRecipe.energy_required = 7.5

data:extend{snipArtilleryAmmoRecipe}

----Projectile----
local snipArtilleryProjectile = table.deepcopy(data.raw["artillery-projectile"]["artillery-projectile"])

snipArtilleryProjectile.name = "snip-light-artillery-projectile"

snipArtilleryProjectile.action.action_delivery.target_effects = {
	{
		action = {
			action_delivery = {
				target_effects = {
					{
						damage = {
							amount = settings.startup["snip-light-artillery-damage-amount"].value, -- 9 two-shots small biters
							type = settings.startup["snip-light-artillery-damage-type"].value
						},
						type = "damage"
					}
				},
				type = "instant"
			},
			radius = settings.startup["snip-light-artillery-damage-radius"].value,
			type = "area"
		},
		type = "nested-result"
	},
	{
		initial_height = 0,
		max_radius = 3.5,
		offset_deviation = { { -4, -4 }, { 4, 4 } },
		repeat_count = 240,
		smoke_name = "artillery-smoke",
		speed_from_center = 0.05,
		speed_from_center_deviation = 0.005,
		type = "create-trivial-smoke"
	},
	{
		entity_name = "big-artillery-explosion",
		type = "create-entity"
	},
}
snipArtilleryProjectile.reveal_map = false

data:extend{snipArtilleryProjectile}