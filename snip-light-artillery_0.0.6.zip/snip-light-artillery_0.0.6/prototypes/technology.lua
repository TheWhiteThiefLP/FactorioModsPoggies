local rp_art_util = require("__rp_art_util__/rp_art_util");
local turret_art = require("__rp_artillery_turret_1_art__/artillery_turret_1");

data:extend(
{
{
	type = "technology",
	name = "snip-light-artillery",
	effects =
	{
		{
			type = "unlock-recipe",
			recipe = "snip-artillery-turret"
		},
		{
			type = "unlock-recipe",
			recipe = "snip-light-artillery-ammo"
		},
		{
			type = "unlock-recipe",
			recipe = "snip-artillery-wagon"
		},
		{
			type = "unlock-recipe",
			recipe = "artillery-targeting-remote"
		}
	},
	prerequisites = {"explosives", "steel-processing", "plastics", "military", "military-science-pack"},
	unit =
	{
		count = 100,
		ingredients = 
		{
			{"automation-science-pack", 1},
			{"logistic-science-pack", 1},
			{"military-science-pack", 1}
		},
		time = 30
	}
}
}
)

	rp_art_util:use_icon(data.raw["technology"]["snip-light-artillery"], turret_art);	