-- not local for this phase
textplates = require("textplates")

require("prototype.styles")
require("prototype.item-groups")
require("prototype.entity.entity")
require("prototype.item.item")
