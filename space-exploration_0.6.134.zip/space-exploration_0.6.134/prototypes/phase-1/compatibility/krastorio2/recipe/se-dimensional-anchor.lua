local data_util = require("data_util")

-- Integrate the K2 AI Core into the Dimensional Anchor recipe
data_util.replace_or_add_ingredient("se-dimensional-anchor","se-quantum-processor","ai-core",8)
