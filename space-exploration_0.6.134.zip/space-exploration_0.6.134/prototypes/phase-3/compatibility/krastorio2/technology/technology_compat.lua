local path = "prototypes/phase-3/compatibility/krastorio2/technology/"

require(path .. "power")
require(path .. "science")
require(path .. "equipment")
require(path .. "logistics")

require(path .. "infinite_techs")