if nach0 == nil then
    nach0 = {}
end
nach0.library = {}
nach0.name = "__nach0_library__"

require(nach0.name .. "/functions/recipes")
require(nach0.name .. "/functions/items")
require(nach0.name .. "/functions/tiles")
require(nach0.name .. "/functions/technologies")
require(nach0.name .. "/functions/log")