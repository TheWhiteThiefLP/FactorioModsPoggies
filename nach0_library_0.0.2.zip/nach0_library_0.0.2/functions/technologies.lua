nach0.technologies = {}

function nach0.technologies.removeRecipeUnlock(technology_name, recipe_name)
    if data.raw.technology[technology_name] then
        local unlocks = data.raw.technology[technology_name]
        for i,u in ipairs(unlocks) do
        end
    end
end