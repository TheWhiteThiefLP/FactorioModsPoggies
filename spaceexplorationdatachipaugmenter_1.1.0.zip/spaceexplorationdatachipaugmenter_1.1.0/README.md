# spaceexplorationdatachipaugmenter
Better description for Space Exploration data card