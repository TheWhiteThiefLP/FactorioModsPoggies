function aug_on_configuration_changed()
	game.print({"space-exploration-data-chip-augmenter.clickable-link"})
end
script.on_configuration_changed(aug_on_configuration_changed)