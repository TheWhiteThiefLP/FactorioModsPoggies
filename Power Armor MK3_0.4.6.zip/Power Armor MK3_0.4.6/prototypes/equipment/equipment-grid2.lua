data:extend(
{
  {
    type = "equipment-grid",
    name = "larger-equipment-grid",
    width = 14,
    height = 14,
    equipment_categories = {"armor"}
  },
  {
    type = "equipment-grid",
    name = "largest-equipment-grid",
    width = 20,
    height = 20,
    equipment_categories = {"armor"}
  },
}
)
