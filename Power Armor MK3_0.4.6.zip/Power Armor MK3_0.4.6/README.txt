Power-Armor-MK3
Mod for Factorio
Forum:      https://forums.factorio.com/viewtopic.php?f=190&t=47506
Mod portal: https://mods.factorio.com/mods/jimmy_1283/Power%20Armor%20MK3
Description: Adds bigger, better power armors; with a bigger grid (14x14)/(20x20) and larger inventory bonus (+50)/(+60), varients of the light and heavy armor with inventory bonus at the cost of protection, Night Vision MK2 with less desaturation affect and greater brightness, Energy shield MK3, a Fusion Battery, Portable Nuclear Reactor, an end game power source, and modified research to beef up Discharge Defense Equipment.
