data:extend(
    {
        {
            type = "item",
            name = "empty-shotgun-shell",
            icon = Graphics .. "empty-shotgun-shell.png",
            icon_mipmaps = 4,
            icon_size = 64,
            stack_size = 200,
            group = "intermediate-products",
            subgroup = "intermediate-product"
        }
    })
