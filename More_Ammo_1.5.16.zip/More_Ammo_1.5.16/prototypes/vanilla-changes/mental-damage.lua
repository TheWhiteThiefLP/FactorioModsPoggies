data:extend({{
    type = "damage-type",
    name = "mental"
}})
