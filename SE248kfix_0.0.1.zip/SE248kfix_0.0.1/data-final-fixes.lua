if mods["space-exploration"] then
    require('scripts/SE/data-final-fixes')
end