-- Copy any colors anyone changed from the base lamp
data.raw["lamp"]["nixie-tube"].signal_to_color_mapping = data.raw["lamp"]["small-lamp"].signal_to_color_mapping
data.raw["lamp"]["nixie-tube-alpha"].signal_to_color_mapping = data.raw["lamp"]["small-lamp"].signal_to_color_mapping
data.raw["lamp"]["nixie-tube-small"].signal_to_color_mapping = data.raw["lamp"]["small-lamp"].signal_to_color_mapping
