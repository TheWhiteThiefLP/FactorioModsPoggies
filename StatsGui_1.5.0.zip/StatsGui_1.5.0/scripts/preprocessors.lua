local preprocessors = {
  require("scripts.research-progress"),
}

return preprocessors
