# Stats GUI

A mod for Factorio that displays various statistics near the FPS/UPS indicator.

Download on the [mod portal](https://mods.factorio.com/mod/StatsGui).
