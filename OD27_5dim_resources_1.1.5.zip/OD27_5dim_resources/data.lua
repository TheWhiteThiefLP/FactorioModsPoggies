mods["5dim_resources"] = mods["OD27_5dim_resources"]

--Changes
require("prototypes.changes")

--Dust
require("prototypes.dust")

--Masher
require("prototypes.gen-masher")

--Furnace
require("prototypes.gen-electric-furnace")

--Furnace
require("prototypes.industrial-furnace")
require("prototypes.industrial-recipes")

--Recipe
require("prototypes.recipe-category")

--Tech
require("prototypes.tech")
