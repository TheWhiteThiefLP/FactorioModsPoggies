Can't be bothered to put down text plates or have a goldfish memory when it comes to minimap markers? Welcome aboard.
