> Place a signal receiver, connect to a power pole to see the signals being received.

Do you find it too much of a chore to place an electric pole (or hover nearby combinators) to see which signals are being sent or received?

If so, this mod is for you, it adds a laptop that you can hover, which shows you the same as a placed power pole would.

And yes, the laptop on the transmitter doesn't rotate with the gear, and the laptop on the receiver looks small in comparison.
