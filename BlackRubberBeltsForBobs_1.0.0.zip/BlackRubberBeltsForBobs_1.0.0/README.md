# Black Rubber Belts for Bob's Logistics

A Factorio mod that adds Black Ruber Belts versions Bob's Logistics belts
