# Rampant Arsenal

Adds a variety of turrets to wage war. Adds Additional Ammo Types, Landmines, Equipment, Capsules, Infinite Technologies.

# Credits

YuokiTani - for turret sprite sheets

# Graphics License

THE GRAPHICS INCLUDED UNDER yuokiTani FOLDERS BELONG TO YuokiTani AND PERMISSION FOR THERE
USE MUST BE SOUGHT FROM YuokiTani.

# Forum Post

https://forums.factorio.com/viewtopic.php?f=190&t=60626

# Features
Advanced Laser Turret - Shoots an electric beam that pierces through enemies and does AoE damage.
Lightning Turret - Able to shoot beams at many biters at once.
Cannon Turret - Shoots cannon shells that that works with standard cannon ammo.
Rapid Cannon Turret - Shoots cannon shells at a high rate of fire.
Shotgun Turret - Shoots shotgun shells for cone AoE damage.
Capsule Turret - Shoots poison, slowdown, grenade, cluster grenades, landmines, distractors, defenders, and destroyers
Advanced Flamethrower - Shoots flame at many biters at the same time.
Rocket Turret - Shoots homing rocket projectiles.
Rapid Rocket Turret - Rapidly Shoots homing rocket projectiles.
Medic Turret - For healing the area surrounding the turret
Gun Turret MkII - For when gun turrets need more damage, range, and rate of fire
Rifle turret - For a tier 0 turret for before you have completed any research
Reactive Mending Walls & Gates - When they take damage they emit a repair cloud around themselves
Reinforced concrete walls and gates
Power Armor Mk 3
nuclear train
stronger car and a nuclear version
stronger tank and a nuclear version
Oil burner for generating electricity

High Explosives: landmines, grenades, bullets, rockets, shotgun shells, cannon shells, and artillery shells
Incendiary: landmines, grenades, bullets, rockets, shotgun shells, cannon shells, and artillery shells
Bio: landmines, grenades, bullets, rockets, shotgun shells, cannon shells, and artillery shells
Nuclear: landmines, and artillery shells

Mortar - for large range player combat using the capsule launcher ammo
Minigun - for an upgraded version of the smg with increased damage, range, and rate of fire
Health Capsule - Restore Health of the user
Speed Booster Capsule - for early game speed boosts
Upgraded Rocket Launcher - Increased damage, range, and rate of fire

Belt Immunity Equipment
Personal equipment tier 3 generator, battery, shield
Personal defense cannon, shotgun, lightning, bullets, and slowing equipment

Napalm - for an upgraded liquid to be used in fluid turrets

Adds Infinite Technology for the characters health
Adds Infinite Technology associated with each turret type and ammo type

### Four Technology Branches

High Explosives for AoE

Bio Weapons for Damage Over Time

Incendiary Weapons for combo over AoE and Damage over Time

Regeneration for weapons that provide healing, speed boosts, or mend themselves over time

# Version History

0.16.0 -
- Initial Release
