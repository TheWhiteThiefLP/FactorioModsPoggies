data:extend({
  {
    type = "bool-setting",
    name = "flow-control-new-group",
    setting_type = "startup",
    default_value = true,
    order = "a"
  },
  {
    type = "bool-setting",
    name = "flow-control-revert-to-normal-pipe",
    setting_type = "startup",
    default_value = true,
    order = "b"
  }
})