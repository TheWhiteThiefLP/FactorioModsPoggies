if not mods["space-exploration"] then -- SE already has its own version
  data:extend({
    {
      type = "virtual-signal",
      name = "aai-select-icon",
      icon = "__core__/graphics/icons/mip/select-icon-black.png",
      icon_size = 40,
      subgroup = "virtual-signal",
      order = "z-z-o"
    }
  })
end
