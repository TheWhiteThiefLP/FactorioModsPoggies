local styles = data.raw["gui-style"].default

styles.aai_signal_transmission_titlebar_flow = {
  type = "horizontal_flow_style",
  horizontal_spacing = 8,
}

styles.aai_signal_transmission_titlebar_drag_handle = {
  type = "empty_widget_style",
  parent = "draggable_space",
  left_margin = 4,
  right_margin = 4,
  height = 24,
  horizontally_stretchable = "on",
}

styles.aai_signal_transmission_transceiver_invisible_frame =
{
  type = "frame_style",
  parent = "container_invisible_frame_with_title",
  bottom_padding = 0,
  vertical_flow_style =
  {
    type = "vertical_flow_style",
    vertical_spacing = 4,
    horizontal_align = "left"
  }
}

styles.aai_icon_selector_button =
{
  type = "button_style",
  parent = "button",
  width = 28,
  height = 28,
  padding = 0,
  top_margin = 1,
}
