# FactorioSpaceExplorationCMEcombinator
Factorio mod for Space Exploration that adds a combinator that can let you react to upcoming CMEs with circuitry. Outputs the time and power of the next CME on that surface.
