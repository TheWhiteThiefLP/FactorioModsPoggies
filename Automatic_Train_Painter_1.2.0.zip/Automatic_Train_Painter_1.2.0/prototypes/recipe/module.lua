data:extend({
	{
		type = "recipe",
		name = "manual-color-module",
		enabled = false,
		ingredients = {
			{"electronic-circuit", 1},
		},
		result = "manual-color-module"
	}
})