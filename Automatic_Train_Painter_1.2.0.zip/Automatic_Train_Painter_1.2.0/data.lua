require('prototypes.equipment-grid')
require('prototypes.item.module')
require('prototypes.recipe.module')
require('prototypes.technology.module')