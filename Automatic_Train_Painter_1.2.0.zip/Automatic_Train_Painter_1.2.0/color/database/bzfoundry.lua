bzfoundry={
    ['coke']                                                ={r=034, g=032, b=030, a=127}, --Coke
    ['electric-foundry']                                    ={r=133, g=085, b=040, a=127}, --Electric foundry
    ['foundry']                                             ={r=118, g=100, b=078, a=127}, --Foundry
}