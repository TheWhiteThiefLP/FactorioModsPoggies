bobmodules={
    ['beacon-2']                                            ={r=226, g=082, b=004, a=127}, --Beacon 2
    ['beacon-3']                                            ={r=226, g=082, b=004, a=127}, --Beacon 3
    ['effectivity-module-2-bobm']                           ={r=249, g=255, b=000, a=127}, --Effectivity Module 2
    ['effectivity-module-3-bobm']                           ={r=249, g=255, b=000, a=127}, --Effectivity Module 3
    ['effectivity-module-4']                                ={r=249, g=255, b=000, a=127}, --Effectivity Module 4
    ['effectivity-module-5']                                ={r=249, g=255, b=000, a=127}, --Effectivity Module 5
    ['effectivity-module-6']                                ={r=249, g=255, b=000, a=127}, --Effectivity Module 6
    ['effectivity-module-7']                                ={r=249, g=255, b=000, a=127}, --Effectivity Module 7
    ['effectivity-module-8']                                ={r=249, g=255, b=000, a=127}, --Effectivity Module 8
    ['effectivity-module-bobm']                             ={r=249, g=255, b=000, a=127}, --Effectivity Module 1
    ['effectivity-processor']                               ={r=073, g=163, b=000, a=127}, --Effectivity circuit board
    ['effectivity-processor-2']                             ={r=073, g=163, b=000, a=127}, --Effectivity logic board
    ['effectivity-processor-3']                             ={r=073, g=163, b=000, a=127}, --Effectivity processor board
    ['god-module-1']                                        ={r=157, g=155, b=145, a=127}, --God module 1
    ['god-module-2']                                        ={r=157, g=155, b=145, a=127}, --God module 2
    ['god-module-3']                                        ={r=157, g=155, b=145, a=127}, --God module 3
    ['god-module-4']                                        ={r=157, g=155, b=145, a=127}, --God module 4
    ['god-module-5']                                        ={r=157, g=155, b=145, a=127}, --God module 5
    ['green-module-1']                                      ={r=073, g=163, b=000, a=127}, --Green module 1
    ['green-module-2']                                      ={r=073, g=163, b=000, a=127}, --Green module 2
    ['green-module-3']                                      ={r=073, g=163, b=000, a=127}, --Green module 3
    ['green-module-4']                                      ={r=073, g=163, b=000, a=127}, --Green module 4
    ['green-module-5']                                      ={r=073, g=163, b=000, a=127}, --Green module 5
    ['green-module-6']                                      ={r=073, g=163, b=000, a=127}, --Green module 6
    ['green-module-7']                                      ={r=073, g=163, b=000, a=127}, --Green module 7
    ['green-module-8']                                      ={r=073, g=163, b=000, a=127}, --Green module 8
    ['lab-module']                                          ={r=092, g=105, b=226, a=127}, --Modules lab
    ['module-case']                                         ={r=156, g=156, b=156, a=127}, --Module case
    ['module-circuit-board']                                ={r=002, g=154, b=000, a=127}, --Module main board
    ['module-contact']                                      ={r=255, g=163, b=000, a=127}, --Module contact
    ['module-processor-board']                              ={r=255, g=250, b=227, a=127}, --Basic module board
    ['module-processor-board-2']                            ={r=240, g=132, b=038, a=127}, --Module logic board
    ['module-processor-board-3']                            ={r=240, g=132, b=038, a=127}, --Module processor board
    ['pollution-clean-module-1']                            ={r=047, g=112, b=085, a=127}, --Pollution Cleaning Module 1
    ['pollution-clean-module-2']                            ={r=047, g=112, b=085, a=127}, --Pollution Cleaning Module 2
    ['pollution-clean-module-3']                            ={r=047, g=112, b=085, a=127}, --Pollution Cleaning Module 3
    ['pollution-clean-module-4']                            ={r=047, g=112, b=085, a=127}, --Pollution Cleaning Module 4
    ['pollution-clean-module-5']                            ={r=047, g=112, b=085, a=127}, --Pollution Cleaning Module 5
    ['pollution-clean-module-6']                            ={r=047, g=112, b=085, a=127}, --Pollution Cleaning Module 6
    ['pollution-clean-module-7']                            ={r=047, g=112, b=085, a=127}, --Pollution Cleaning Module 7
    ['pollution-clean-module-8']                            ={r=047, g=112, b=085, a=127}, --Pollution Cleaning Module 8
    ['pollution-clean-processor']                           ={r=047, g=112, b=085, a=127}, --Pollution cleaning circuit board
    ['pollution-clean-processor-2']                         ={r=047, g=112, b=085, a=127}, --Pollution cleaning logic board
    ['pollution-clean-processor-3']                         ={r=047, g=112, b=085, a=127}, --Pollution cleaning processor board
    ['pollution-create-module-1']                           ={r=119, g=077, b=045, a=127}, --Pollution Producing Module 1
    ['pollution-create-module-2']                           ={r=119, g=077, b=045, a=127}, --Pollution Producing Module 2
    ['pollution-create-module-3']                           ={r=119, g=077, b=045, a=127}, --Pollution Producing Module 3
    ['pollution-create-module-4']                           ={r=119, g=077, b=045, a=127}, --Pollution Producing Module 4
    ['pollution-create-module-5']                           ={r=119, g=077, b=045, a=127}, --Pollution Producing Module 5
    ['pollution-create-module-6']                           ={r=119, g=077, b=045, a=127}, --Pollution Producing Module 6
    ['pollution-create-module-7']                           ={r=119, g=077, b=045, a=127}, --Pollution Producing Module 7
    ['pollution-create-module-8']                           ={r=119, g=077, b=045, a=127}, --Pollution Producing Module 8
    ['pollution-create-processor']                          ={r=119, g=077, b=045, a=127}, --Pollution producing circuit board
    ['pollution-create-processor-2']                        ={r=119, g=077, b=045, a=127}, --Pollution producing logic board
    ['pollution-create-processor-3']                        ={r=119, g=077, b=045, a=127}, --Pollution producing processor board
    ['productivity-module-2-bobm']                          ={r=196, g=004, b=000, a=127}, --Productivity Module 2
    ['productivity-module-3-bobm']                          ={r=196, g=004, b=000, a=127}, --Productivity Module 3
    ['productivity-module-4']                               ={r=196, g=004, b=000, a=127}, --Productivity Module 4
    ['productivity-module-5']                               ={r=196, g=004, b=000, a=127}, --Productivity Module 5
    ['productivity-module-6']                               ={r=196, g=004, b=000, a=127}, --Productivity Module 6
    ['productivity-module-7']                               ={r=196, g=004, b=000, a=127}, --Productivity Module 7
    ['productivity-module-8']                               ={r=196, g=004, b=000, a=127}, --Productivity Module 8
    ['productivity-module-bobm']                            ={r=196, g=004, b=000, a=127}, --Productivity Module 1
    ['productivity-processor']                              ={r=186, g=024, b=236, a=127}, --Productivity circuit board
    ['productivity-processor-2']                            ={r=186, g=024, b=236, a=127}, --Productivity logic board
    ['productivity-processor-3']                            ={r=186, g=024, b=236, a=127}, --Productivity processor board
    ['raw-productivity-module-1']                           ={r=186, g=024, b=236, a=127}, --Raw productivity module 1
    ['raw-productivity-module-2']                           ={r=186, g=024, b=236, a=127}, --Raw productivity module 2
    ['raw-productivity-module-3']                           ={r=186, g=024, b=236, a=127}, --Raw productivity module 3
    ['raw-productivity-module-4']                           ={r=186, g=024, b=236, a=127}, --Raw productivity module 4
    ['raw-productivity-module-5']                           ={r=186, g=024, b=236, a=127}, --Raw productivity module 5
    ['raw-productivity-module-6']                           ={r=186, g=024, b=236, a=127}, --Raw productivity module 6
    ['raw-productivity-module-7']                           ={r=186, g=024, b=236, a=127}, --Raw productivity module 7
    ['raw-productivity-module-8']                           ={r=186, g=024, b=236, a=127}, --Raw productivity module 8
    ['raw-speed-module-1']                                  ={r=000, g=235, b=241, a=127}, --Raw speed module 1
    ['raw-speed-module-2']                                  ={r=000, g=235, b=241, a=127}, --Raw speed module 2
    ['raw-speed-module-3']                                  ={r=000, g=235, b=241, a=127}, --Raw speed module 3
    ['raw-speed-module-4']                                  ={r=000, g=235, b=241, a=127}, --Raw speed module 4
    ['raw-speed-module-5']                                  ={r=000, g=235, b=241, a=127}, --Raw speed module 5
    ['raw-speed-module-6']                                  ={r=000, g=235, b=241, a=127}, --Raw speed module 6
    ['raw-speed-module-7']                                  ={r=000, g=235, b=241, a=127}, --Raw speed module 7
    ['raw-speed-module-8']                                  ={r=000, g=235, b=241, a=127}, --Raw speed module 8
    ['speed-module-2-bobm']                                 ={r=000, g=087, b=255, a=127}, --Speed Module 2
    ['speed-module-3-bobm']                                 ={r=000, g=087, b=255, a=127}, --Speed Module 3
    ['speed-module-4']                                      ={r=000, g=087, b=255, a=127}, --Speed Module 4
    ['speed-module-5']                                      ={r=000, g=087, b=255, a=127}, --Speed Module 5
    ['speed-module-6']                                      ={r=000, g=087, b=255, a=127}, --Speed Module 6
    ['speed-module-7']                                      ={r=000, g=087, b=255, a=127}, --Speed Module 7
    ['speed-module-8']                                      ={r=000, g=087, b=255, a=127}, --Speed Module 8
    ['speed-module-bobm']                                   ={r=000, g=087, b=255, a=127}, --Speed Module 1
    ['speed-processor']                                     ={r=000, g=087, b=255, a=127}, --Speed circuit board
    ['speed-processor-2']                                   ={r=000, g=087, b=255, a=127}, --Speed logic board
    ['speed-processor-3']                                   ={r=000, g=087, b=255, a=127}, --Speed processor board

}

bobmodules_filters={
    "effectivity-module",
    "effectivity-module-2",
    "effectivity-module-3",
    "productivity-module",
    "productivity-module-2",
    "productivity-module-3",
    "speed-module",
    "speed-module-2",
    "speed-module-3",
}