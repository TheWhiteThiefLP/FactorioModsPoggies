DarkMatterReplicators={
    ['dark-matter-scoop']                                   ={r=125, g=035, b=134, a=127}, --Dark matter scoop
    ['dark-matter-transducer']                              ={r=176, g=052, b=178, a=127}, --Dark matter transducer
    ['matter-conduit']                                      ={r=172, g=147, b=188, a=127}, --Matter conduit
    ['replication-lab']                                     ={r=210, g=147, b=037, a=127}, --Replication lab
    ['replicator-1']                                        ={r=079, g=112, b=074, a=127}, --Simple replicator
    ['replicator-2']                                        ={r=188, g=192, b=113, a=127}, --Element replicator
    ['replicator-3']                                        ={r=142, g=040, b=148, a=127}, --Chemical replicator
    ['replicator-4']                                        ={r=255, g=000, b=077, a=127}, --Device replicator
    ['replicator-5']                                        ={r=000, g=000, b=255, a=127}, --Advanced replicator
    ['tenemut']                                             ={r=155, g=079, b=151, a=127}, --Tenemut
}