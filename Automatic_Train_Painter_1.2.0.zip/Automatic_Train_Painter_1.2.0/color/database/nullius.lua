nullius={
    ['nullius-acid-boric']                                  ={r=255, g=145, b=142, a=127}, --Boric acid
    ['nullius-acrylic-fiber']                               ={r=076, g=218, b=206, a=127}, --Acrylic fiber
    ['nullius-air-filter-1']                                ={r=161, g=042, b=001, a=127}, --Air filter 1
    ['nullius-air-filter-2']                                ={r=161, g=042, b=001, a=127}, --Air filter 2
    ['nullius-air-filter-3']                                ={r=161, g=042, b=001, a=127}, --Air filter 3
    ['nullius-algaculture-drone']                           ={r=134, g=206, b=034, a=127}, --Algaculture drone
    ['nullius-algaculture-remote']                          ={r=134, g=206, b=034, a=127}, --Algaculture remote
    ['nullius-algae']                                       ={r=134, g=206, b=034, a=127}, --Algae
    ['nullius-algae-genome']                                ={r=134, g=206, b=034, a=127}, --Algae genome
    ['nullius-algae-progenitor']                            ={r=055, g=167, b=140, a=127}, --Algae progenitor
    ['nullius-algae-spore']                                 ={r=134, g=206, b=034, a=127}, --Algae spore
    ['nullius-alumina']                                     ={r=101, g=140, b=216, a=127}, --Alumina
    ['nullius-aluminum-carbide']                            ={r=068, g=063, b=076, a=127}, --Aluminum carbide
    ['nullius-aluminum-hydroxide']                          ={r=185, g=147, b=030, a=127}, --Aluminum hydroxide
    ['nullius-aluminum-ingot']                              ={r=192, g=174, b=053, a=127}, --Aluminum ingot
    ['nullius-aluminum-plate']                              ={r=192, g=174, b=053, a=127}, --Aluminum plate
    ['nullius-aluminum-rod']                                ={r=206, g=185, b=052, a=127}, --Aluminum rod
    ['nullius-aluminum-sheet']                              ={r=192, g=174, b=053, a=127}, --Aluminum sheet
    ['nullius-aluminum-wire']                               ={r=192, g=174, b=053, a=127}, --Aluminum wire
    ['nullius-android-1']                                   ={r=255, g=135, b=000, a=127}, --Android 1
    ['nullius-android-2']                                   ={r=073, g=236, b=053, a=127}, --Android 2
    ['nullius-antenna']                                     ={r=163, g=160, b=143, a=127}, --Antenna
    ['nullius-antimatter']                                  ={r=224, g=000, b=178, a=127}, --Antimatter
    ['nullius-antimatter-trap']                             ={r=199, g=046, b=037, a=127}, --Antimatter trap
    ['nullius-aquaculture-drone']                           ={r=191, g=226, b=105, a=127}, --Aquaculture drone
    ['nullius-aquaculture-remote']                          ={r=191, g=226, b=105, a=127}, --Aquaculture remote
    ['nullius-arboriculture-drone']                         ={r=088, g=131, b=000, a=127}, --Arboriculture drone
    ['nullius-arboriculture-remote']                        ={r=088, g=131, b=000, a=127}, --Arboriculture remote
    ['nullius-arithmetic-circuit']                          ={r=052, g=175, b=198, a=127}, --Arithmetic circuit
    ['nullius-armor-plate']                                 ={r=215, g=215, b=215, a=127}, --Armor plate
    ['nullius-arthropod']                                   ={r=255, g=128, b=007, a=127}, --Arthropod
    ['nullius-arthropod-egg']                               ={r=255, g=128, b=007, a=127}, --Arthropod egg
    ['nullius-arthropod-genome']                            ={r=255, g=128, b=007, a=127}, --Arthropod genome
    ['nullius-arthropod-progenitor']                        ={r=168, g=146, b=046, a=127}, --Arthropod progenitor
    ['nullius-asteroid-miner-1']                            ={r=158, g=047, b=086, a=127}, --Asteroid miner 1
    ['nullius-asteroid-miner-2']                            ={r=115, g=245, b=216, a=127}, --Asteroid miner 2
    ['nullius-astronomy-pack']                              ={r=100, g=109, b=138, a=127}, --Astronomical data
    ['nullius-backup-turbine-1']                            ={r=021, g=091, b=017, a=127}, --Backup turbine 1
    ['nullius-backup-turbine-2']                            ={r=071, g=164, b=056, a=127}, --Backup turbine 2
    ['nullius-backup-turbine-3']                            ={r=127, g=222, b=109, a=127}, --Backup turbine 3
    ['nullius-bacteria-genome']                             ={r=255, g=167, b=067, a=127}, --Bacteria genome
    ['nullius-barrel-pump-1']                               ={r=085, g=115, b=115, a=127}, --Barrel pump 1
    ['nullius-barrel-pump-2']                               ={r=120, g=050, b=028, a=127}, --Barrel pump 2
    ['nullius-battery-1']                                   ={r=093, g=111, b=124, a=127}, --Battery 1
    ['nullius-battery-2']                                   ={r=093, g=111, b=124, a=127}, --Battery 2
    ['nullius-battery-3']                                   ={r=093, g=111, b=124, a=127}, --Battery 3
    ['nullius-bauxite']                                     ={r=206, g=163, b=005, a=127}, --Bauxite
    ['nullius-beacon-1']                                    ={r=187, g=187, b=086, a=127}, --Small beacon 1
    ['nullius-beacon-2']                                    ={r=086, g=110, b=216, a=127}, --Small beacon 2
    ['nullius-beacon-3']                                    ={r=152, g=059, b=019, a=127}, --Small beacon 3
    ['nullius-bearing']                                     ={r=206, g=192, b=129, a=127}, --Bearing
    ['nullius-belt-1']                                      ={r=255, g=165, b=000, a=127}, --Belt 1
    ['nullius-belt-2']                                      ={r=255, g=011, b=000, a=127}, --Belt 2
    ['nullius-belt-3']                                      ={r=000, g=224, b=253, a=127}, --Belt 3
    ['nullius-belt-4']                                      ={r=000, g=221, b=050, a=127}, --Belt 4
    ['nullius-biochemistry-pack']                           ={r=255, g=004, b=004, a=127}, --Biochemistry sample
    ['nullius-biodiesel-canister']                          ={r=255, g=169, b=089, a=127}, --Biodiesel canister
    ['nullius-biology-lab']                                 ={r=060, g=164, b=053, a=127}, --Biology laboratory
    ['nullius-black-concrete']                              ={r=030, g=030, b=030, a=127}, --Black concrete
    ['nullius-blue-concrete']                               ={r=000, g=095, b=184, a=127}, --Blue concrete
    ['nullius-boron']                                       ={r=118, g=100, b=082, a=127}, --Boron
    ['nullius-botany-pack']                                 ={r=088, g=131, b=000, a=127}, --Botany specimen
    ['nullius-boxer']                                       ={r=125, g=002, b=001, a=127}, --Boxer
    ['nullius-bpa']                                         ={r=235, g=244, b=255, a=127}, --BPA
    ['nullius-breeder-cell']                                ={r=000, g=219, b=253, a=127}, --Breeder cell
    ['nullius-brown-concrete']                              ={r=168, g=067, b=000, a=127}, --Brown concrete
    ['nullius-calcium']                                     ={r=235, g=233, b=233, a=127}, --Calcium
    ['nullius-calcium-chloride']                            ={r=203, g=228, b=039, a=127}, --Calcium chloride
    ['nullius-canister']                                    ={r=187, g=187, b=187, a=127}, --Empty canister
    ['nullius-capacitor']                                   ={r=093, g=111, b=124, a=127}, --Capacitor
    ['nullius-car-1']                                       ={r=216, g=118, b=000, a=127}, --Car 1
    ['nullius-car-2']                                       ={r=255, g=114, b=039, a=127}, --Car 2
    ['nullius-car-3']                                       ={r=106, g=127, b=192, a=127}, --Car 3
    ['nullius-carbon-composite']                            ={r=029, g=029, b=031, a=127}, --Carbon composite
    ['nullius-carbon-fiber']                                ={r=029, g=029, b=031, a=127}, --Carbon fiber
    ['nullius-cargo-wagon-1']                               ={r=187, g=187, b=122, a=127}, --Cargo wagon 1
    ['nullius-cargo-wagon-2']                               ={r=175, g=150, b=132, a=127}, --Cargo wagon 2
    ['nullius-cargo-wagon-3']                               ={r=211, g=211, b=211, a=127}, --Cargo wagon 3
    ['nullius-cellulose']                                   ={r=127, g=064, b=025, a=127}, --Cellulose
    ['nullius-cement']                                      ={r=149, g=047, b=000, a=127}, --Cement
    ['nullius-ceramic-powder']                              ={r=255, g=199, b=164, a=127}, --Ceramic powder
    ['nullius-charger-1']                                   ={r=119, g=119, b=119, a=127}, --Charger 1
    ['nullius-charger-2']                                   ={r=119, g=119, b=119, a=127}, --Charger 2
    ['nullius-charger-3']                                   ={r=070, g=079, b=077, a=127}, --Charger 3
    ['nullius-charger-4']                                   ={r=070, g=079, b=077, a=127}, --Charger 4
    ['nullius-chassis-1']                                   ={r=244, g=112, b=000, a=127}, --Chassis 1
    ['nullius-chassis-2']                                   ={r=239, g=120, b=000, a=127}, --Chassis 2
    ['nullius-chassis-3']                                   ={r=255, g=135, b=000, a=127}, --Chassis 3
    ['nullius-chassis-4']                                   ={r=255, g=135, b=000, a=127}, --Chassis 4
    ['nullius-chassis-5']                                   ={r=255, g=135, b=000, a=127}, --Chassis 5
    ['nullius-chassis-6']                                   ={r=060, g=164, b=053, a=127}, --Chassis 6
    ['nullius-checkpoint']                                  ={r=000, g=018, b=255, a=127}, --Checkpoint
    ['nullius-chemical-pack']                               ={r=032, g=239, b=041, a=127}, --Chemical sample
    ['nullius-chemical-plant-1']                            ={r=132, g=132, b=085, a=127}, --Chemical plant 1
    ['nullius-chemical-plant-2']                            ={r=132, g=118, b=132, a=127}, --Chemical plant 2
    ['nullius-chemical-plant-3']                            ={r=217, g=142, b=000, a=127}, --Chemical plant 3
    ['nullius-chimney-1']                                   ={r=098, g=057, b=043, a=127}, --Chimney 1
    ['nullius-chimney-2']                                   ={r=098, g=057, b=043, a=127}, --Chimney 2
    ['nullius-climatology-pack']                            ={r=032, g=233, b=255, a=127}, --Climate sample
    ['nullius-combustion-chamber-1']                        ={r=250, g=232, b=136, a=127}, --Combustion chamber 1
    ['nullius-combustion-chamber-2']                        ={r=250, g=232, b=136, a=127}, --Combustion chamber 2
    ['nullius-combustion-chamber-3']                        ={r=250, g=232, b=136, a=127}, --Combustion chamber 3
    ['nullius-construction-bot-1']                          ={r=255, g=201, b=000, a=127}, --Construction bot 1
    ['nullius-construction-bot-2']                          ={r=234, g=017, b=000, a=127}, --Construction bot 2
    ['nullius-construction-bot-3']                          ={r=024, g=132, b=211, a=127}, --Construction bot 3
    ['nullius-construction-bot-4']                          ={r=060, g=164, b=053, a=127}, --Construction bot 4
    ['nullius-copper-ingot']                                ={r=156, g=073, b=052, a=127}, --Copper ingot
    ['nullius-copper-sheet']                                ={r=146, g=071, b=049, a=127}, --Copper sheet
    ['nullius-copper-wire']                                 ={r=181, g=093, b=070, a=127}, --Copper wire
    ['nullius-crucible']                                    ={r=235, g=244, b=255, a=127}, --Crucible
    ['nullius-crushed-bauxite']                             ={r=197, g=168, b=010, a=127}, --Crushed bauxite
    ['nullius-crushed-copper-ore']                          ={r=168, g=082, b=056, a=127}, --Crushed copper ore
    ['nullius-crushed-iron-ore']                            ={r=116, g=149, b=174, a=127}, --Crushed iron ore
    ['nullius-crushed-limestone']                           ={r=218, g=157, b=114, a=127}, --Crushed limestone
    ['nullius-crushed-uranium-ore']                         ={r=022, g=079, b=020, a=127}, --Crushed uranium ore
    ['nullius-crusher-1']                                   ={r=046, g=062, b=064, a=127}, --Crusher 1
    ['nullius-crusher-2']                                   ={r=048, g=077, b=120, a=127}, --Crusher 2
    ['nullius-crusher-3']                                   ={r=143, g=145, b=161, a=127}, --Crusher 3
    ['nullius-demolition-drone']                            ={r=254, g=000, b=005, a=127}, --Demolition drone
    ['nullius-demolition-remote']                           ={r=254, g=000, b=005, a=127}, --Demolition remote
    ['nullius-dendrology-pack']                             ={r=088, g=131, b=000, a=127}, --Dendrology specimen
    ['nullius-distillery-1']                                ={r=206, g=158, b=070, a=127}, --Distillery 1
    ['nullius-distillery-2']                                ={r=165, g=174, b=228, a=127}, --Distillery 2
    ['nullius-distillery-3']                                ={r=245, g=082, b=000, a=127}, --Distillery 3
    ['nullius-drone-carrier-1']                             ={r=086, g=110, b=216, a=127}, --Drone carrier 1
    ['nullius-drone-carrier-2']                             ={r=255, g=202, b=000, a=127}, --Drone carrier 2
    ['nullius-drone-launcher-1']                            ={r=086, g=110, b=216, a=127}, --Drone launcher 1
    ['nullius-drone-launcher-2']                            ={r=255, g=202, b=000, a=127}, --Drone launcher 2
    ['nullius-efficiency-module-1']                         ={r=100, g=244, b=042, a=127}, --Efficiency module 1
    ['nullius-efficiency-module-2']                         ={r=100, g=244, b=042, a=127}, --Efficiency module 2
    ['nullius-efficiency-module-3']                         ={r=100, g=244, b=042, a=127}, --Efficiency module 3
    ['nullius-electrical-pack']                             ={r=164, g=000, b=248, a=127}, --Electrical prototype
    ['nullius-enriched-uranium']                            ={r=125, g=255, b=066, a=127}, --Enriched uranium
    ['nullius-entomology-drone']                            ={r=216, g=115, b=086, a=127}, --Entomology drone
    ['nullius-entomology-remote']                           ={r=216, g=115, b=086, a=127}, --Entomology remote
    ['nullius-eutectic-salt']                               ={r=046, g=139, b=233, a=127}, --Eutectic salt
    ['nullius-excavation-drone']                            ={r=000, g=146, b=206, a=127}, --Excavation drone
    ['nullius-excavation-remote']                           ={r=000, g=146, b=206, a=127}, --Excavation remote
    ['nullius-explosive']                                   ={r=255, g=042, b=000, a=127}, --Explosive
    ['nullius-extractor-1']                                 ={r=239, g=089, b=053, a=127}, --Extractor 1
    ['nullius-extractor-2']                                 ={r=246, g=000, b=048, a=127}, --Extractor 2
    ['nullius-fabrication-tool-1']                          ={r=255, g=203, b=000, a=127}, --Fabrication tool 1
    ['nullius-fabrication-tool-2']                          ={r=255, g=000, b=000, a=127}, --Fabrication tool 2
    ['nullius-fabrication-tool-3']                          ={r=000, g=127, b=253, a=127}, --Fabrication tool 3
    ['nullius-fertilizer']                                  ={r=127, g=064, b=025, a=127}, --Fertilizer
    ['nullius-fiberglass']                                  ={r=000, g=098, b=158, a=127}, --Fiberglass
    ['nullius-filter-1']                                    ={r=029, g=029, b=031, a=127}, --Filter 1
    ['nullius-filter-2']                                    ={r=149, g=134, b=014, a=127}, --Filter 2
    ['nullius-filter-inserter-2']                           ={r=154, g=055, b=240, a=127}, --Filter inserter 2
    ['nullius-filter-inserter-3']                           ={r=053, g=193, b=251, a=127}, --Filter inserter 3
    ['nullius-filter-inserter-4']                           ={r=060, g=164, b=053, a=127}, --Filter inserter 4
    ['nullius-fish']                                        ={r=191, g=226, b=105, a=127}, --Fish
    ['nullius-fish-egg']                                    ={r=191, g=226, b=105, a=127}, --Fish egg
    ['nullius-fish-genome']                                 ={r=191, g=226, b=105, a=127}, --Fish genome
    ['nullius-fish-progenitor']                             ={r=172, g=251, b=193, a=127}, --Fish progenitor
    ['nullius-fission-cell']                                ={r=027, g=248, b=000, a=127}, --Fission cell
    ['nullius-flotation-cell-1']                            ={r=132, g=132, b=085, a=127}, --Flotation cell 1
    ['nullius-flotation-cell-2']                            ={r=048, g=077, b=120, a=127}, --Flotation cell 2
    ['nullius-flotation-cell-3']                            ={r=149, g=149, b=149, a=127}, --Flotation cell 3
    ['nullius-fluid-wagon-1']                               ={r=187, g=187, b=122, a=127}, --Fluid wagon 1
    ['nullius-fluid-wagon-2']                               ={r=175, g=150, b=132, a=127}, --Fluid wagon 2
    ['nullius-fluid-wagon-3']                               ={r=211, g=211, b=211, a=127}, --Fluid wagon 3
    ['nullius-foundry-1']                                   ={r=156, g=036, b=000, a=127}, --Foundry 1
    ['nullius-foundry-2']                                   ={r=156, g=036, b=000, a=127}, --Foundry 2
    ['nullius-foundry-3']                                   ={r=156, g=036, b=000, a=127}, --Foundry 3
    ['nullius-fusion-cell']                                 ={r=091, g=000, b=255, a=127}, --Fusion cell
    ['nullius-geology-pack']                                ={r=255, g=173, b=026, a=127}, --Mineral sample
    ['nullius-geothermal-plant-1']                          ={r=077, g=178, b=206, a=127}, --Geothermal plant 1
    ['nullius-geothermal-plant-2']                          ={r=086, g=110, b=216, a=127}, --Geothermal plant 2
    ['nullius-geothermal-plant-3']                          ={r=161, g=058, b=015, a=127}, --Geothermal plant 3
    ['nullius-glass']                                       ={r=143, g=145, b=161, a=127}, --Glass
    ['nullius-glass-fiber']                                 ={r=182, g=155, b=119, a=127}, --Glass fiber
    ['nullius-graphene']                                    ={r=176, g=178, b=176, a=127}, --Graphene
    ['nullius-graphite']                                    ={r=000, g=000, b=000, a=127}, --Graphite
    ['nullius-grass']                                       ={r=088, g=131, b=000, a=127}, --Grass
    ['nullius-grass-genome']                                ={r=088, g=131, b=000, a=127}, --Grass genome
    ['nullius-grass-progenitor']                            ={r=055, g=167, b=140, a=127}, --Grass progenitor
    ['nullius-grass-seed']                                  ={r=088, g=131, b=000, a=127}, --Grass seed
    ['nullius-gravel']                                      ={r=162, g=139, b=115, a=127}, --Gravel
    ['nullius-green-concrete']                              ={r=000, g=180, b=022, a=127}, --Green concrete
    ['nullius-grid-battery-1']                              ={r=187, g=187, b=086, a=127}, --Grid battery 1
    ['nullius-grid-battery-2']                              ={r=089, g=250, b=255, a=127}, --Grid battery 2
    ['nullius-grid-battery-3']                              ={r=178, g=120, b=163, a=127}, --Grid battery 3
    ['nullius-guide-drone-bauxite']                         ={r=206, g=163, b=005, a=127}, --Guide drone (bauxite)
    ['nullius-guide-drone-copper']                          ={r=238, g=079, b=058, a=127}, --Guide drone (copper)
    ['nullius-guide-drone-iron']                            ={r=070, g=124, b=155, a=127}, --Guide drone (iron)
    ['nullius-guide-drone-limestone']                       ={r=255, g=202, b=165, a=127}, --Guide drone (limestone)
    ['nullius-guide-drone-sandstone']                       ={r=221, g=115, b=021, a=127}, --Guide drone (sandstone)
    ['nullius-guide-drone-uranium']                         ={r=097, g=205, b=000, a=127}, --Guide drone (uranium)
    ['nullius-guide-remote-bauxite']                        ={r=206, g=163, b=005, a=127}, --Guide remote (bauxite)
    ['nullius-guide-remote-copper']                         ={r=238, g=079, b=058, a=127}, --Guide remote (copper)
    ['nullius-guide-remote-iron']                           ={r=070, g=124, b=155, a=127}, --Guide remote (iron)
    ['nullius-guide-remote-limestone']                      ={r=255, g=202, b=165, a=127}, --Guide remote (limestone)
    ['nullius-guide-remote-sandstone']                      ={r=221, g=115, b=021, a=127}, --Guide remote (sandstone)
    ['nullius-guide-remote-uranium']                        ={r=097, g=205, b=000, a=127}, --Guide remote (uranium)
    ['nullius-gun']                                         ={r=088, g=079, b=068, a=127}, --Gun
    ['nullius-gypsum']                                      ={r=226, g=226, b=155, a=127}, --Gypsum
    ['nullius-hangar-1']                                    ={r=169, g=095, b=097, a=127}, --Hangar 1
    ['nullius-hangar-2']                                    ={r=186, g=161, b=139, a=127}, --Hangar 2
    ['nullius-hangar-3']                                    ={r=067, g=125, b=089, a=127}, --Hangar 3
    ['nullius-hangar-4']                                    ={r=067, g=125, b=089, a=127}, --Hangar 4
    ['nullius-hard-glass']                                  ={r=166, g=168, b=168, a=127}, --Hard glass
    ['nullius-haste-module-1']                              ={r=000, g=021, b=255, a=127}, --Haste module 1
    ['nullius-haste-module-2']                              ={r=000, g=021, b=255, a=127}, --Haste module 2
    ['nullius-haste-module-3']                              ={r=000, g=021, b=255, a=127}, --Haste module 3
    ['nullius-haste-module-4']                              ={r=000, g=021, b=255, a=127}, --Haste module 4
    ['nullius-hazard-concrete']                             ={r=255, g=195, b=054, a=127}, --Hazard concrete
    ['nullius-heat-pipe-1']                                 ={r=086, g=110, b=216, a=127}, --Heat pipe 1
    ['nullius-heat-pipe-2']                                 ={r=077, g=178, b=206, a=127}, --Heat pipe 2
    ['nullius-heat-pipe-3']                                 ={r=196, g=020, b=000, a=127}, --Heat pipe 3
    ['nullius-horticulture-drone']                          ={r=088, g=131, b=000, a=127}, --Horticulture drone
    ['nullius-horticulture-remote']                         ={r=088, g=131, b=000, a=127}, --Horticulture remote
    ['nullius-husbandry-drone']                             ={r=255, g=128, b=007, a=127}, --Husbandry drone
    ['nullius-husbandry-remote']                            ={r=255, g=128, b=007, a=127}, --Husbandry remote
    ['nullius-hydrogen-canister']                           ={r=230, g=166, b=173, a=127}, --Hydrogen canister
    ['nullius-hydro-plant-1']                               ={r=186, g=208, b=170, a=127}, --Hydro plant 1
    ['nullius-hydro-plant-2']                               ={r=165, g=174, b=228, a=127}, --Hydro plant 2
    ['nullius-hydro-plant-3']                               ={r=175, g=202, b=227, a=127}, --Hydro plant 3
    ['nullius-ichthyology-pack']                            ={r=191, g=226, b=105, a=127}, --Ichthyology specimen
    ['nullius-inserter-1']                                  ={r=255, g=163, b=000, a=127}, --Inserter 1
    ['nullius-inserter-2']                                  ={r=154, g=055, b=240, a=127}, --Inserter 2
    ['nullius-inserter-3']                                  ={r=053, g=193, b=251, a=127}, --Inserter 3
    ['nullius-inserter-4']                                  ={r=060, g=164, b=053, a=127}, --Inserter 4
    ['nullius-insulated-wire']                              ={r=080, g=161, b=096, a=127}, --Insulated wire
    ['nullius-insulation']                                  ={r=192, g=019, b=019, a=127}, --Insulation
    ['nullius-iron-gear']                                   ={r=125, g=152, b=175, a=127}, --Iron gear
    ['nullius-iron-ingot']                                  ={r=109, g=138, b=163, a=127}, --Iron ingot
    ['nullius-iron-oxide']                                  ={r=178, g=091, b=062, a=127}, --Iron oxide
    ['nullius-iron-plate']                                  ={r=124, g=155, b=180, a=127}, --Iron plate
    ['nullius-iron-rod']                                    ={r=149, g=179, b=203, a=127}, --Iron rod
    ['nullius-iron-sheet']                                  ={r=104, g=133, b=156, a=127}, --Iron sheet
    ['nullius-iron-wire']                                   ={r=124, g=155, b=180, a=127}, --Iron wire
    ['nullius-jump-boots']                                  ={r=219, g=246, b=250, a=127}, --Jump boots
    ['nullius-lab-1']                                       ={r=255, g=201, b=000, a=127}, --Laboratory 1
    ['nullius-lab-2']                                       ={r=234, g=017, b=000, a=127}, --Laboratory 2
    ['nullius-lab-3']                                       ={r=000, g=057, b=204, a=127}, --Laboratory 3
    ['nullius-lamp-1']                                      ={r=255, g=255, b=255, a=127}, --Lamp 1
    ['nullius-lamp-2']                                      ={r=255, g=255, b=255, a=127}, --Lamp 2
    ['nullius-land-fill-bauxite']                           ={r=145, g=059, b=000, a=127}, --Land fill (brown)
    ['nullius-land-fill-gravel']                            ={r=077, g=077, b=090, a=127}, --Land fill (grey)
    ['nullius-land-fill-iron']                              ={r=166, g=000, b=000, a=127}, --Land fill (red)
    ['nullius-land-fill-limestone']                         ={r=176, g=122, b=090, a=127}, --Land fill (beige)
    ['nullius-land-fill-sand']                              ={r=158, g=130, b=025, a=127}, --Land fill (tan)
    ['nullius-large-assembler-1']                           ={r=100, g=152, b=030, a=127}, --Large assembler 1
    ['nullius-large-assembler-2']                           ={r=100, g=152, b=030, a=127}, --Large assembler 2
    ['nullius-large-beacon-1']                              ={r=086, g=110, b=216, a=127}, --Large beacon 1
    ['nullius-large-beacon-2']                              ={r=152, g=059, b=019, a=127}, --Large beacon 2
    ['nullius-large-buffer-chest-1']                        ={r=000, g=221, b=050, a=127}, --Large buffer chest 1
    ['nullius-large-buffer-chest-2']                        ={r=000, g=221, b=050, a=127}, --Large buffer chest 2
    ['nullius-large-cargo-pod-1']                           ={r=255, g=229, b=020, a=127}, --Large cargo pod 1
    ['nullius-large-cargo-pod-2']                           ={r=244, g=013, b=022, a=127}, --Large cargo pod 2
    ['nullius-large-cargo-pod-3']                           ={r=017, g=157, b=247, a=127}, --Large cargo pod 3
    ['nullius-large-chest-1']                               ={r=185, g=149, b=149, a=127}, --Large chest 1
    ['nullius-large-chest-2']                               ={r=085, g=078, b=080, a=127}, --Large chest 2
    ['nullius-large-demand-chest-1']                        ={r=058, g=181, b=254, a=127}, --Large demand chest 1
    ['nullius-large-demand-chest-2']                        ={r=058, g=181, b=254, a=127}, --Large demand chest 2
    ['nullius-large-dispatch-chest-1']                      ={r=187, g=000, b=255, a=127}, --Large dispatch chest 1
    ['nullius-large-dispatch-chest-2']                      ={r=187, g=000, b=255, a=127}, --Large dispatch chest 2
    ['nullius-large-furnace-1']                             ={r=096, g=101, b=125, a=127}, --Large furnace 1
    ['nullius-large-furnace-2']                             ={r=113, g=146, b=151, a=127}, --Large furnace 2
    ['nullius-large-miner-1']                               ={r=076, g=159, b=222, a=127}, --Large miner 1
    ['nullius-large-miner-2']                               ={r=113, g=146, b=151, a=127}, --Large miner 2
    ['nullius-large-storage-chest-1']                       ={r=254, g=211, b=074, a=127}, --Large storage chest 1
    ['nullius-large-storage-chest-2']                       ={r=254, g=211, b=074, a=127}, --Large storage chest 2
    ['nullius-large-supply-chest-1']                        ={r=235, g=010, b=000, a=127}, --Large supply chest 1
    ['nullius-large-supply-chest-2']                        ={r=235, g=010, b=000, a=127}, --Large supply chest 2
    ['nullius-large-tank-1']                                ={r=209, g=218, b=152, a=127}, --Large tank 1
    ['nullius-large-tank-2']                                ={r=208, g=206, b=236, a=127}, --Large tank 2
    ['nullius-large-tank-3']                                ={r=205, g=206, b=203, a=127}, --Large tank 3
    ['nullius-leg-augmentation-1']                          ={r=187, g=187, b=086, a=127}, --Leg augmentation 1
    ['nullius-leg-augmentation-2']                          ={r=086, g=110, b=216, a=127}, --Leg augmentation 2
    ['nullius-leg-augmentation-3']                          ={r=151, g=144, b=126, a=127}, --Leg augmentation 3
    ['nullius-leg-augmentation-4']                          ={r=151, g=144, b=126, a=127}, --Leg augmentation 4
    ['nullius-levitation-field-1']                          ={r=000, g=245, b=251, a=127}, --Levitation field 1
    ['nullius-levitation-field-2']                          ={r=048, g=254, b=000, a=127}, --Levitation field 2
    ['nullius-lime']                                        ={r=245, g=194, b=146, a=127}, --Lime
    ['nullius-limestone']                                   ={r=255, g=202, b=165, a=127}, --Limestone
    ['nullius-lithium']                                     ={r=052, g=227, b=209, a=127}, --Lithium
    ['nullius-lithium-chloride']                            ={r=223, g=164, b=241, a=127}, --Lithium chloride
    ['nullius-locomotive-1']                                ={r=187, g=187, b=086, a=127}, --Locomotive 1
    ['nullius-locomotive-2']                                ={r=234, g=017, b=000, a=127}, --Locomotive 2
    ['nullius-locomotive-3']                                ={r=024, g=132, b=211, a=127}, --Locomotive 3
    ['nullius-logic-circuit']                               ={r=255, g=182, b=026, a=127}, --Logic circuit
    ['nullius-logistic-bot-1']                              ={r=187, g=187, b=086, a=127}, --Logistic bot 1
    ['nullius-logistic-bot-2']                              ={r=234, g=017, b=000, a=127}, --Logistic bot 2
    ['nullius-logistic-bot-3']                              ={r=000, g=108, b=202, a=127}, --Logistic bot 3
    ['nullius-logistic-bot-4']                              ={r=060, g=164, b=053, a=127}, --Logistic bot 4
    ['nullius-magazine']                                    ={r=255, g=000, b=000, a=127}, --Magazine
    ['nullius-mecha']                                       ={r=251, g=152, b=000, a=127}, --Mecha
    ['nullius-mecha-2']                                     ={r=255, g=255, b=255, a=127}, --Mecha-2
    ['nullius-mecha-drone-launcher-1']                      ={r=086, g=110, b=216, a=127}, --Drone launcher 1
    ['nullius-mecha-drone-launcher-2']                      ={r=255, g=202, b=000, a=127}, --Drone launcher 2
    ['nullius-mechanical-pack']                             ={r=255, g=004, b=004, a=127}, --Mechanical prototype
    ['nullius-mecha-remote']                                ={r=247, g=004, b=000, a=127}, --Mecha remote
    ['nullius-medium-assembler-1']                          ={r=052, g=068, b=108, a=127}, --Medium assembler 1
    ['nullius-medium-assembler-2']                          ={r=052, g=068, b=108, a=127}, --Medium assembler 2
    ['nullius-medium-assembler-3']                          ={r=052, g=068, b=108, a=127}, --Medium assembler 3
    ['nullius-medium-furnace-1']                            ={r=167, g=142, b=093, a=127}, --Medium furnace 1
    ['nullius-medium-furnace-2']                            ={r=096, g=101, b=125, a=127}, --Medium furnace 2
    ['nullius-medium-furnace-3']                            ={r=113, g=146, b=151, a=127}, --Medium furnace 3
    ['nullius-medium-miner-1']                              ={r=132, g=118, b=132, a=127}, --Medium miner 1
    ['nullius-medium-miner-2']                              ={r=076, g=159, b=222, a=127}, --Medium miner 2
    ['nullius-medium-miner-3']                              ={r=113, g=146, b=151, a=127}, --Medium miner 3
    ['nullius-medium-tank-1']                               ={r=131, g=109, b=070, a=127}, --Medium tank 1
    ['nullius-medium-tank-2']                               ={r=166, g=189, b=230, a=127}, --Medium tank 2
    ['nullius-medium-tank-3']                               ={r=176, g=190, b=199, a=127}, --Medium tank 3
    ['nullius-memory-circuit']                              ={r=193, g=035, b=031, a=127}, --Memory circuit
    ['nullius-microbiology-pack']                           ={r=255, g=167, b=067, a=127}, --Microbiology sample
    ['nullius-mineral-dust']                                ={r=146, g=076, b=022, a=127}, --Mineral dust
    ['nullius-mining-tool-1']                               ={r=144, g=004, b=004, a=127}, --Mining tool 1
    ['nullius-mining-tool-2']                               ={r=019, g=130, b=000, a=127}, --Mining tool 2
    ['nullius-mirror-chemical-plant-2']                     ={r=132, g=118, b=132, a=127}, --Chemical plant 2 (mirrored)
    ['nullius-mirror-chemical-plant-3']                     ={r=217, g=142, b=000, a=127}, --Chemical plant 3 (mirrored)
    ['nullius-mirror-combustion-chamber-2']                 ={r=250, g=232, b=136, a=127}, --Combustion chamber 2 (mirrored)
    ['nullius-mirror-combustion-chamber-3']                 ={r=250, g=232, b=136, a=127}, --Combustion chamber 3 (mirrored)
    ['nullius-mirror-distillery-2']                         ={r=165, g=174, b=228, a=127}, --Distillery 2 (mirrored)
    ['nullius-mirror-distillery-3']                         ={r=245, g=082, b=000, a=127}, --Distillery 3 (mirrored)
    ['nullius-mirror-flotation-cell-2']                     ={r=048, g=077, b=120, a=127}, --Flotation cell 2 (mirrored)
    ['nullius-mirror-flotation-cell-3']                     ={r=149, g=149, b=149, a=127}, --Flotation cell 3 (mirrored)
    ['nullius-mirror-hydro-plant-2']                        ={r=165, g=174, b=228, a=127}, --Hydro plant 2 (mirrored)
    ['nullius-mirror-hydro-plant-3']                        ={r=175, g=202, b=227, a=127}, --Hydro plant 3 (mirrored)
    ['nullius-mirror-nanofabricator-2']                     ={r=000, g=219, b=255, a=127}, --Nanofabricator 2 (mirrored)
    ['nullius-mirror-priority-electrolyzer-2']              ={r=110, g=105, b=114, a=127}, --Priority electrolyzer 2 (mirrored)
    ['nullius-mirror-priority-electrolyzer-3']              ={r=168, g=053, b=024, a=127}, --Priority electrolyzer 3 (mirrored)
    ['nullius-mirror-surge-electrolyzer-2']                 ={r=113, g=146, b=151, a=127}, --Surge electrolyzer 2 (mirrored)
    ['nullius-mirror-surge-electrolyzer-3']                 ={r=073, g=074, b=078, a=127}, --Surge electrolyzer 3 (mirrored)
    ['nullius-missile-1']                                   ={r=255, g=027, b=000, a=127}, --Missile 1
    ['nullius-missile-2']                                   ={r=057, g=255, b=000, a=127}, --Missile 2
    ['nullius-missile-launcher']                            ={r=140, g=152, b=120, a=127}, --Missile launcher
    ['nullius-monocrystalline-silicon']                     ={r=255, g=241, b=232, a=127}, --Monocrystalline silicon
    ['nullius-mortar']                                      ={r=220, g=207, b=184, a=127}, --Mortar
    ['nullius-motor-1']                                     ={r=100, g=109, b=138, a=127}, --Motor 1
    ['nullius-motor-2']                                     ={r=236, g=005, b=000, a=127}, --Motor 2
    ['nullius-motor-3']                                     ={r=032, g=233, b=255, a=127}, --Motor 3
    ['nullius-multi-tool-1']                                ={r=216, g=000, b=019, a=127}, --Multi-tool 1
    ['nullius-multi-tool-2']                                ={r=071, g=174, b=232, a=127}, --Multi-tool 2
    ['nullius-multi-tool-3']                                ={r=038, g=228, b=000, a=127}, --Multi-tool 3
    ['nullius-nanofabricator-1']                            ={r=060, g=074, b=071, a=127}, --Nanofabricator 1
    ['nullius-nanofabricator-2']                            ={r=000, g=219, b=255, a=127}, --Nanofabricator 2
    ['nullius-nematology-pack']                             ={r=216, g=115, b=086, a=127}, --Nematology specimen
    ['nullius-night-vision-1']                              ={r=048, g=254, b=000, a=127}, --Night vision 1
    ['nullius-night-vision-2']                              ={r=255, g=004, b=000, a=127}, --Night vision 2
    ['nullius-night-vision-3']                              ={r=000, g=245, b=251, a=127}, --Night vision 3
    ['nullius-one-way-valve']                               ={r=092, g=125, b=164, a=127}, --One-way valve
    ['nullius-optical-cable']                               ={r=192, g=019, b=019, a=127}, --Optical cable
    ['nullius-outfall-1']                                   ={r=229, g=168, b=000, a=127}, --Outfall 1
    ['nullius-outfall-2']                                   ={r=229, g=168, b=000, a=127}, --Outfall 2
    ['nullius-paving-drone-black']                          ={r=030, g=030, b=030, a=127}, --Paving drone (black)
    ['nullius-paving-drone-blue']                           ={r=000, g=095, b=184, a=127}, --Paving drone (blue)
    ['nullius-paving-drone-brown']                          ={r=168, g=067, b=000, a=127}, --Paving drone (brown)
    ['nullius-paving-drone-green']                          ={r=000, g=180, b=022, a=127}, --Paving drone (green)
    ['nullius-paving-drone-grey']                           ={r=164, g=168, b=168, a=127}, --Paving drone (grey)
    ['nullius-paving-drone-hazard']                         ={r=255, g=195, b=054, a=127}, --Paving drone (hazard)
    ['nullius-paving-drone-purple']                         ={r=125, g=000, b=184, a=127}, --Paving drone (purple)
    ['nullius-paving-drone-red']                            ={r=184, g=006, b=000, a=127}, --Paving drone (red)
    ['nullius-paving-drone-yellow']                         ={r=245, g=192, b=000, a=127}, --Paving drone (yellow)
    ['nullius-paving-remote-black']                         ={r=030, g=030, b=030, a=127}, --Paving remote (black)
    ['nullius-paving-remote-blue']                          ={r=000, g=095, b=184, a=127}, --Paving remote (blue)
    ['nullius-paving-remote-brown']                         ={r=168, g=067, b=000, a=127}, --Paving remote (brown)
    ['nullius-paving-remote-green']                         ={r=000, g=180, b=022, a=127}, --Paving remote (green)
    ['nullius-paving-remote-grey']                          ={r=164, g=168, b=168, a=127}, --Paving remote (grey)
    ['nullius-paving-remote-hazard']                        ={r=255, g=195, b=054, a=127}, --Paving remote (hazard)
    ['nullius-paving-remote-purple']                        ={r=125, g=000, b=184, a=127}, --Paving remote (purple)
    ['nullius-paving-remote-red']                           ={r=184, g=006, b=000, a=127}, --Paving remote (red)
    ['nullius-paving-remote-yellow']                        ={r=245, g=192, b=000, a=127}, --Paving remote (yellow)
    ['nullius-physics-pack']                                ={r=255, g=253, b=253, a=127}, --Physics apparatus
    ['nullius-pipe-1']                                      ={r=160, g=133, b=079, a=127}, --Pipe 1
    ['nullius-pipe-2']                                      ={r=226, g=056, b=000, a=127}, --Pipe 2
    ['nullius-pipe-3']                                      ={r=000, g=098, b=208, a=127}, --Pipe 3
    ['nullius-pipe-4']                                      ={r=066, g=066, b=066, a=127}, --Pipe 4
    ['nullius-plastic']                                     ={r=251, g=251, b=251, a=127}, --Plastic
    ['nullius-polycrystalline-silicon']                     ={r=255, g=241, b=232, a=127}, --Polycrystalline silicon
    ['nullius-portable-generator-1']                        ={r=226, g=207, b=000, a=127}, --Generator 1
    ['nullius-portable-generator-2']                        ={r=228, g=000, b=009, a=127}, --Generator 2
    ['nullius-portable-generator-backup']                   ={r=000, g=197, b=235, a=127}, --Backup generator
    ['nullius-portable-reactor']                            ={r=000, g=234, b=042, a=127}, --Portable reactor
    ['nullius-power-pole-1']                                ={r=139, g=140, b=140, a=127}, --Power pole 1
    ['nullius-power-pole-2']                                ={r=187, g=194, b=202, a=127}, --Power pole 2
    ['nullius-power-pole-3']                                ={r=096, g=103, b=107, a=127}, --Power pole 3
    ['nullius-power-pole-4']                                ={r=199, g=098, b=003, a=127}, --Power pole 4
    ['nullius-priority-compressor-1']                       ={r=107, g=098, b=049, a=127}, --Priority compressor 1
    ['nullius-priority-compressor-2']                       ={r=062, g=060, b=064, a=127}, --Priority compressor 2
    ['nullius-priority-compressor-3']                       ={r=120, g=086, b=106, a=127}, --Priority compressor 3
    ['nullius-priority-electrolyzer-1']                     ={r=125, g=083, b=049, a=127}, --Priority electrolyzer 1
    ['nullius-priority-electrolyzer-2']                     ={r=110, g=105, b=114, a=127}, --Priority electrolyzer 2
    ['nullius-priority-electrolyzer-3']                     ={r=168, g=053, b=024, a=127}, --Priority electrolyzer 3
    ['nullius-priority-turbine-1']                          ={r=197, g=024, b=053, a=127}, --Priority turbine 1
    ['nullius-priority-turbine-2']                          ={r=221, g=048, b=077, a=127}, --Priority turbine 2
    ['nullius-priority-valve']                              ={r=107, g=150, b=055, a=127}, --Auxiliary valve
    ['nullius-probe']                                       ={r=247, g=181, b=000, a=127}, --Probe
    ['nullius-processor-1']                                 ={r=044, g=197, b=000, a=127}, --Processor 1
    ['nullius-processor-2']                                 ={r=255, g=012, b=000, a=127}, --Processor 2
    ['nullius-processor-3']                                 ={r=000, g=071, b=255, a=127}, --Processor 3
    ['nullius-productivity-module-1']                       ={r=255, g=098, b=030, a=127}, --Productivity module 1
    ['nullius-productivity-module-2']                       ={r=255, g=098, b=030, a=127}, --Productivity module 2
    ['nullius-productivity-module-3']                       ={r=255, g=098, b=030, a=127}, --Productivity module 3
    ['nullius-pump-1']                                      ={r=197, g=197, b=053, a=127}, --Pump 1
    ['nullius-pump-2']                                      ={r=000, g=108, b=202, a=127}, --Pump 2
    ['nullius-pump-3']                                      ={r=170, g=125, b=089, a=127}, --Pump 3
    ['nullius-purple-concrete']                             ={r=125, g=000, b=184, a=127}, --Purple concrete
    ['nullius-pylon-1']                                     ={r=113, g=133, b=142, a=127}, --Pylon 1
    ['nullius-pylon-2']                                     ={r=187, g=194, b=202, a=127}, --Pylon 2
    ['nullius-pylon-3']                                     ={r=096, g=103, b=107, a=127}, --Pylon 3
    ['nullius-quadrupedal-adaptation-1']                    ={r=187, g=187, b=086, a=127}, --Quadrupedal adaptation 1
    ['nullius-quadrupedal-adaptation-2']                    ={r=086, g=110, b=216, a=127}, --Quadrupedal adaptation 2
    ['nullius-quadrupedal-adaptation-3']                    ={r=151, g=144, b=126, a=127}, --Quadrupedal adaptation 3
    ['nullius-quadrupedal-adaptation-4']                    ={r=151, g=144, b=126, a=127}, --Quadrupedal adaptation 4
    ['nullius-reactor']                                     ={r=073, g=236, b=053, a=127}, --Reactor
    ['nullius-red-concrete']                                ={r=184, g=006, b=000, a=127}, --Red concrete
    ['nullius-refractory-brick']                            ={r=137, g=083, b=025, a=127}, --Refractory brick
    ['nullius-refueler']                                    ={r=255, g=002, b=000, a=127}, --Refueler
    ['nullius-reinforced-concrete']                         ={r=164, g=168, b=168, a=127}, --Reinforced concrete
    ['nullius-relay-1']                                     ={r=128, g=101, b=184, a=127}, --Relay 1
    ['nullius-relay-2']                                     ={r=119, g=119, b=119, a=127}, --Relay 2
    ['nullius-relay-3']                                     ={r=184, g=139, b=004, a=127}, --Relay 3
    ['nullius-relay-4']                                     ={r=140, g=162, b=191, a=127}, --Relay 4
    ['nullius-relief-valve']                                ={r=149, g=054, b=000, a=127}, --Relief valve
    ['nullius-requirement-build']                           ={r=255, g=226, b=175, a=127}, --Building requirement
    ['nullius-requirement-consume']                         ={r=144, g=158, b=187, a=127}, --Consumption requirement
    ['nullius-robot-frame-1']                               ={r=255, g=201, b=000, a=127}, --Robot frame 1
    ['nullius-robot-frame-2']                               ={r=234, g=017, b=000, a=127}, --Robot frame 2
    ['nullius-robot-frame-3']                               ={r=000, g=108, b=202, a=127}, --Robot frame 3
    ['nullius-robot-frame-4']                               ={r=060, g=164, b=053, a=127}, --Robot frame 4
    ['nullius-rock-picker']                                 ={r=163, g=246, b=034, a=127}, --Rock picker
    ['nullius-rocket']                                      ={r=255, g=221, b=054, a=127}, --Rocket
    ['nullius-rocket-fuel']                                 ={r=197, g=098, b=000, a=127}, --Rocket fuel
    ['nullius-rubber']                                      ={r=029, g=029, b=031, a=127}, --Rubber
    ['nullius-rutile']                                      ={r=138, g=093, b=134, a=127}, --Rutile
    ['nullius-salt']                                        ={r=237, g=252, b=255, a=127}, --Salt
    ['nullius-sand']                                        ={r=186, g=159, b=026, a=127}, --Sand
    ['nullius-sandstone']                                   ={r=221, g=115, b=021, a=127}, --Sandstone
    ['nullius-satellite']                                   ={r=027, g=140, b=255, a=127}, --Satellite
    ['nullius-scout-drone-1']                               ={r=158, g=158, b=158, a=127}, --Scout drone 1
    ['nullius-scout-drone-2']                               ={r=158, g=158, b=158, a=127}, --Scout drone 2
    ['nullius-scout-remote']                                ={r=158, g=158, b=158, a=127}, --Scout remote
    ['nullius-seawater-intake-1']                           ={r=170, g=125, b=089, a=127}, --Seawater intake 1
    ['nullius-seawater-intake-2']                           ={r=170, g=125, b=089, a=127}, --Seawater intake 2
    ['nullius-self-repair-pack']                            ={r=255, g=103, b=177, a=127}, --Self repair pack
    ['nullius-sensor-1']                                    ={r=255, g=004, b=000, a=127}, --Sensor 1
    ['nullius-sensor-2']                                    ={r=000, g=108, b=202, a=127}, --Sensor 2
    ['nullius-sensor-node-1']                               ={r=187, g=187, b=086, a=127}, --Sensor node 1
    ['nullius-sensor-node-2']                               ={r=086, g=110, b=216, a=127}, --Sensor node 2
    ['nullius-sensor-node-3']                               ={r=127, g=115, b=079, a=127}, --Sensor node 3
    ['nullius-shield']                                      ={r=000, g=233, b=255, a=127}, --Shield
    ['nullius-silica']                                      ={r=255, g=241, b=232, a=127}, --Silica
    ['nullius-silicon-ingot']                               ={r=255, g=241, b=232, a=127}, --Silicon ingot
    ['nullius-silo']                                        ={r=130, g=115, b=090, a=127}, --Silo
    ['nullius-small-assembler-1']                           ={r=085, g=060, b=047, a=127}, --Small assembler 1
    ['nullius-small-assembler-2']                           ={r=085, g=060, b=047, a=127}, --Small assembler 2
    ['nullius-small-assembler-3']                           ={r=085, g=060, b=047, a=127}, --Small assembler 3
    ['nullius-small-buffer-chest-1']                        ={r=000, g=221, b=050, a=127}, --Small buffer chest 1
    ['nullius-small-buffer-chest-2']                        ={r=000, g=221, b=050, a=127}, --Small buffer chest 2
    ['nullius-small-cargo-pod-1']                           ={r=252, g=255, b=125, a=127}, --Small cargo pod 1
    ['nullius-small-cargo-pod-2']                           ={r=131, g=208, b=255, a=127}, --Small cargo pod 2
    ['nullius-small-chest-1']                               ={r=176, g=137, b=104, a=127}, --Small chest 1
    ['nullius-small-chest-2']                               ={r=185, g=149, b=149, a=127}, --Small chest 2
    ['nullius-small-chest-3']                               ={r=085, g=078, b=080, a=127}, --Small chest 3
    ['nullius-small-demand-chest-1']                        ={r=058, g=181, b=254, a=127}, --Small demand chest 1
    ['nullius-small-demand-chest-2']                        ={r=058, g=181, b=254, a=127}, --Small demand chest 2
    ['nullius-small-dispatch-chest-1']                      ={r=187, g=000, b=255, a=127}, --Small dispatch chest 1
    ['nullius-small-dispatch-chest-2']                      ={r=187, g=000, b=255, a=127}, --Small dispatch chest 2
    ['nullius-small-furnace-1']                             ={r=255, g=207, b=057, a=127}, --Small furnace 1
    ['nullius-small-furnace-2']                             ={r=167, g=142, b=093, a=127}, --Small furnace 2
    ['nullius-small-furnace-3']                             ={r=096, g=101, b=125, a=127}, --Small furnace 3
    ['nullius-small-miner-1']                               ={r=132, g=118, b=132, a=127}, --Small miner 1
    ['nullius-small-miner-2']                               ={r=076, g=159, b=222, a=127}, --Small miner 2
    ['nullius-small-miner-3']                               ={r=113, g=146, b=151, a=127}, --Small miner 3
    ['nullius-small-pump-1']                                ={r=119, g=119, b=117, a=127}, --Small pump 1
    ['nullius-small-pump-2']                                ={r=233, g=218, b=218, a=127}, --Small pump 2
    ['nullius-small-storage-chest-1']                       ={r=254, g=211, b=074, a=127}, --Small storage chest 1
    ['nullius-small-storage-chest-2']                       ={r=254, g=211, b=074, a=127}, --Small storage chest 2
    ['nullius-small-supply-chest-1']                        ={r=235, g=010, b=000, a=127}, --Small supply chest 1
    ['nullius-small-supply-chest-2']                        ={r=235, g=010, b=000, a=127}, --Small supply chest 2
    ['nullius-small-tank-1']                                ={r=146, g=019, b=008, a=127}, --Small tank 1
    ['nullius-small-tank-2']                                ={r=146, g=019, b=008, a=127}, --Small tank 2
    ['nullius-soda-ash']                                    ={r=081, g=119, b=184, a=127}, --Soda ash
    ['nullius-sodium']                                      ={r=005, g=062, b=178, a=127}, --Sodium
    ['nullius-sodium-hydroxide']                            ={r=216, g=216, b=216, a=127}, --Sodium hydroxide
    ['nullius-sodium-sulfate']                              ={r=200, g=175, b=040, a=127}, --Sodium sulfate
    ['nullius-solar-collector-1']                           ={r=255, g=040, b=000, a=127}, --Solar collector 1
    ['nullius-solar-collector-2']                           ={r=255, g=145, b=000, a=127}, --Solar collector 2
    ['nullius-solar-collector-3']                           ={r=255, g=226, b=000, a=127}, --Solar collector 3
    ['nullius-solar-locomotive']                            ={r=060, g=164, b=053, a=127}, --Solar locomotive
    ['nullius-solar-panel-1']                               ={r=035, g=112, b=128, a=127}, --Solar panel 1
    ['nullius-solar-panel-2']                               ={r=009, g=173, b=212, a=127}, --Solar panel 2
    ['nullius-solar-panel-3']                               ={r=044, g=146, b=190, a=127}, --Solar panel 3
    ['nullius-solar-panel-4']                               ={r=178, g=120, b=163, a=127}, --Solar panel 4
    ['nullius-speed-module-1']                              ={r=034, g=160, b=235, a=127}, --Speed module 1
    ['nullius-speed-module-2']                              ={r=034, g=160, b=235, a=127}, --Speed module 2
    ['nullius-speed-module-3']                              ={r=034, g=160, b=235, a=127}, --Speed module 3
    ['nullius-speed-module-4']                              ={r=034, g=160, b=235, a=127}, --Speed module 4
    ['nullius-spent-breeder-cell']                          ={r=034, g=139, b=158, a=127}, --Spent breeder cell
    ['nullius-spent-fission-cell']                          ={r=023, g=050, b=023, a=127}, --Spent fission cell
    ['nullius-spent-fusion-cell']                           ={r=109, g=073, b=131, a=127}, --Spent fusion cell
    ['nullius-splitter-1']                                  ={r=255, g=201, b=002, a=127}, --Splitter 1
    ['nullius-splitter-2']                                  ={r=255, g=013, b=000, a=127}, --Splitter 2
    ['nullius-splitter-3']                                  ={r=111, g=229, b=255, a=127}, --Splitter 3
    ['nullius-splitter-4']                                  ={r=000, g=221, b=050, a=127}, --Splitter 4
    ['nullius-stabilizer-1']                                ={r=000, g=190, b=078, a=127}, --Stabilizer 1
    ['nullius-stabilizer-2']                                ={r=163, g=091, b=235, a=127}, --Stabilizer 2
    ['nullius-standard-turbine-1']                          ={r=107, g=098, b=049, a=127}, --Standard turbine 1
    ['nullius-standard-turbine-2']                          ={r=180, g=176, b=122, a=127}, --Standard turbine 2
    ['nullius-standard-turbine-3']                          ={r=233, g=220, b=136, a=127}, --Standard turbine 3
    ['nullius-steel-beam']                                  ={r=224, g=224, b=212, a=127}, --Steel beam
    ['nullius-steel-cable']                                 ={r=187, g=192, b=206, a=127}, --Steel cable
    ['nullius-steel-gear']                                  ={r=231, g=238, b=251, a=127}, --Steel gear
    ['nullius-steel-ingot']                                 ={r=235, g=244, b=255, a=127}, --Steel ingot
    ['nullius-steel-plate']                                 ={r=231, g=238, b=251, a=127}, --Steel plate
    ['nullius-steel-rod']                                   ={r=187, g=192, b=206, a=127}, --Steel rod
    ['nullius-steel-sheet']                                 ={r=231, g=238, b=251, a=127}, --Steel sheet
    ['nullius-steel-wire']                                  ={r=231, g=238, b=251, a=127}, --Steel wire
    ['nullius-stirling-engine-1']                           ={r=187, g=187, b=086, a=127}, --Stirling engine 1
    ['nullius-stirling-engine-2']                           ={r=086, g=110, b=216, a=127}, --Stirling engine 2
    ['nullius-stirling-engine-3']                           ={r=151, g=144, b=126, a=127}, --Stirling engine 3
    ['nullius-substation-1']                                ={r=187, g=187, b=086, a=127}, --Substation 1
    ['nullius-substation-2']                                ={r=072, g=117, b=155, a=127}, --Substation 2
    ['nullius-substation-3']                                ={r=071, g=164, b=056, a=127}, --Substation 3
    ['nullius-sugar']                                       ={r=248, g=243, b=227, a=127}, --Sugar
    ['nullius-surge-compressor-1']                          ={r=046, g=062, b=064, a=127}, --Surge compressor 1
    ['nullius-surge-compressor-2']                          ={r=048, g=077, b=120, a=127}, --Surge compressor 2
    ['nullius-surge-compressor-3']                          ={r=143, g=145, b=161, a=127}, --Surge compressor 3
    ['nullius-surge-electrolyzer-1']                        ={r=132, g=132, b=085, a=127}, --Surge electrolyzer 1
    ['nullius-surge-electrolyzer-2']                        ={r=113, g=146, b=151, a=127}, --Surge electrolyzer 2
    ['nullius-surge-electrolyzer-3']                        ={r=073, g=074, b=078, a=127}, --Surge electrolyzer 3
    ['nullius-telekinesis-field-1']                         ={r=255, g=229, b=020, a=127}, --Telekinesis field 1
    ['nullius-telekinesis-field-2']                         ={r=244, g=013, b=022, a=127}, --Telekinesis field 2
    ['nullius-telekinesis-field-3']                         ={r=017, g=157, b=247, a=127}, --Telekinesis field 3
    ['nullius-terraforming-drone-beige']                    ={r=176, g=122, b=090, a=127}, --Terraforming drone (beige)
    ['nullius-terraforming-drone-brown']                    ={r=145, g=059, b=000, a=127}, --Terraforming drone (brown)
    ['nullius-terraforming-drone-grey']                     ={r=077, g=077, b=090, a=127}, --Terraforming drone (grey)
    ['nullius-terraforming-drone-red']                      ={r=166, g=000, b=000, a=127}, --Terraforming drone (red)
    ['nullius-terraforming-drone-tan']                      ={r=158, g=130, b=025, a=127}, --Terraforming drone (tan)
    ['nullius-terraforming-remote-beige']                   ={r=176, g=122, b=090, a=127}, --Terraforming remote (beige)
    ['nullius-terraforming-remote-brown']                   ={r=145, g=059, b=000, a=127}, --Terraforming remote (brown)
    ['nullius-terraforming-remote-grey']                    ={r=077, g=077, b=090, a=127}, --Terraforming remote (grey)
    ['nullius-terraforming-remote-red']                     ={r=166, g=000, b=000, a=127}, --Terraforming remote (red)
    ['nullius-terraforming-remote-tan']                     ={r=158, g=130, b=025, a=127}, --Terraforming remote (tan)
    ['nullius-textile']                                     ={r=076, g=218, b=206, a=127}, --Textile
    ['nullius-thermal-tank-1']                              ={r=160, g=136, b=062, a=127}, --Thermal tank 1
    ['nullius-thermal-tank-2']                              ={r=076, g=101, b=139, a=127}, --Thermal tank 2
    ['nullius-thermal-tank-3']                              ={r=142, g=044, b=034, a=127}, --Thermal tank 3
    ['nullius-titanium-ingot']                              ={r=127, g=084, b=122, a=127}, --Titanium ingot
    ['nullius-titanium-plate']                              ={r=146, g=101, b=141, a=127}, --Titanium plate
    ['nullius-titanium-rod']                                ={r=127, g=084, b=122, a=127}, --Titanium rod
    ['nullius-titanium-sheet']                              ={r=139, g=096, b=139, a=127}, --Titanium sheet
    ['nullius-top-up-valve']                                ={r=209, g=172, b=000, a=127}, --Top-up valve
    ['nullius-transformer']                                 ={r=250, g=250, b=241, a=127}, --Transformer
    ['nullius-trash-compactor']                             ={r=163, g=161, b=160, a=127}, --Trash compactor
    ['nullius-tree']                                        ={r=088, g=131, b=000, a=127}, --Tree
    ['nullius-tree-genome']                                 ={r=088, g=131, b=000, a=127}, --Tree genome
    ['nullius-tree-progenitor']                             ={r=149, g=034, b=005, a=127}, --Tree progenitor
    ['nullius-tree-seed']                                   ={r=088, g=131, b=000, a=127}, --Tree seed
    ['nullius-truck-1']                                     ={r=245, g=145, b=000, a=127}, --Truck 1
    ['nullius-truck-2']                                     ={r=106, g=127, b=192, a=127}, --Truck 2
    ['nullius-turret']                                      ={r=255, g=212, b=000, a=127}, --Turret
    ['nullius-uncharged-battery-1']                         ={r=093, g=111, b=124, a=127}, --Battery 1 (uncharged)
    ['nullius-uncharged-battery-2']                         ={r=093, g=111, b=124, a=127}, --Battery 2 (uncharged)
    ['nullius-uncharged-battery-3']                         ={r=093, g=111, b=124, a=127}, --Battery 3 (uncharged)
    ['nullius-underground-belt-1']                          ={r=255, g=192, b=040, a=127}, --Underground belt 1
    ['nullius-underground-belt-2']                          ={r=252, g=007, b=000, a=127}, --Underground belt 2
    ['nullius-underground-belt-3']                          ={r=053, g=193, b=251, a=127}, --Underground belt 3
    ['nullius-underground-belt-4']                          ={r=000, g=221, b=050, a=127}, --Underground belt 4
    ['nullius-underground-pipe-1']                          ={r=188, g=154, b=095, a=127}, --Underground pipe 1
    ['nullius-underground-pipe-2']                          ={r=226, g=056, b=000, a=127}, --Underground pipe 2
    ['nullius-underground-pipe-3']                          ={r=000, g=098, b=208, a=127}, --Underground pipe 3
    ['nullius-underground-pipe-4']                          ={r=066, g=066, b=066, a=127}, --Underground pipe 4
    ['nullius-uranium']                                     ={r=022, g=079, b=020, a=127}, --Uranium
    ['nullius-water-canister']                              ={r=112, g=247, b=242, a=127}, --Water canister
    ['nullius-well-1']                                      ={r=077, g=178, b=206, a=127}, --Well 1
    ['nullius-well-2']                                      ={r=086, g=110, b=216, a=127}, --Well 2
    ['nullius-wind-1']                                      ={r=235, g=206, b=156, a=127}, --Wind turbine 1
    ['nullius-wind-2']                                      ={r=255, g=201, b=000, a=127}, --Wind turbine 2
    ['nullius-wind-3']                                      ={r=250, g=031, b=000, a=127}, --Wind turbine 3
    ['nullius-wood']                                        ={r=192, g=094, b=000, a=127}, --Wood
    ['nullius-worm']                                        ={r=216, g=115, b=086, a=127}, --Worm
    ['nullius-worm-egg']                                    ={r=216, g=115, b=086, a=127}, --Worm egg
    ['nullius-worm-genome']                                 ={r=216, g=115, b=086, a=127}, --Worm genome
    ['nullius-worm-progenitor']                             ={r=022, g=202, b=245, a=127}, --Worm progenitor
    ['nullius-yellowcake']                                  ={r=151, g=241, b=011, a=127}, --Yellowcake
    ['nullius-yellow-concrete']                             ={r=245, g=192, b=000, a=127}, --Yellow concrete
    ['nullius-yield-module-1']                              ={r=255, g=219, b=000, a=127}, --Yield module 1
    ['nullius-yield-module-2']                              ={r=255, g=219, b=000, a=127}, --Yield module 2
    ['nullius-yield-module-3']                              ={r=255, g=219, b=000, a=127}, --Yield module 3
    ['nullius-yield-module-4']                              ={r=255, g=219, b=000, a=127}, --Yield module 4
    ['nullius-zoology-pack']                                ={r=255, g=128, b=007, a=127}, --Zoology specimen
    ['processed-fuel-null']                                 ={r=185, g=191, b=191, a=127}, --Methanol canister

    ['nullius-acid-hydrochloric']                           ={r=026, g=255, b=026, a=127}, --Hydrochloric acid
    ['nullius-acid-nitric']                                 ={r=125, g=064, b=255, a=127}, --Nitric acid
    ['nullius-acid-sulfuric']                               ={r=230, g=194, b=000, a=127}, --Sulfuric acid
    ['nullius-acrylonitrile']                               ={r=031, g=031, b=122, a=127}, --Acrylonitrile
    ['nullius-air']                                         ={r=000, g=128, b=255, a=127}, --Air
    ['nullius-amino-acids']                                 ={r=153, g=107, b=015, a=127}, --Amino acids
    ['nullius-ammonia']                                     ={r=077, g=077, b=214, a=127}, --Ammonia
    ['nullius-argon']                                       ={r=173, g=130, b=245, a=127}, --Argon
    ['nullius-bacteria']                                    ={r=245, g=107, b=015, a=127}, --Bacteria
    ['nullius-benzene']                                     ={r=046, g=046, b=046, a=127}, --Benzene
    ['nullius-biodiesel']                                   ={r=255, g=143, b=008, a=127}, --Biodiesel
    ['nullius-brine']                                       ={r=000, g=093, b=170, a=127}, --Brine
    ['nullius-butadiene']                                   ={r=245, g=245, b=245, a=127}, --Butadiene
    ['nullius-calcium-chloride-solution']                   ={r=217, g=255, b=140, a=127}, --Calcium chloride solution
    ['nullius-carbon-dioxide']                              ={r=255, g=026, b=026, a=127}, --Carbon dioxide
    ['nullius-carbon-monoxide']                             ={r=153, g=015, b=015, a=127}, --Carbon monoxide
    ['nullius-caustic-solution']                            ={r=170, g=000, b=216, a=127}, --Caustic solution
    ['nullius-chlorine']                                    ={r=000, g=255, b=000, a=127}, --Chlorine
    ['nullius-compressed-air']                              ={r=000, g=128, b=255, a=127}, --Compressed air
    ['nullius-compressed-argon']                            ={r=173, g=130, b=245, a=127}, --Compressed argon
    ['nullius-compressed-carbon-dioxide']                   ={r=255, g=026, b=026, a=127}, --Compressed carbon dioxide
    ['nullius-compressed-carbon-monoxide']                  ={r=153, g=015, b=015, a=127}, --Compressed carbon monoxide
    ['nullius-compressed-helium']                           ={r=209, g=173, b=255, a=127}, --Compressed helium
    ['nullius-compressed-hydrogen']                         ={r=255, g=255, b=255, a=127}, --Compressed hydrogen
    ['nullius-compressed-methane']                          ={r=208, g=208, b=208, a=127}, --Compressed methane
    ['nullius-compressed-nitrogen']                         ={r=000, g=061, b=230, a=127}, --Compressed nitrogen
    ['nullius-compressed-oxygen']                           ={r=255, g=000, b=000, a=127}, --Compressed oxygen
    ['nullius-compressed-residual-gas']                     ={r=074, g=161, b=255, a=127}, --Compressed residual gas
    ['nullius-compressed-trace-gas']                        ={r=151, g=194, b=245, a=127}, --Compressed trace gas
    ['nullius-copper-solution']                             ={r=246, g=072, b=000, a=127}, --Copper solution
    ['nullius-deuterium']                                   ={r=255, g=236, b=198, a=127}, --Deuterium
    ['nullius-ech']                                         ={r=255, g=235, b=159, a=127}, --ECH
    ['nullius-epoxy']                                       ={r=230, g=216, b=130, a=127}, --Epoxy
    ['nullius-ethylene']                                    ={r=138, g=138, b=138, a=127}, --Ethylene
    ['nullius-fatty-acids']                                 ={r=245, g=245, b=061, a=127}, --Fatty acids
    ['nullius-freshwater']                                  ={r=041, g=192, b=170, a=127}, --Freshwater
    ['nullius-glycerol']                                    ={r=255, g=200, b=091, a=127}, --Glycerol
    ['nullius-heavy-water']                                 ={r=000, g=216, b=216, a=127}, --Heavy water
    ['nullius-helium']                                      ={r=209, g=173, b=255, a=127}, --Helium
    ['nullius-hydrogen']                                    ={r=255, g=255, b=255, a=127}, --Hydrogen
    ['nullius-hydrogen-chloride']                           ={r=140, g=255, b=140, a=127}, --Hydrogen chloride
    ['nullius-lubricant']                                   ={r=098, g=199, b=043, a=127}, --Lubricant
    ['nullius-methane']                                     ={r=208, g=208, b=208, a=127}, --Methane
    ['nullius-methanol']                                    ={r=214, g=157, b=157, a=127}, --Methanol
    ['nullius-nitrogen']                                    ={r=000, g=061, b=230, a=127}, --Nitrogen
    ['nullius-nucleotides']                                 ={r=170, g=255, b=085, a=127}, --Nucleotides
    ['nullius-oil']                                         ={r=255, g=181, b=000, a=127}, --Oil
    ['nullius-oxygen']                                      ={r=255, g=000, b=000, a=127}, --Oxygen
    ['nullius-pressure-steam']                              ={r=245, g=245, b=245, a=127}, --High-pressure steam
    ['nullius-propene']                                     ={r=092, g=092, b=092, a=127}, --Propene
    ['nullius-protocell']                                   ={r=255, g=170, b=085, a=127}, --Protocell
    ['nullius-residual-gas']                                ={r=074, g=161, b=255, a=127}, --Residual gas
    ['nullius-saline']                                      ={r=000, g=198, b=224, a=127}, --Saline water
    ['nullius-seawater']                                    ={r=043, g=173, b=166, a=127}, --Seawater
    ['nullius-sludge']                                      ={r=138, g=100, b=034, a=127}, --Sludge
    ['nullius-solvent']                                     ={r=255, g=248, b=202, a=127}, --Solvent
    ['nullius-steam']                                       ={r=217, g=217, b=255, a=127}, --Steam
    ['nullius-styrene']                                     ={r=000, g=000, b=000, a=127}, --Styrene
    ['nullius-sulfur-dioxide']                              ={r=255, g=255, b=000, a=127}, --Sulfur dioxide
    ['nullius-titanium-tetrachloride']                      ={r=144, g=036, b=090, a=127}, --Titanium tetrachloride
    ['nullius-trace-gas']                                   ={r=151, g=194, b=245, a=127}, --Trace gas
    ['nullius-tritium']                                     ={r=255, g=217, b=140, a=127}, --Tritium
    ['nullius-volcanic-gas']                                ={r=255, g=146, b=000, a=127}, --Volcanic gas
    ['nullius-wastewater']                                  ={r=098, g=152, b=111, a=127}, --Wastewater
    ['nullius-water']                                       ={r=000, g=231, b=240, a=127}, --Water
}

nullius_filters={
    "processed-fuel",
}