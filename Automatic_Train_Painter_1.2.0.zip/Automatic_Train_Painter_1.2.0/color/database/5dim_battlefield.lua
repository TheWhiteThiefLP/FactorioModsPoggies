_5dim_battlefield={
    ['5d-flamethrower-turret-02']                           ={r=250, g=025, b=000, a=127}, --Flamethrower turret MK2
    ['5d-flamethrower-turret-03']                           ={r=000, g=198, b=255, a=127}, --Flamethrower turret MK3
    ['5d-flamethrower-turret-04']                           ={r=248, g=074, b=234, a=127}, --Flamethrower turret MK4
    ['5d-flamethrower-turret-05']                           ={r=022, g=255, b=009, a=127}, --Flamethrower turret MK5
    ['5d-flamethrower-turret-06']                           ={r=178, g=107, b=055, a=127}, --Flamethrower turret MK6
    ['5d-flamethrower-turret-07']                           ={r=124, g=023, b=191, a=127}, --Flamethrower turret MK7
    ['5d-flamethrower-turret-08']                           ={r=252, g=252, b=248, a=127}, --Flamethrower turret MK8
    ['5d-flamethrower-turret-09']                           ={r=255, g=121, b=000, a=127}, --Flamethrower turret MK9
    ['5d-flamethrower-turret-10']                           ={r=025, g=029, b=252, a=127}, --Flamethrower turret MK10
    ['5d-gate-02']                                          ={r=250, g=025, b=000, a=127}, --Gate MK2
    ['5d-gate-03']                                          ={r=000, g=198, b=255, a=127}, --Gate MK3
    ['5d-gate-04']                                          ={r=248, g=074, b=234, a=127}, --Gate MK4
    ['5d-gate-05']                                          ={r=022, g=255, b=009, a=127}, --Gate MK5
    ['5d-gate-06']                                          ={r=178, g=107, b=055, a=127}, --Gate MK6
    ['5d-gate-07']                                          ={r=124, g=023, b=191, a=127}, --Gate MK7
    ['5d-gate-08']                                          ={r=252, g=252, b=248, a=127}, --Gate MK8
    ['5d-gate-09']                                          ={r=255, g=121, b=000, a=127}, --Gate MK9
    ['5d-gate-10']                                          ={r=025, g=029, b=252, a=127}, --Gate MK10
    ['5d-gun-turret-02']                                    ={r=250, g=025, b=000, a=127}, --Gun turret MK2
    ['5d-gun-turret-03']                                    ={r=250, g=025, b=000, a=127}, --Gun turret MK3
    ['5d-gun-turret-04']                                    ={r=250, g=025, b=000, a=127}, --Gun turret MK4
    ['5d-gun-turret-05']                                    ={r=250, g=025, b=000, a=127}, --Gun turret MK5
    ['5d-gun-turret-06']                                    ={r=250, g=025, b=000, a=127}, --Gun turret MK6
    ['5d-gun-turret-07']                                    ={r=250, g=025, b=000, a=127}, --Gun turret MK7
    ['5d-gun-turret-08']                                    ={r=250, g=025, b=000, a=127}, --Gun turret MK8
    ['5d-gun-turret-09']                                    ={r=250, g=025, b=000, a=127}, --Gun turret MK9
    ['5d-gun-turret-10']                                    ={r=250, g=025, b=000, a=127}, --Gun turret MK10
    ['5d-gun-turret-big-01']                                ={r=025, g=029, b=252, a=127}, --Big gun turret
    ['5d-gun-turret-big-02']                                ={r=025, g=029, b=252, a=127}, --Big gun turret MK2
    ['5d-gun-turret-big-03']                                ={r=025, g=029, b=252, a=127}, --Big gun turret MK3
    ['5d-gun-turret-big-04']                                ={r=025, g=029, b=252, a=127}, --Big gun turret MK4
    ['5d-gun-turret-big-05']                                ={r=025, g=029, b=252, a=127}, --Big gun turret MK5
    ['5d-gun-turret-big-06']                                ={r=025, g=029, b=252, a=127}, --Big gun turret MK6
    ['5d-gun-turret-big-07']                                ={r=025, g=029, b=252, a=127}, --Big gun turret MK7
    ['5d-gun-turret-big-08']                                ={r=025, g=029, b=252, a=127}, --Big gun turret MK8
    ['5d-gun-turret-big-09']                                ={r=025, g=029, b=252, a=127}, --Big gun turret MK9
    ['5d-gun-turret-big-10']                                ={r=025, g=029, b=252, a=127}, --Big gun turret MK10
    ['5d-gun-turret-small-01']                              ={r=255, g=207, b=000, a=127}, --Small gun turret
    ['5d-gun-turret-small-02']                              ={r=255, g=207, b=000, a=127}, --Small gun turret MK2
    ['5d-gun-turret-small-03']                              ={r=255, g=207, b=000, a=127}, --Small gun turret MK3
    ['5d-gun-turret-small-04']                              ={r=255, g=207, b=000, a=127}, --Small gun turret MK4
    ['5d-gun-turret-small-05']                              ={r=255, g=207, b=000, a=127}, --Small gun turret MK5
    ['5d-gun-turret-small-06']                              ={r=255, g=207, b=000, a=127}, --Small gun turret MK6
    ['5d-gun-turret-small-07']                              ={r=255, g=207, b=000, a=127}, --Small gun turret MK7
    ['5d-gun-turret-small-08']                              ={r=255, g=207, b=000, a=127}, --Small gun turret MK8
    ['5d-gun-turret-small-09']                              ={r=255, g=207, b=000, a=127}, --Small gun turret MK9
    ['5d-gun-turret-small-10']                              ={r=255, g=207, b=000, a=127}, --Small gun turret MK10
    ['5d-gun-turret-sniper-01']                             ={r=000, g=198, b=255, a=127}, --Sniper gun turret
    ['5d-gun-turret-sniper-02']                             ={r=000, g=198, b=255, a=127}, --Sniper gun turret MK2
    ['5d-gun-turret-sniper-03']                             ={r=000, g=198, b=255, a=127}, --Sniper gun turret MK3
    ['5d-gun-turret-sniper-04']                             ={r=000, g=198, b=255, a=127}, --Sniper gun turret MK4
    ['5d-gun-turret-sniper-05']                             ={r=000, g=198, b=255, a=127}, --Sniper gun turret MK5
    ['5d-gun-turret-sniper-06']                             ={r=000, g=198, b=255, a=127}, --Sniper gun turret MK6
    ['5d-gun-turret-sniper-07']                             ={r=000, g=198, b=255, a=127}, --Sniper gun turret MK7
    ['5d-gun-turret-sniper-08']                             ={r=000, g=198, b=255, a=127}, --Sniper gun turret MK8
    ['5d-gun-turret-sniper-09']                             ={r=000, g=198, b=255, a=127}, --Sniper gun turret MK9
    ['5d-gun-turret-sniper-10']                             ={r=000, g=198, b=255, a=127}, --Sniper gun turret MK10
    ['5d-laser-turret-02']                                  ={r=250, g=025, b=000, a=127}, --Laser turret MK2
    ['5d-laser-turret-03']                                  ={r=250, g=025, b=000, a=127}, --Laser turret MK3
    ['5d-laser-turret-04']                                  ={r=250, g=025, b=000, a=127}, --Laser turret MK4
    ['5d-laser-turret-05']                                  ={r=250, g=025, b=000, a=127}, --Laser turret MK5
    ['5d-laser-turret-06']                                  ={r=250, g=025, b=000, a=127}, --Laser turret MK6
    ['5d-laser-turret-07']                                  ={r=250, g=025, b=000, a=127}, --Laser turret MK7
    ['5d-laser-turret-08']                                  ={r=250, g=025, b=000, a=127}, --Laser turret MK8
    ['5d-laser-turret-09']                                  ={r=250, g=025, b=000, a=127}, --Laser turret MK9
    ['5d-laser-turret-10']                                  ={r=250, g=025, b=000, a=127}, --Laser turret MK10
    ['5d-laser-turret-big-01']                              ={r=025, g=029, b=252, a=127}, --Big laser turret
    ['5d-laser-turret-big-02']                              ={r=025, g=029, b=252, a=127}, --Big laser turret MK2
    ['5d-laser-turret-big-03']                              ={r=025, g=029, b=252, a=127}, --Big laser turret MK3
    ['5d-laser-turret-big-04']                              ={r=025, g=029, b=252, a=127}, --Big laser turret MK4
    ['5d-laser-turret-big-05']                              ={r=025, g=029, b=252, a=127}, --Big laser turret MK5
    ['5d-laser-turret-big-06']                              ={r=025, g=029, b=252, a=127}, --Big laser turret MK6
    ['5d-laser-turret-big-07']                              ={r=025, g=029, b=252, a=127}, --Big laser turret MK7
    ['5d-laser-turret-big-08']                              ={r=025, g=029, b=252, a=127}, --Big laser turret MK8
    ['5d-laser-turret-big-09']                              ={r=025, g=029, b=252, a=127}, --Big laser turret MK9
    ['5d-laser-turret-big-10']                              ={r=025, g=029, b=252, a=127}, --Big laser turret MK10
    ['5d-laser-turret-small-01']                            ={r=255, g=248, b=000, a=127}, --Small laser turret
    ['5d-laser-turret-small-02']                            ={r=255, g=248, b=000, a=127}, --Small laser turret MK2
    ['5d-laser-turret-small-03']                            ={r=255, g=248, b=000, a=127}, --Small laser turret MK3
    ['5d-laser-turret-small-04']                            ={r=255, g=248, b=000, a=127}, --Small laser turret MK4
    ['5d-laser-turret-small-05']                            ={r=255, g=248, b=000, a=127}, --Small laser turret MK5
    ['5d-laser-turret-small-06']                            ={r=255, g=248, b=000, a=127}, --Small laser turret MK6
    ['5d-laser-turret-small-07']                            ={r=255, g=248, b=000, a=127}, --Small laser turret MK7
    ['5d-laser-turret-small-08']                            ={r=255, g=248, b=000, a=127}, --Small laser turret MK8
    ['5d-laser-turret-small-09']                            ={r=255, g=248, b=000, a=127}, --Small laser turret MK9
    ['5d-laser-turret-small-10']                            ={r=255, g=248, b=000, a=127}, --Small laser turret MK10
    ['5d-laser-turret-sniper-01']                           ={r=000, g=235, b=255, a=127}, --Sniper laser turret
    ['5d-laser-turret-sniper-02']                           ={r=000, g=235, b=255, a=127}, --Sniper laser turret MK2
    ['5d-laser-turret-sniper-03']                           ={r=000, g=235, b=255, a=127}, --Sniper laser turret MK3
    ['5d-laser-turret-sniper-04']                           ={r=000, g=235, b=255, a=127}, --Sniper laser turret MK4
    ['5d-laser-turret-sniper-05']                           ={r=000, g=235, b=255, a=127}, --Sniper laser turret MK5
    ['5d-laser-turret-sniper-06']                           ={r=000, g=235, b=255, a=127}, --Sniper laser turret MK6
    ['5d-laser-turret-sniper-07']                           ={r=000, g=235, b=255, a=127}, --Sniper laser turret MK7
    ['5d-laser-turret-sniper-08']                           ={r=000, g=235, b=255, a=127}, --Sniper laser turret MK8
    ['5d-laser-turret-sniper-09']                           ={r=000, g=235, b=255, a=127}, --Sniper laser turret MK9
    ['5d-laser-turret-sniper-10']                           ={r=000, g=235, b=255, a=127}, --Sniper laser turret MK10
    ['5d-radar-02']                                         ={r=250, g=025, b=000, a=127}, --Radar MK2
    ['5d-radar-03']                                         ={r=000, g=198, b=255, a=127}, --Radar MK3
    ['5d-radar-04']                                         ={r=248, g=074, b=234, a=127}, --Radar MK4
    ['5d-radar-05']                                         ={r=022, g=255, b=009, a=127}, --Radar MK5
    ['5d-radar-06']                                         ={r=178, g=107, b=055, a=127}, --Radar MK6
    ['5d-radar-07']                                         ={r=124, g=023, b=191, a=127}, --Radar MK7
    ['5d-radar-08']                                         ={r=252, g=252, b=248, a=127}, --Radar MK8
    ['5d-radar-09']                                         ={r=255, g=121, b=000, a=127}, --Radar MK9
    ['5d-radar-10']                                         ={r=025, g=029, b=252, a=127}, --Radar MK10
    ['5d-stone-wall-02']                                    ={r=250, g=025, b=000, a=127}, --Stone wall MK2
    ['5d-stone-wall-03']                                    ={r=000, g=198, b=255, a=127}, --Stone wall MK3
    ['5d-stone-wall-04']                                    ={r=248, g=074, b=234, a=127}, --Stone wall MK4
    ['5d-stone-wall-05']                                    ={r=022, g=255, b=009, a=127}, --Stone wall MK5
    ['5d-stone-wall-06']                                    ={r=178, g=107, b=055, a=127}, --Stone wall MK6
    ['5d-stone-wall-07']                                    ={r=124, g=023, b=191, a=127}, --Stone wall MK7
    ['5d-stone-wall-08']                                    ={r=252, g=252, b=248, a=127}, --Stone wall MK8
    ['5d-stone-wall-09']                                    ={r=255, g=121, b=000, a=127}, --Stone wall MK9
    ['5d-stone-wall-10']                                    ={r=025, g=029, b=252, a=127}, --Stone wall MK10
    ['5d-tesla-turret-01']                                  ={r=124, g=023, b=191, a=127}, --Tesla turret MK1
    ['5d-tesla-turret-02']                                  ={r=124, g=023, b=191, a=127}, --Tesla turret MK2
    ['5d-tesla-turret-03']                                  ={r=124, g=023, b=191, a=127}, --Tesla turret MK3
    ['5d-tesla-turret-04']                                  ={r=124, g=023, b=191, a=127}, --Tesla turret MK4
    ['5d-tesla-turret-05']                                  ={r=124, g=023, b=191, a=127}, --Tesla turret MK5
    ['5d-tesla-turret-06']                                  ={r=124, g=023, b=191, a=127}, --Tesla turret MK6
    ['5d-tesla-turret-07']                                  ={r=124, g=023, b=191, a=127}, --Tesla turret MK7
    ['5d-tesla-turret-08']                                  ={r=124, g=023, b=191, a=127}, --Tesla turret MK8
    ['5d-tesla-turret-09']                                  ={r=124, g=023, b=191, a=127}, --Tesla turret MK9
    ['5d-tesla-turret-10']                                  ={r=124, g=023, b=191, a=127}, --Tesla turret MK10
    ['flamethrower-turret-5db']                             ={r=255, g=207, b=000, a=127}, --Flamethrower turret
    ['gate-5db']                                            ={r=255, g=207, b=000, a=127}, --Gate MK1
    ['gun-turret-5db']                                      ={r=250, g=025, b=000, a=127}, --Gun turret
    ['laser-turret-5db']                                    ={r=250, g=025, b=000, a=127}, --Laser turret MK1
    ['radar-5db']                                           ={r=255, g=207, b=000, a=127}, --Radar MK1
    ['stone-wall-5db']                                      ={r=255, g=207, b=000, a=127}, --Stone Wall MK1
}

_5dim_battlefield_filters={
    "flamethrower-turret",
    "gate",
    "gun-turret",
    "laser-turret",
    "radar",
    "stone-wall",
}