_5dim_trains={
    ['5d-cargo-wagon-2']                                    ={r=104, g=097, b=192, a=127}, --Wagon MK2
    ['5d-cargo-wagon-3']                                    ={r=068, g=173, b=061, a=127}, --Wagon MK3
    ['5d-fluid-wagon-2']                                    ={r=086, g=080, b=181, a=127}, --Fluid wagon MK2
    ['5d-fluid-wagon-3']                                    ={r=098, g=185, b=089, a=127}, --Fluid wagon MK3
    ['5d-locomotive-hs']                                    ={r=087, g=055, b=154, a=127}, --High speed locomotive
    ['5d-locomotive-reinforced']                            ={r=100, g=085, b=074, a=127}, --Reinforced locomotive
}