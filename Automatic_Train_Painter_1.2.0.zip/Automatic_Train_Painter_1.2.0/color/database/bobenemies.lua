bobenemies={
    ['alien-artifact']                                      ={r=209, g=043, b=255, a=127}, --Alien artifact
    ['alien-artifact-blue']                                 ={r=000, g=126, b=255, a=127}, --Blue alien artifact
    ['alien-artifact-green']                                ={r=000, g=255, b=001, a=127}, --Green alien artifact
    ['alien-artifact-orange']                               ={r=255, g=122, b=000, a=127}, --Orange alien artifact
    ['alien-artifact-purple']                               ={r=071, g=000, b=255, a=127}, --Purple alien artifact
    ['alien-artifact-red']                                  ={r=255, g=011, b=000, a=127}, --Red alien artifact
    ['alien-artifact-yellow']                               ={r=255, g=211, b=000, a=127}, --Yellow alien artifact
    ['small-alien-artifact-blue']                           ={r=000, g=126, b=255, a=127}, --Small blue alien artifact
    ['small-alien-artifact-boben']                          ={r=209, g=043, b=255, a=127}, --Small alien artifact
    ['small-alien-artifact-green']                          ={r=000, g=255, b=001, a=127}, --Small green alien artifact
    ['small-alien-artifact-orange']                         ={r=255, g=122, b=000, a=127}, --Small orange alien artifact
    ['small-alien-artifact-purple']                         ={r=071, g=000, b=255, a=127}, --Small purple alien artifact
    ['small-alien-artifact-red']                            ={r=255, g=011, b=000, a=127}, --Small red alien artifact
    ['small-alien-artifact-yellow']                         ={r=255, g=211, b=000, a=127}, --Small yellow alien artifact
}

bobenemies_filters={
    "small-alien-artifact",
}