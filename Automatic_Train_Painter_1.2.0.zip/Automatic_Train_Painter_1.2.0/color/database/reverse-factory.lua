reverse_factory={
    ['reverse-factory-1']                                   ={r=020, g=221, b=000, a=127}, --Reverse Factory 1
    ['reverse-factory-2']                                   ={r=020, g=221, b=000, a=127}, --Reverse Factory 2
    ['reverse-factory-3']                                   ={r=025, g=255, b=000, a=127}, --Reverse Factory 3
    ['reverse-factory-4']                                   ={r=025, g=255, b=000, a=127}, --Reverse Factory 4
}