aai_vehicles_chaingunner={
    ['vehicle-chaingunner']                                 ={r=255, g=126, b=000, a=127}, --Chaingunner
    ['vehicle-chaingunner-gun']                             ={r=255, g=126, b=000, a=127}, --Chaingun
    ['vehicle-chaingunner-vehicle-chaingunner-gun']         ={r=255, g=126, b=000, a=127}, --AI Chaingunner
}