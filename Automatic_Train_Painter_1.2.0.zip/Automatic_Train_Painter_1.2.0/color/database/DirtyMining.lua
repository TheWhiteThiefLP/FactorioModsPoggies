DirtyMining={
    ['dirty-planner']                                       ={r=166, g=000, b=179, a=127}, --Dirty Mining Planner
    ['ore-washer']                                          ={r=187, g=102, b=000, a=127}, --Ore Washing Plant
    ['pebbles']                                             ={r=134, g=109, b=070, a=127}, --Pebbles
    ['twig']                                                ={r=091, g=026, b=000, a=127}, --Twig
}
