_5dim_equipment={
    ['5d-battery-equipment-03']                             ={r=000, g=198, b=255, a=127}, --Battery MK3
    ['5d-battery-equipment-04']                             ={r=248, g=074, b=234, a=127}, --Battery MK4
    ['5d-battery-equipment-05']                             ={r=022, g=255, b=009, a=127}, --Battery MK5
    ['5d-battery-equipment-06']                             ={r=178, g=107, b=055, a=127}, --Battery MK6
    ['5d-battery-equipment-07']                             ={r=124, g=023, b=191, a=127}, --Battery MK7
    ['5d-battery-equipment-08']                             ={r=252, g=252, b=248, a=127}, --Battery MK8
    ['5d-battery-equipment-09']                             ={r=255, g=121, b=000, a=127}, --Battery MK9
    ['5d-battery-equipment-10']                             ={r=025, g=029, b=252, a=127}, --Battery MK10
    ['5d-energy-shield-equipment-03']                       ={r=000, g=198, b=255, a=127}, --Energy shield MK3
    ['5d-energy-shield-equipment-04']                       ={r=248, g=074, b=234, a=127}, --Energy shield MK4
    ['5d-energy-shield-equipment-05']                       ={r=022, g=255, b=009, a=127}, --Energy shield MK5
    ['5d-energy-shield-equipment-06']                       ={r=178, g=107, b=055, a=127}, --Energy shield MK6
    ['5d-energy-shield-equipment-07']                       ={r=124, g=023, b=191, a=127}, --Energy shield MK7
    ['5d-energy-shield-equipment-08']                       ={r=252, g=252, b=248, a=127}, --Energy shield MK8
    ['5d-energy-shield-equipment-09']                       ={r=255, g=121, b=000, a=127}, --Energy shield MK9
    ['5d-energy-shield-equipment-10']                       ={r=025, g=029, b=252, a=127}, --Energy shield MK10
    ['5d-exoskeleton-equipment-02']                         ={r=250, g=025, b=000, a=127}, --Exoskeleton MK2
    ['5d-exoskeleton-equipment-03']                         ={r=000, g=198, b=255, a=127}, --Exoskeleton MK3
    ['5d-exoskeleton-equipment-04']                         ={r=248, g=074, b=234, a=127}, --Exoskeleton MK4
    ['5d-exoskeleton-equipment-05']                         ={r=022, g=255, b=009, a=127}, --Exoskeleton MK5
    ['5d-exoskeleton-equipment-06']                         ={r=178, g=107, b=055, a=127}, --Exoskeleton MK6
    ['5d-exoskeleton-equipment-07']                         ={r=124, g=023, b=191, a=127}, --Exoskeleton MK7
    ['5d-exoskeleton-equipment-08']                         ={r=252, g=252, b=248, a=127}, --Exoskeleton MK8
    ['5d-exoskeleton-equipment-09']                         ={r=255, g=121, b=000, a=127}, --Exoskeleton MK9
    ['5d-exoskeleton-equipment-10']                         ={r=025, g=029, b=252, a=127}, --Exoskeleton MK10
    ['5d-fusion-reactor-equipment-02']                      ={r=250, g=025, b=000, a=127}, --Fusion reactor MK2
    ['5d-fusion-reactor-equipment-03']                      ={r=000, g=198, b=255, a=127}, --Fusion reactor MK3
    ['5d-fusion-reactor-equipment-04']                      ={r=248, g=074, b=234, a=127}, --Fusion reactor MK4
    ['5d-fusion-reactor-equipment-05']                      ={r=022, g=255, b=009, a=127}, --Fusion reactor MK5
    ['5d-fusion-reactor-equipment-06']                      ={r=178, g=107, b=055, a=127}, --Fusion reactor MK6
    ['5d-fusion-reactor-equipment-07']                      ={r=124, g=023, b=191, a=127}, --Fusion reactor MK7
    ['5d-fusion-reactor-equipment-08']                      ={r=252, g=252, b=248, a=127}, --Fusion reactor MK8
    ['5d-fusion-reactor-equipment-09']                      ={r=255, g=121, b=000, a=127}, --Fusion reactor MK9
    ['5d-fusion-reactor-equipment-10']                      ={r=025, g=029, b=252, a=127}, --Fusion reactor MK10
    ['5d-night-vision-equipment-02']                        ={r=250, g=025, b=000, a=127}, --Night vision MK2
    ['5d-personal-laser-defense-equipment-02']              ={r=250, g=025, b=000, a=127}, --Personal laser defense MK2
    ['5d-personal-laser-defense-equipment-03']              ={r=000, g=198, b=255, a=127}, --Personal laser defense MK3
    ['5d-personal-laser-defense-equipment-04']              ={r=248, g=074, b=234, a=127}, --Personal laser defense MK4
    ['5d-personal-laser-defense-equipment-05']              ={r=022, g=255, b=009, a=127}, --Personal laser defense MK5
    ['5d-personal-laser-defense-equipment-06']              ={r=178, g=107, b=055, a=127}, --Personal laser defense MK6
    ['5d-personal-laser-defense-equipment-07']              ={r=124, g=023, b=191, a=127}, --Personal laser defense MK7
    ['5d-personal-laser-defense-equipment-08']              ={r=252, g=252, b=248, a=127}, --Personal laser defense MK8
    ['5d-personal-laser-defense-equipment-09']              ={r=255, g=121, b=000, a=127}, --Personal laser defense MK9
    ['5d-personal-laser-defense-equipment-10']              ={r=025, g=029, b=252, a=127}, --Personal laser defense MK10
    ['5d-personal-roboport-equipment-03']                   ={r=000, g=198, b=255, a=127}, --Personal roboport MK3
    ['5d-personal-roboport-equipment-04']                   ={r=248, g=074, b=234, a=127}, --Personal roboport MK4
    ['5d-personal-roboport-equipment-05']                   ={r=022, g=255, b=009, a=127}, --Personal roboport MK5
    ['5d-personal-roboport-equipment-06']                   ={r=178, g=107, b=055, a=127}, --Personal roboport MK6
    ['5d-personal-roboport-equipment-07']                   ={r=124, g=023, b=191, a=127}, --Personal roboport MK7
    ['5d-personal-roboport-equipment-08']                   ={r=252, g=252, b=248, a=127}, --Personal roboport MK8
    ['5d-personal-roboport-equipment-09']                   ={r=255, g=121, b=000, a=127}, --Personal roboport MK9
    ['5d-personal-roboport-equipment-10']                   ={r=025, g=029, b=252, a=127}, --Personal roboport MK10
    ['5d-personal-tesla-defense-equipment-01']              ={r=255, g=207, b=000, a=127}, --Personal tesla defense MK1
    ['5d-personal-tesla-defense-equipment-02']              ={r=250, g=025, b=000, a=127}, --Personal tesla defense MK2
    ['5d-personal-tesla-defense-equipment-03']              ={r=000, g=198, b=255, a=127}, --Personal tesla defense MK3
    ['5d-personal-tesla-defense-equipment-04']              ={r=248, g=074, b=234, a=127}, --Personal tesla defense MK4
    ['5d-personal-tesla-defense-equipment-05']              ={r=022, g=255, b=009, a=127}, --Personal tesla defense MK5
    ['5d-personal-tesla-defense-equipment-06']              ={r=178, g=107, b=055, a=127}, --Personal tesla defense MK6
    ['5d-personal-tesla-defense-equipment-07']              ={r=124, g=023, b=191, a=127}, --Personal tesla defense MK7
    ['5d-personal-tesla-defense-equipment-08']              ={r=252, g=252, b=248, a=127}, --Personal tesla defense MK8
    ['5d-personal-tesla-defense-equipment-09']              ={r=255, g=121, b=000, a=127}, --Personal tesla defense MK9
    ['5d-personal-tesla-defense-equipment-10']              ={r=025, g=029, b=252, a=127}, --Personal tesla defense MK10
    ['5d-power-armor-03']                                   ={r=000, g=198, b=255, a=127}, --Power armor MK3
    ['5d-power-armor-04']                                   ={r=248, g=074, b=234, a=127}, --Power armor MK4
    ['5d-power-armor-05']                                   ={r=022, g=255, b=009, a=127}, --Power armor MK5
    ['5d-power-armor-06']                                   ={r=178, g=107, b=055, a=127}, --Power armor MK6
    ['5d-power-armor-07']                                   ={r=124, g=023, b=191, a=127}, --Power armor MK7
    ['5d-power-armor-08']                                   ={r=252, g=252, b=248, a=127}, --Power armor MK8
    ['5d-power-armor-09']                                   ={r=255, g=121, b=000, a=127}, --Power armor MK9
    ['5d-power-armor-10']                                   ={r=025, g=029, b=252, a=127}, --Power armor MK10
    ['5d-solar-panel-equipment-02']                         ={r=250, g=025, b=000, a=127}, --Portable solar panel MK2
    ['5d-solar-panel-equipment-03']                         ={r=000, g=198, b=255, a=127}, --Portable solar panel MK3
    ['5d-solar-panel-equipment-04']                         ={r=248, g=074, b=234, a=127}, --Portable solar panel MK4
    ['5d-solar-panel-equipment-05']                         ={r=022, g=255, b=009, a=127}, --Portable solar panel MK5
    ['5d-solar-panel-equipment-06']                         ={r=178, g=107, b=055, a=127}, --Portable solar panel MK6
    ['5d-solar-panel-equipment-07']                         ={r=124, g=023, b=191, a=127}, --Portable solar panel MK7
    ['5d-solar-panel-equipment-08']                         ={r=252, g=252, b=248, a=127}, --Portable solar panel MK8
    ['5d-solar-panel-equipment-09']                         ={r=255, g=121, b=000, a=127}, --Portable solar panel MK9
    ['5d-solar-panel-equipment-10']                         ={r=025, g=029, b=252, a=127}, --Portable solar panel MK10
    ['battery-equipment-5deq']                              ={r=255, g=207, b=000, a=127}, --Personal battery
    ['battery-mk2-equipment-5deq']                          ={r=250, g=025, b=000, a=127}, --Personal battery MK2
    ['energy-shield-equipment-5deq']                        ={r=255, g=207, b=000, a=127}, --Energy shield
    ['energy-shield-mk2-equipment-5deq']                    ={r=250, g=025, b=000, a=127}, --Energy shield MK2
    ['exoskeleton-equipment-5deq']                          ={r=255, g=207, b=000, a=127}, --Exoskeleton
    ['fusion-reactor-equipment-5deq']                       ={r=255, g=207, b=000, a=127}, --Portable fusion reactor
    ['night-vision-equipment-5deq']                         ={r=255, g=207, b=000, a=127}, --Nightvision
    ['personal-laser-defense-equipment-5deq']               ={r=255, g=207, b=000, a=127}, --Personal laser defense
    ['personal-roboport-equipment-5deq']                    ={r=255, g=207, b=000, a=127}, --Personal roboport
    ['personal-roboport-mk2-equipment-5deq']                ={r=250, g=025, b=000, a=127}, --Personal roboport MK2
    ['power-armor-5deq']                                    ={r=255, g=207, b=000, a=127}, --Power armor
    ['power-armor-mk2-5deq']                                ={r=250, g=025, b=000, a=127}, --Power armor MK2
    ['solar-panel-equipment-5deq']                          ={r=255, g=207, b=000, a=127}, --Portable solar panel
}

_5dim_equipment_filters={
    "battery-equipment",
    "battery-mk2-equipment",
    "energy-shield-equipment",
    "energy-shield-mk2-equipment",
    "exoskeleton-equipment",
    "fusion-reactor-equipment",
    "night-vision-equipment",
    "personal-laser-defense-equipment",
    "personal-roboport-equipment",
    "personal-roboport-mk2-equipment",
    "power-armor",
    "power-armor-mk2",
    "solar-panel-equipment",
}