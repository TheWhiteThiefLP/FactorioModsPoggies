omnimatter_energy={
    ['anbaric-omnitor']                                     ={r=197, g=197, b=197, a=127}, --Anbaric omnitor
    ['basic-splitter-ome']                                  ={r=226, g=213, b=206, a=127}, --Basic splitter
    ['basic-transport-belt-ome']                            ={r=226, g=213, b=206, a=127}, --Basic transport belt
    ['basic-underground-belt-ome']                          ={r=226, g=213, b=206, a=127}, --Basic underground belt
    ['burner-filter-inserter']                              ={r=120, g=026, b=178, a=127}, --Burner filter inserter
    ['crystal-panel']                                       ={r=241, g=232, b=241, a=127}, --Crystal panel
    ['crystal-solar-panel-tier-1-size-1']                   ={r=222, g=172, b=226, a=127}, --Crystal solar panel tier 1 size 1
    ['crystal-solar-panel-tier-1-size-2']                   ={r=222, g=172, b=226, a=127}, --Crystal solar panel tier 1 size 2
    ['crystal-solar-panel-tier-1-size-3']                   ={r=222, g=172, b=226, a=127}, --Crystal solar panel tier 1 size 3
    ['crystal-solar-panel-tier-1-size-4']                   ={r=222, g=172, b=226, a=127}, --Crystal solar panel tier 1 size 4
    ['crystal-solar-panel-tier-1-size-5']                   ={r=222, g=172, b=226, a=127}, --Crystal solar panel tier 1 size 5
    ['crystal-solar-panel-tier-2-size-1']                   ={r=222, g=172, b=226, a=127}, --Crystal solar panel tier 2 size 1
    ['crystal-solar-panel-tier-2-size-2']                   ={r=222, g=172, b=226, a=127}, --Crystal solar panel tier 2 size 2
    ['crystal-solar-panel-tier-2-size-3']                   ={r=222, g=172, b=226, a=127}, --Crystal solar panel tier 2 size 3
    ['crystal-solar-panel-tier-2-size-4']                   ={r=222, g=172, b=226, a=127}, --Crystal solar panel tier 2 size 4
    ['crystal-solar-panel-tier-2-size-5']                   ={r=222, g=172, b=226, a=127}, --Crystal solar panel tier 2 size 5
    ['crystal-solar-panel-tier-3-size-1']                   ={r=222, g=172, b=226, a=127}, --Crystal solar panel tier 3 size 1
    ['crystal-solar-panel-tier-3-size-2']                   ={r=222, g=172, b=226, a=127}, --Crystal solar panel tier 3 size 2
    ['crystal-solar-panel-tier-3-size-3']                   ={r=222, g=172, b=226, a=127}, --Crystal solar panel tier 3 size 3
    ['crystal-solar-panel-tier-3-size-4']                   ={r=222, g=172, b=226, a=127}, --Crystal solar panel tier 3 size 4
    ['crystal-solar-panel-tier-3-size-5']                   ={r=222, g=172, b=226, a=127}, --Crystal solar panel tier 3 size 5
    ['energy-science-pack']                                 ={r=002, g=001, b=215, a=127}, --Energy science pack
    ['omnictor']                                            ={r=067, g=082, b=067, a=127}, --Omnictor
    ['omni-furnace-1']                                      ={r=150, g=000, b=226, a=127}, --Omnifurnace Mk 1
    ['omni-furnace-2']                                      ={r=150, g=000, b=226, a=127}, --Omnifurnace Mk 2
    ['omni-furnace-3']                                      ={r=150, g=000, b=226, a=127}, --Omnifurnace Mk 3
    ['omni-heat-burner']                                    ={r=090, g=059, b=097, a=127}, --Omnium heat turbine
    ['omni-solar-road']                                     ={r=089, g=000, b=137, a=127}, --Solar road
    ['omni-tablet']                                         ={r=109, g=025, b=181, a=127}, --Omnite tablet
    ['omnitor']                                             ={r=178, g=178, b=170, a=127}, --Omnitor
    ['omnitor-assembling-machine']                          ={r=107, g=060, b=146, a=127}, --Omnitor assembling machine
    ['omnitor-lab']                                         ={r=255, g=000, b=227, a=127}, --Omnitor lab
    ['omnium']                                              ={r=139, g=000, b=255, a=127}, --Omnium
    ['purified-omnite']                                     ={r=089, g=000, b=137, a=127}, --Purified omnite
    ['small-iron-electric-pole-ome']                        ={r=198, g=115, b=000, a=127}, --Small iron anbaric pole
    ['small-omnicium-electric-pole']                        ={r=198, g=115, b=000, a=127}, --Small omnicium anbaric pole
}