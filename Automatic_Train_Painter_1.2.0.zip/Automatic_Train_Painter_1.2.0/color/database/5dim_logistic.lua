_5dim_logistic={
    ['5d-active']                                           ={r=106, g=008, b=149, a=127}, --Active provider chest MK2
    ['5d-construction-robot-2']                             ={r=216, g=025, b=072, a=127}, --Construction Robot MK2
    ['5d-construction-robot-3']                             ={r=197, g=251, b=035, a=127}, --Construction Robot MK3
    ['5d-construction-robot-4']                             ={r=255, g=215, b=031, a=127}, --Construction Robot MK4
    ['5d-construction-robot-p']                             ={r=255, g=130, b=024, a=127}, --Personal construction robot
    ['5d-logistic-robot-2']                                 ={r=218, g=152, b=159, a=127}, --Logistic Robot MK2
    ['5d-logistic-robot-3']                                 ={r=157, g=168, b=062, a=127}, --Logistic Robot MK3
    ['5d-logistic-robot-4']                                 ={r=255, g=241, b=148, a=127}, --Logistic Robot MK4
    ['5d-passive']                                          ={r=199, g=041, b=000, a=127}, --Passive provider chest MK2
    ['5d-repair-pack-2']                                    ={r=215, g=224, b=228, a=127}, --Repair pack MK2
    ['5d-requester']                                        ={r=000, g=054, b=149, a=127}, --Requester Chest MK2
    ['5d-roboport-2']                                       ={r=156, g=053, b=102, a=127}, --Roboport MK2
    ['5d-roboport-3']                                       ={r=047, g=108, b=036, a=127}, --Roboport MK3
    ['5d-roboport-4']                                       ={r=152, g=145, b=059, a=127}, --Roboport MK4
    ['5d-storage']                                          ={r=229, g=170, b=042, a=127}, --Storage Chest MK2
}