aai_vehicles_warden={
    ['electro-bolter-gun']                                  ={r=252, g=110, b=000, a=127}, --Electro-Bolter
    ['electroshock-pulse-ammo']                             ={r=000, g=218, b=255, a=127}, --Electroshock Pulse Ammo
    ['vehicle-warden']                                      ={r=252, g=110, b=000, a=127}, --Warden
    ['vehicle-warden-electro-bolter-gun']                   ={r=252, g=110, b=000, a=127}, --AI Warden
}