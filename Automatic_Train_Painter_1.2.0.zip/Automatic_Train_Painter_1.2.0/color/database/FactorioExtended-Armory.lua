FactorioExtended_Armory={
    ['firearm-magazine-1']                                  ={r=241, g=211, b=000, a=127}, --Firearm Magazine Mk1
    ['firearm-magazine-2']                                  ={r=241, g=211, b=000, a=127}, --Firearm Magazine Mk2
    ['piercing-rounds-magazine-1']                          ={r=211, g=000, b=001, a=127}, --Piercing Rounds Magazine Mk1
    ['piercing-rounds-magazine-2']                          ={r=211, g=000, b=001, a=127}, --Piercing Rounds Magazine Mk2
    ['piercing-shotgun-shell-1']                            ={r=002, g=101, b=151, a=127}, --Piercing Shotgun Shell Mk1
    ['piercing-shotgun-shell-2']                            ={r=002, g=101, b=151, a=127}, --Piercing Shotgun Shell Mk2
    ['shotgun-shell-1']                                     ={r=254, g=012, b=000, a=127}, --Shotgun Shell Mk1
    ['shotgun-shell-2']                                     ={r=254, g=012, b=000, a=127}, --Shotgun Shell Mk2
    ['uranium-rounds-magazine-1']                           ={r=000, g=255, b=008, a=127}, --Uranium Rounds Magazine Mk1
    ['uranium-rounds-magazine-2']                           ={r=000, g=255, b=008, a=127}, --Uranium Rounds Magazine Mk2
}