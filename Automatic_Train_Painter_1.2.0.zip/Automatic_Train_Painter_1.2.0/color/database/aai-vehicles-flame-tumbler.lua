aai_vehicles_flame_tumbler={
    ['flamejet-ammo-aaivft2']                               ={r=197, g=096, b=049, a=127}, --Flamejet Ammo
    ['flame-tumbler-flame-thrower']                         ={r=255, g=138, b=000, a=127}, --Flame Thrower
    ['vehicle-flame-tumbler']                               ={r=255, g=138, b=000, a=127}, --Flame Tumbler
    ['vehicle-flame-tumbler-flame-tumbler-flamethrower']    ={r=255, g=138, b=000, a=127}, --AI Flame Tumbler
}

aai_vehicles_flame_tumbler_filters={
    "flamejet-ammo",
}
