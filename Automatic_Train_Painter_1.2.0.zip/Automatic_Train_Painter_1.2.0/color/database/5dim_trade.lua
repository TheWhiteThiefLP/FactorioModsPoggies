_5dim_trade={
    ['5d-coin']                                         ={r=255, g=183, b=000, a=127}, --5D coin
    ['5d-trader']                                       ={r=143, g=143, b=074, a=127}, --Trader
}