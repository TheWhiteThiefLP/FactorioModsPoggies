aai_vehicles_hauler={
    ['vehicle-hauler']                                      ={r=255, g=131, b=000, a=127}, --Hauler
    ['vehicle-hauler-0']                                    ={r=255, g=131, b=000, a=127}, --AI Hauler
}