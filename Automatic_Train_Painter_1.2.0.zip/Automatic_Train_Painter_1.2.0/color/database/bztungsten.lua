bztungsten={
    ['compressed-tungsten-ore']                             ={r=215, g=209, b=154, a=127}, --Compressed tungsten ore
    ['enriched-tungsten']                                   ={r=089, g=073, b=095, a=127}, --Enriched tungsten
    ['rocket-engine-nozzle']                                ={r=202, g=202, b=202, a=127}, --Rocket engine nozzle
    ['tungsten-carbide-bzw']                                ={r=221, g=214, b=201, a=127}, --Tungsten carbide
    ['tungsten-dust']                                       ={r=216, g=216, b=202, a=127}, --Tungsten dust
    ['tungsten-ore']                                        ={r=215, g=209, b=154, a=127}, --Wolframite
    ['tungsten-plate-bzw']                                  ={r=251, g=247, b=218, a=127}, --Tungsten plate
}

bztungsten_filters={
    "tungsten-carbide",
    "tungsten-plate",
}