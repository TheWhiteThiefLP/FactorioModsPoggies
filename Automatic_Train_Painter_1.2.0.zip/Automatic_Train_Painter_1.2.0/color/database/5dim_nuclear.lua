_5dim_nuclear={
    ['5d-centrifuge-2']                                 ={r=218, g=121, b=004, a=127}, --Centrifuge MK2
    ['5d-heat-exchanger-2']                             ={r=206, g=096, b=000, a=127}, --Heat exchanger MK2
    ['5d-nuclear-reactor-2']                            ={r=216, g=081, b=000, a=127}, --Nuclear reactor MK2
    ['5d-steam-turbine-2']                              ={r=205, g=089, b=000, a=127}, --Steam turbine MK2
}