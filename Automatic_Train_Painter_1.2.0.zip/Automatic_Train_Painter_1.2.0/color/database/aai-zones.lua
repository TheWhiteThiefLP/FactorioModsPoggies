aai_zones={
    ['zone-planner']                                    ={r=070, g=070, b=070, a=127}, --Zone Planner
}