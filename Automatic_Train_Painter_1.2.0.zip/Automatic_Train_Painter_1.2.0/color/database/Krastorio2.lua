Krastorio2={
    ['additional-engine-k2']                                ={r=178, g=169, b=145, a=127}, --Additional electric engine
    ['advanced-additional-engine-k2']                       ={r=128, g=130, b=158, a=127}, --Advanced additional electric engine
    ['advanced-exoskeleton-equipment-k2']                   ={r=000, g=077, b=239, a=127}, --Advanced exoskeleton
    ['advanced-fuel']                                       ={r=131, g=053, b=188, a=127}, --Advanced fuel
    ['advanced-radar']                                      ={r=123, g=125, b=105, a=127}, --Advanced radar
    ['advanced-tech-card']                                  ={r=255, g=240, b=052, a=127}, --Advanced tech card
    ['ai-core']                                             ={r=255, g=028, b=000, a=127}, --AI core
    ['anti-material-rifle']                                 ={r=136, g=000, b=000, a=127}, --Anti-materiel rifle
    ['anti-material-rifle-magazine']                        ={r=179, g=123, b=000, a=127}, --Anti-materiel rifle magazine
    ['antimatter-artillery-shell-k2']                       ={r=232, g=000, b=195, a=127}, --Antimatter artillery shell
    ['antimatter-railgun-shell-k2']                         ={r=206, g=016, b=149, a=127}, --Antimatter railgun shell
    ['antimatter-reactor-equipment']                        ={r=000, g=246, b=255, a=127}, --Portable antimatter reactor
    ['antimatter-rocket-k2']                                ={r=255, g=000, b=228, a=127}, --Antimatter rocket
    ['antimatter-turret-rocket']                            ={r=216, g=000, b=158, a=127}, --Antimatter turret rocket
    ['armor-piercing-anti-material-rifle-magazine']         ={r=226, g=003, b=000, a=127}, --Armor piercing anti-materiel rifle magazine
    ['armor-piercing-pistol-magazine']                      ={r=192, g=030, b=000, a=127}, --Armor piercing pistol magazine
    ['armor-piercing-rifle-magazine']                       ={r=226, g=003, b=000, a=127}, --Armor piercing rifle magazine
    ['artillery-shell-k2']                                  ={r=248, g=059, b=000, a=127}, --Artillery shell
    ['atomic-bomb-k2']                                      ={r=030, g=232, b=000, a=127}, --Atomic bomb
    ['automation-core']                                     ={r=226, g=059, b=000, a=127}, --Automation core
    ['automation-science-pack-k2']                          ={r=193, g=000, b=007, a=127}, --Automation science pack
    ['automation-tech-card']                                ={r=193, g=000, b=007, a=127}, --Automation tech card
    ['basic-railgun-shell-k2']                              ={r=131, g=154, b=181, a=127}, --Railgun shell
    ['basic-tech-card']                                     ={r=146, g=098, b=053, a=127}, --Basic tech card
    ['battery-mk2-equipment-k2']                            ={r=000, g=129, b=230, a=127}, --Personal battery MK2
    ['battery-mk3-equipment-k2']                            ={r=248, g=000, b=248, a=127}, --Battery MK3
    ['big-battery-equipment-k2']                            ={r=000, g=252, b=005, a=127}, --Big personal battery
    ['big-battery-mk2-equipment-k2']                        ={r=000, g=135, b=255, a=127}, --Big personal battery MK2
    ['big-battery-mk3-equipment-k2']                        ={r=250, g=000, b=246, a=127}, --Big personal battery MK3
    ['big-imersite-solar-panel-equipment-k2']               ={r=139, g=006, b=161, a=127}, --Big portable imersite solar panel
    ['big-solar-panel-equipment-k2']                        ={r=037, g=032, b=188, a=127}, --Big portable solar panel
    ['bio-fuel']                                            ={r=034, g=133, b=032, a=127}, --Biofuel
    ['biomass']                                             ={r=146, g=112, b=136, a=127}, --Biomass
    ['biters-research-data']                                ={r=083, g=074, b=070, a=127}, --Biter research data
    ['biusart-lab']                                         ={r=000, g=117, b=214, a=127}, --Advanced lab
    ['blank-tech-card']                                     ={r=217, g=174, b=151, a=127}, --Blank tech card
    ['charged-antimatter-fuel-cell']                        ={r=227, g=000, b=255, a=127}, --Charged antimatter fuel cell
    ['charged-matter-stabilizer']                           ={r=158, g=005, b=242, a=127}, --Charged Matter stabilizer
    ['chemical-science-pack-k2']                            ={r=019, g=035, b=208, a=127}, --Chemical science pack
    ['chemical-tech-card']                                  ={r=019, g=035, b=208, a=127}, --Chemical tech card
    ['coke-k2']                                             ={r=038, g=038, b=038, a=127}, --Coke
    ['cyber-potato-equipment']                              ={r=215, g=164, b=065, a=127}, --Cyber Potato
    ['dolphin-gun-k2']                                      ={r=085, g=095, b=108, a=127}, --Space Dolphin Gun
    ['dt-fuel']                                             ={r=255, g=112, b=000, a=127}, --DT-fuel
    ['electronic-components-k2']                            ={r=094, g=169, b=000, a=127}, --Electronic components
    ['empty-antimatter-fuel-cell']                          ={r=232, g=017, b=000, a=127}, --Empty antimatter fuel cell
    ['empty-dt-fuel']                                       ={r=223, g=167, b=000, a=127}, --Empty DT-fuel
    ['energy-absorber']                                     ={r=203, g=101, b=000, a=127}, --Energy absorber
    ['energy-control-unit']                                 ={r=255, g=000, b=242, a=127}, --Energy control unit
    ['energy-shield-equipment-k2']                          ={r=000, g=226, b=005, a=127}, --Energy shield
    ['energy-shield-mk2-equipment-k2']                      ={r=041, g=158, b=250, a=127}, --Energy shield MK2
    ['energy-shield-mk3-equipment-k2']                      ={r=250, g=053, b=055, a=127}, --Shield generator MK3
    ['energy-shield-mk4-equipment-k2']                      ={r=167, g=070, b=238, a=127}, --Shield generator MK4
    ['enriched-copper-k2']                                  ={r=242, g=109, b=048, a=127}, --Enriched copper
    ['enriched-iron-k2']                                    ={r=101, g=141, b=175, a=127}, --Enriched iron
    ['enriched-rare-metals']                                ={r=255, g=193, b=044, a=127}, --Enriched rare metals
    ['explosion-railgun-shell-k2']                          ={r=209, g=021, b=000, a=127}, --Explosion railgun shell
    ['explosive-turret-rocket']                             ={r=204, g=023, b=000, a=127}, --Explosive turret rocket
    ['explosive-turret-rocket-turret']                      ={r=204, g=023, b=000, a=127}, --Explosive turret rocket
    ['fertilizer']                                          ={r=085, g=089, b=055, a=127}, --Fertilizer
    ['firearm-magazine-k2']                                 ={r=199, g=147, b=000, a=127}, --Firearm magazine
    ['first-aid-kit']                                       ={r=163, g=028, b=000, a=127}, --First aid kit
    ['fuel']                                                ={r=163, g=025, b=003, a=127}, --Fuel
    ['fusion-reactor-equipment-k2']                         ={r=255, g=204, b=000, a=127}, --Portable fusion reactor
    ['glass-k2']                                            ={r=151, g=202, b=245, a=127}, --Glass
    ['gps-satellite']                                       ={r=041, g=158, b=250, a=127}, --GPS satellite
    ['heavy-rocket-k2']                                     ={r=255, g=086, b=000, a=127}, --Heavy rocket
    ['heavy-rocket-launcher-k2']                            ={r=088, g=077, b=057, a=127}, --Heavy rocket launcher
    ['imersite-anti-material-rifle-magazine']               ={r=147, g=010, b=199, a=127}, --Imersite anti-materiel rifle magazine
    ['imersite-crystal']                                    ={r=237, g=000, b=239, a=127}, --Imersite crystal
    ['imersite-night-vision-equipment-k2']                  ={r=212, g=000, b=233, a=127}, --Imersite night vision
    ['imersite-powder-k2']                                  ={r=174, g=078, b=255, a=127}, --Imersite powder
    ['imersite-rifle-magazine']                             ={r=147, g=010, b=199, a=127}, --Imersite rifle magazine
    ['imersite-rounds-magazine-k2']                         ={r=241, g=000, b=234, a=127}, --Imersite rounds magazine
    ['imersite-solar-panel-equipment-k2']                   ={r=147, g=010, b=199, a=127}, --Portable imersite solar panel
    ['imersium-beam']                                       ={r=134, g=059, b=149, a=127}, --Imersium beam
    ['imersium-gear-wheel']                                 ={r=147, g=032, b=199, a=127}, --Imersium gear wheel
    ['imersium-plate']                                      ={r=151, g=044, b=185, a=127}, --Imersium plate
    ['improved-pollution-filter']                           ={r=226, g=164, b=000, a=127}, --Improved pollution filter
    ['impulse-rifle-ammo-k2']                               ={r=255, g=000, b=119, a=127}, --Impulse rifle ammo
    ['impulse-rifle-k2']                                    ={r=244, g=000, b=215, a=127}, --Impulse rifle
    ['inserter-parts']                                      ={r=168, g=168, b=164, a=127}, --Inserter parts
    ['iron-beam']                                           ={r=164, g=166, b=164, a=127}, --Iron beam
    ['iron-gear-wheel-k2']                                  ={r=185, g=156, b=115, a=127}, --Iron gear wheel
    ['iron-plate-k2']                                       ={r=232, g=219, b=203, a=127}, --Iron plate
    ['kr-accelerator']                                      ={r=041, g=034, b=034, a=127}, --Accelerator
    ['kr-advanced-assembling-machine']                      ={r=206, g=062, b=149, a=127}, --Advanced assembling machine
    ['kr-advanced-chemical-plant']                          ={r=048, g=064, b=145, a=127}, --Advanced chemical plant
    ['kr-advanced-furnace']                                 ={r=036, g=032, b=029, a=127}, --Advanced furnace
    ['kr-advanced-loader']                                  ={r=035, g=247, b=042, a=127}, --Advanced loader
    ['kr-advanced-solar-panel']                             ={r=093, g=028, b=124, a=127}, --Advanced solar panel
    ['kr-advanced-splitter']                                ={r=041, g=255, b=000, a=127}, --Advanced splitter
    ['kr-advanced-steam-turbine']                           ={r=068, g=068, b=073, a=127}, --Advanced steam turbine
    ['kr-advanced-tank']                                    ={r=115, g=092, b=038, a=127}, --Tank
    ['kr-advanced-transport-belt']                          ={r=072, g=255, b=000, a=127}, --Advanced transport belt
    ['kr-advanced-underground-belt']                        ={r=050, g=252, b=000, a=127}, --Advanced underground belt
    ['kr-air-purifier']                                     ={r=230, g=164, b=000, a=127}, --Air purifier
    ['kr-antimatter-reactor']                               ={r=111, g=028, b=138, a=127}, --Antimatter reactor
    ['kr-atmospheric-condenser']                            ={r=150, g=107, b=046, a=127}, --Atmospheric condenser
    ['kr-big-active-provider-container']                    ={r=135, g=000, b=169, a=127}, --Active provider warehouse
    ['kr-big-buffer-container']                             ={r=030, g=127, b=026, a=127}, --Buffer warehouse
    ['kr-big-container']                                    ={r=050, g=050, b=050, a=127}, --Warehouse
    ['kr-big-passive-provider-container']                   ={r=224, g=013, b=000, a=127}, --Passive provider warehouse
    ['kr-big-requester-container']                          ={r=000, g=078, b=181, a=127}, --Requester warehouse
    ['kr-big-storage-container']                            ={r=182, g=139, b=038, a=127}, --Storage warehouse
    ['kr-bio-lab']                                          ={r=238, g=032, b=031, a=127}, --Bio lab
    ['kr-biter-virus']                                      ={r=255, g=032, b=223, a=127}, --Anti biter virus capsule
    ['kr-black-reinforced-plate']                           ={r=076, g=070, b=070, a=127}, --Black reinforced plate
    ['kr-black-reinforced-plate-l']                         ={r=076, g=070, b=070, a=127}, --__ITEM__kr-black-reinforced-plate__ (KL)
    ['kr-creep']                                            ={r=146, g=112, b=136, a=127}, --Biter creep
    ['kr-creep-collector']                                  ={r=154, g=148, b=148, a=127}, --Creep collector
    ['kr-creep-virus']                                      ={r=255, g=032, b=223, a=127}, --Anti creep virus capsule
    ['kr-crusher']                                          ={r=193, g=141, b=000, a=127}, --Crusher
    ['kr-electric-mining-drill-mk2']                        ={r=026, g=095, b=232, a=127}, --Electric mining drill Mk2
    ['kr-electric-mining-drill-mk3']                        ={r=171, g=058, b=209, a=127}, --Electric mining drill Mk3
    ['kr-electrolysis-plant']                               ={r=026, g=082, b=156, a=127}, --Electrolysis plant
    ['kr-energy-storage']                                   ={r=095, g=088, b=095, a=127}, --Energy storage
    ['kr-express-loader']                                   ={r=000, g=128, b=238, a=127}, --Express loader
    ['kr-fast-loader']                                      ={r=255, g=000, b=000, a=127}, --Fast loader
    ['kr-filtration-plant']                                 ={r=000, g=093, b=158, a=127}, --Filtration plant
    ['kr-fluid-burner']                                     ={r=220, g=167, b=000, a=127}, --Fluid burner
    ['kr-fluid-storage-1']                                  ={r=157, g=116, b=082, a=127}, --Large storage tank
    ['kr-fluid-storage-2']                                  ={r=157, g=116, b=082, a=127}, --Huge storage tank
    ['kr-fuel-refinery']                                    ={r=210, g=038, b=000, a=127}, --Fuel refinery
    ['kr-fusion-reactor']                                   ={r=194, g=139, b=000, a=127}, --Fusion reactor
    ['kr-gas-power-station']                                ={r=167, g=102, b=073, a=127}, --Gas power station
    ['kr-greenhouse']                                       ={r=067, g=179, b=035, a=127}, --Greenhouse
    ['kr-intergalactic-transceiver']                        ={r=236, g=000, b=154, a=127}, --Intergalactic transceiver
    ['kr-jackhammer']                                       ={r=187, g=117, b=000, a=127}, --Jackhammer
    ['kr-large-roboport']                                   ={r=236, g=170, b=000, a=127}, --Large roboport
    ['kr-laser-artillery-turret']                           ={r=230, g=171, b=000, a=127}, --Laser artillery turret
    ['kr-loader']                                           ={r=234, g=169, b=000, a=127}, --Loader
    ['kr-matter-assembler']                                 ={r=000, g=255, b=255, a=127}, --Matter assembler
    ['kr-matter-plant']                                     ={r=155, g=011, b=211, a=127}, --Matter plant
    ['kr-medium-active-provider-container']                 ={r=135, g=000, b=169, a=127}, --Medium active provider container
    ['kr-medium-buffer-container']                          ={r=030, g=127, b=026, a=127}, --Medium buffer container
    ['kr-medium-container']                                 ={r=050, g=050, b=050, a=127}, --Medium container
    ['kr-medium-passive-provider-container']                ={r=224, g=013, b=000, a=127}, --Medium passive provider container
    ['kr-medium-requester-container']                       ={r=000, g=078, b=181, a=127}, --Medium requester container
    ['kr-medium-storage-container']                         ={r=182, g=139, b=038, a=127}, --Medium storage container
    ['kr-mineral-water-pumpjack']                           ={r=022, g=143, b=141, a=127}, --Mineral water pumpjack
    ['kr-note-1']                                           ={r=255, g=206, b=000, a=127}, --Mystery note
    ['kr-nuclear-locomotive']                               ={r=090, g=216, b=061, a=127}, --Nuclear locomotive
    ['kr-oil-pumpjack']                                     ={r=041, g=034, b=032, a=127}, --Oil pumpjack
    ['kr-quantum-computer']                                 ={r=050, g=057, b=156, a=127}, --Quantum computer
    ['kr-quarry-drill']                                     ={r=049, g=056, b=190, a=127}, --Quarry drill
    ['kr-railgun-turret']                                   ={r=233, g=167, b=000, a=127}, --Railgun turret
    ['kr-research-server']                                  ={r=233, g=167, b=000, a=127}, --Research server
    ['kr-rocket-turret']                                    ={r=212, g=155, b=000, a=127}, --Rocket turret
    ['kr-sentinel']                                         ={r=238, g=173, b=000, a=127}, --Sentinel
    ['kr-shelter']                                          ={r=235, g=169, b=000, a=127}, --Shelter
    ['kr-shelter-plus']                                     ={r=240, g=235, b=229, a=127}, --Advanced shelter
    ['kr-singularity-beacon']                               ={r=088, g=075, b=052, a=127}, --Singularity beacon
    ['kr-singularity-lab']                                  ={r=034, g=059, b=155, a=127}, --Singularity lab
    ['kr-small-roboport']                                   ={r=197, g=140, b=000, a=127}, --Small roboport
    ['kr-stabilizer-charging-station']                      ={r=115, g=036, b=110, a=127}, --Stabilizer charging station
    ['kr-steel-pipe']                                       ={r=159, g=161, b=168, a=127}, --Steel pipe
    ['kr-steel-pipe-to-ground']                             ={r=130, g=140, b=151, a=127}, --Steel underground pipe
    ['kr-steel-pump']                                       ={r=098, g=122, b=124, a=127}, --Steel pump
    ['kr-substation-mk2']                                   ={r=093, g=066, b=152, a=127}, --Substation mk2
    ['kr-superior-filter-inserter']                         ={r=140, g=000, b=197, a=127}, --Superior filter inserter
    ['kr-superior-inserter']                                ={r=067, g=082, b=082, a=127}, --Superior inserter
    ['kr-superior-loader']                                  ={r=187, g=000, b=248, a=127}, --Superior loader
    ['kr-superior-long-filter-inserter']                    ={r=223, g=198, b=040, a=127}, --Superior long filter inserter
    ['kr-superior-long-inserter']                           ={r=255, g=026, b=000, a=127}, --Superior long inserter
    ['kr-superior-splitter']                                ={r=138, g=000, b=226, a=127}, --Superior splitter
    ['kr-superior-transport-belt']                          ={r=170, g=000, b=255, a=127}, --Superior transport belt
    ['kr-superior-underground-belt']                        ={r=136, g=000, b=221, a=127}, --Superior underground belt
    ['kr-tesla-coil']                                       ={r=206, g=158, b=061, a=127}, --Tesla coil
    ['kr-void']                                             ={r=005, g=005, b=005, a=127}, --Nothing
    ['kr-white-reinforced-plate']                           ={r=145, g=138, b=133, a=127}, --Light reinforced plate
    ['kr-white-reinforced-plate-l']                         ={r=145, g=138, b=133, a=127}, --__ITEM__kr-white-reinforced-plate__ (KL)
    ['kr-wind-turbine']                                     ={r=230, g=170, b=000, a=127}, --Wind turbine
    ['lithium-chloride-k2']                                 ={r=216, g=230, b=255, a=127}, --Lithium chloride
    ['lithium-k2']                                          ={r=096, g=096, b=080, a=127}, --Lithium
    ['lithium-sulfur-battery']                              ={r=255, g=197, b=000, a=127}, --Lithium–sulfur battery
    ['logistic-science-pack-k2']                            ={r=007, g=166, b=013, a=127}, --Logistic science pack
    ['logistic-tech-card']                                  ={r=007, g=166, b=013, a=127}, --Logistic tech card
    ['matter-cube-k2']                                      ={r=055, g=158, b=232, a=127}, --Matter cube
    ['matter-research-data-k2']                             ={r=140, g=246, b=250, a=127}, --Matter research data
    ['matter-stabilizer']                                   ={r=159, g=000, b=187, a=127}, --Matter stabilizer
    ['matter-stabilizer-k2']                                ={r=147, g=000, b=187, a=127}, --Matter stabilizer
    ['matter-tech-card']                                    ={r=019, g=174, b=188, a=127}, --Matter tech card
    ['military-science-pack-k2']                            ={r=179, g=173, b=166, a=127}, --Military science pack
    ['military-tech-card']                                  ={r=179, g=173, b=166, a=127}, --Military tech card
    ['nuclear-artillery-shell']                             ={r=015, g=241, b=000, a=127}, --Nuclear artillery shell
    ['nuclear-reactor-equipment']                           ={r=006, g=255, b=000, a=127}, --Portable nuclear reactor
    ['nuclear-turret-rocket']                               ={r=000, g=217, b=003, a=127}, --Nuclear turret rocket
    ['optimization-tech-card']                              ={r=091, g=082, b=077, a=127}, --Optimization tech card
    ['personal-laser-defense-equipment-k2']                 ={r=000, g=255, b=042, a=127}, --Personal laser defense
    ['personal-laser-defense-mk2-equipment-k2']             ={r=000, g=146, b=255, a=127}, --Personal laser defense MK2
    ['personal-laser-defense-mk3-equipment']                ={r=255, g=000, b=009, a=127}, --Personal laser defense MK3
    ['personal-laser-defense-mk4-equipment']                ={r=240, g=000, b=255, a=127}, --Personal laser defense MK4
    ['personal-sniper-laser-defense-mk1-equipment-k2']      ={r=000, g=255, b=042, a=127}, --Personal sniper laser defense
    ['personal-sniper-laser-defense-mk2-equipment-k2']      ={r=000, g=146, b=255, a=127}, --Personal sniper laser defense MK2
    ['personal-sniper-laser-defense-mk3-equipment']         ={r=255, g=000, b=009, a=127}, --Personal sniper laser defense MK3
    ['personal-sniper-laser-defense-mk4-equipment']         ={r=240, g=000, b=255, a=127}, --Personal sniper laser defense MK4
    ['personal-submachine-laser-defense-mk1-equipment-k2']  ={r=000, g=255, b=042, a=127}, --Personal submachine laser defense
    ['personal-submachine-laser-defense-mk2-equipment-k2']  ={r=000, g=146, b=255, a=127}, --Personal submachine laser defense MK2
    ['personal-submachine-laser-defense-mk3-equipment-k2']  ={r=255, g=000, b=009, a=127}, --Personal submachine laser defense MK3
    ['personal-submachine-laser-defense-mk4-equipment-k2']  ={r=240, g=000, b=255, a=127}, --Personal submachine laser defense MK4
    ['piercing-rounds-magazine-k2']                         ={r=192, g=030, b=000, a=127}, --Piercing rounds magazine
    ['pistol-magazine']                                     ={r=199, g=147, b=000, a=127}, --Pistol magazine
    ['pollution-filter']                                    ={r=233, g=167, b=000, a=127}, --Pollution filter
    ['poop']                                                ={r=138, g=086, b=037, a=127}, --Mystery substance
    ['portable-generator-k2']                               ={r=080, g=104, b=113, a=127}, --Portable generator
    ['potato']                                              ={r=221, g=174, b=091, a=127}, --Potato
    ['power-armor-mk3-k2']                                  ={r=053, g=067, b=168, a=127}, --Power armor MK3
    ['power-armor-mk4-k2']                                  ={r=223, g=001, b=232, a=127}, --Power armor MK4
    ['production-science-pack-k2']                          ={r=149, g=034, b=118, a=127}, --Production science pack
    ['production-tech-card']                                ={r=149, g=034, b=118, a=127}, --Production tech card
    ['pumpjack-k2']                                         ={r=041, g=034, b=032, a=127}, --Pumpjack
    ['quartz-k2']                                           ={r=192, g=196, b=206, a=127}, --Quartz
    ['rare-metals']                                         ={r=095, g=101, b=133, a=127}, --Rare metals
    ['raw-imersite-k2']                                     ={r=222, g=000, b=255, a=127}, --Raw imersite
    ['raw-rare-metals']                                     ={r=092, g=162, b=198, a=127}, --Raw rare metals
    ['rifle-magazine']                                      ={r=182, g=138, b=000, a=127}, --Rifle magazine
    ['sand-k2']                                             ={r=240, g=211, b=168, a=127}, --Sand
    ['shield-generator-mk1-k2']                             ={r=000, g=226, b=005, a=127}, --Shield generator
    ['shield-generator-mk2-k2']                             ={r=041, g=158, b=250, a=127}, --Shield generator MK2
    ['shield-generator-mk3-k2']                             ={r=250, g=053, b=055, a=127}, --Shield generator MK3
    ['shield-generator-mk4-k2']                             ={r=167, g=070, b=238, a=127}, --Shield generator MK4
    ['silicon-k2']                                          ={r=121, g=137, b=175, a=127}, --Silicon
    ['singularity-tech-card']                               ={r=254, g=000, b=255, a=127}, --Singularity tech card
    ['small-portable-generator-k2']                         ={r=148, g=142, b=112, a=127}, --Small portable generator
    ['space-research-data']                                 ={r=184, g=146, b=137, a=127}, --Space research data
    ['space-science-pack-k2']                               ={r=091, g=082, b=077, a=127}, --Space science pack
    ['space-tech-card']                                     ={r=091, g=082, b=077, a=127}, --Space tech card
    ['spoiled-potato']                                      ={r=051, g=060, b=020, a=127}, --Spoiled potato
    ['steel-beam']                                          ={r=131, g=130, b=158, a=127}, --Steel beam
    ['steel-gear-wheel-k2']                                 ={r=153, g=155, b=180, a=127}, --Steel gear wheel
    ['steel-plate-k2']                                      ={r=127, g=128, b=143, a=127}, --Steel plate
    ['superior-exoskeleton-equipment']                      ={r=204, g=000, b=238, a=127}, --Superior exoskeleton
    ['teleportation-gps-module']                            ={r=041, g=158, b=250, a=127}, --Teleportation GPS module
    ['tritium']                                             ={r=019, g=255, b=000, a=127}, --Tritium
    ['uranium-anti-material-rifle-magazine']                ={r=017, g=158, b=000, a=127}, --Uranium anti-materiel rifle magazine
    ['uranium-rifle-magazine']                              ={r=000, g=158, b=045, a=127}, --Uranium rifle magazine
    ['used-improved-pollution-filter']                      ={r=097, g=059, b=052, a=127}, --Used improved pollution filter
    ['used-pollution-filter']                               ={r=197, g=138, b=000, a=127}, --Used pollution filter
    ['utility-science-pack-k2']                             ={r=210, g=143, b=003, a=127}, --Utility science pack
    ['utility-tech-card']                                   ={r=210, g=143, b=003, a=127}, --Utility tech card
    ['vehicle-roboport-k2']                                 ={r=114, g=101, b=074, a=127}, --Vehicle roboport

    ['ammonia-k2']                                          ={r=046, g=046, b=138, a=127}, --Ammonia
    ['biomethanol']                                         ={r=059, g=162, b=000, a=127}, --Biomethanol
    ['chlorine-k2']                                         ={r=073, g=184, b=000, a=127}, --Chlorine
    ['dirty-water-k2']                                      ={r=199, g=133, b=000, a=127}, --Dirty water
    ['heavy-water-k2']                                      ={r=085, g=255, b=128, a=127}, --Heavy water
    ['hydrogen-chloride-k2']                                ={r=115, g=230, b=023, a=127}, --Hydrogen chloride
    ['hydrogen-k2']                                         ={r=153, g=153, b=153, a=127}, --Hydrogen
    ['matter']                                              ={r=000, g=255, b=223, a=127}, --Matter
    ['mineral-water']                                       ={r=020, g=000, b=122, a=127}, --Mineral water
    ['nitric-acid-k2']                                      ={r=230, g=000, b=052, a=127}, --Nitric acid
    ['nitrogen-k2']                                         ={r=000, g=017, b=153, a=127}, --Nitrogen
    ['oxygen-k2']                                           ={r=245, g=153, b=153, a=127}, --Oxygen
}

Krastorio2_filters={
    "additional-engine",
    "advanced-additional-engine",
    "advanced-exoskeleton-equipment",
    "antimatter-artillery-shell",
    "antimatter-railgun-shell",
    "antimatter-rocket",
    "artillery-shell",
    "atomic-bomb",
    "automation-science-pack",
    "basic-railgun-shell",
    "battery-mk2-equipment",
    "battery-mk3-equipment",
    "big-battery-equipment",
    "big-battery-mk2-equipment",
    "big-battery-mk3-equipment",
    "big-imersite-solar-panel-equipment",
    "big-solar-panel-equipment",
    "chemical-science-pack",
    "coke",
    "dolphin-gun",
    "electronic-components",
    "energy-shield-equipment",
    "energy-shield-mk2-equipment",
    "energy-shield-mk3-equipment",
    "energy-shield-mk4-equipment",
    "enriched-copper",
    "enriched-iron",
    "explosion-railgun-shell",
    "firearm-magazine",
    "fusion-reactor-equipment",
    "glass",
    "heavy-rocket",
    "heavy-rocket-launcher",
    "imersite-night-vision-equipment",
    "imersite-powder",
    "imersite-rounds-magazine",
    "imersite-solar-panel-equipment",
    "impulse-rifle-ammo",
    "impulse-rifle",
    "iron-gear-wheel",
    "iron-plate",
    "lithium-chloride",
    "lithium",
    "logistic-science-pack",
    "matter-cube",
    "matter-research-data",
    "matter-stabilizer",
    "military-science-pack",
    "personal-laser-defense-equipment",
    "personal-laser-defense-mk2-equipment",
    "personal-sniper-laser-defense-mk1-equipment",
    "personal-sniper-laser-defense-mk2-equipment",
    "personal-submachine-laser-defense-mk1-equipment",
    "personal-submachine-laser-defense-mk2-equipment",
    "personal-submachine-laser-defense-mk3-equipment",
    "personal-submachine-laser-defense-mk4-equipment",
    "piercing-rounds-magazine",
    "portable-generator",
    "power-armor-mk3",
    "power-armor-mk4",
    "production-science-pack",
    "pumpjack",
    "quartz",
    "raw-imersite",
    "sand",
    "shield-generator-mk1",
    "shield-generator-mk2",
    "shield-generator-mk3",
    "shield-generator-mk4",
    "silicon",
    "small-portable-generator",
    "space-science-pack",
    "steel-gear-wheel",
    "steel-plate",
    "utility-science-pack",
    "vehicle-roboport",

    "ammonia",
    "chlorine",
    "dirty-water",
    "heavy-water",
    "hydrogen-chloride",
    "hydrogen",
    "nitric-acid",
    "nitrogen",
    "oxygen",
}