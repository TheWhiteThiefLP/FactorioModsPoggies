bztin={
    ['tin-ore-bzsn']                                        ={r=255, g=193, b=087, a=127}, --Tin ore
    ['tin-dust-bzsn']                                       ={r=235, g=235, b=203, a=127}, --Tin dust
    ['tin-plate-bzsn']                                      ={r=202, g=193, b=086, a=127}, --Tin plate
    ['tin-ingot-bzsn']                                      ={r=185, g=187, b=067, a=127}, --Tin ingot
    ['solder']                                              ={r=197, g=197, b=197, a=127}, --Solder
    ['tinned-cable-bzsn']                                   ={r=235, g=230, b=129, a=127}, --Tinned cable
    ['enriched-tin']                                        ={r=137, g=130, b=047, a=127}, --Enriched tin
    ['compressed-tin-ore']                                  ={r=254, g=240, b=204, a=127}, --Compressed tin ore
    ['bronze-plate-bzsn']                                   ={r=221, g=131, b=053, a=127}, --Bronze plate

    ['molten-tin-bzsn']                                     ={r=186, g=232, b=255, a=127}, --Molten tin
    ['organotins']                                          ={r=230, g=194, b=000, a=127}, --Organotins
}

bztin_filters={
    "tin-ore",
    "tin-dust",
    "tin-plate",
    "tin-ingot",
    "tinned-cable",
    "bronze-plate",

    "molten-tin",
}