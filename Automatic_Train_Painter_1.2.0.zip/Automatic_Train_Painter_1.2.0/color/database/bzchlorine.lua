bzchlorine={
    ['salt']                                                ={r=255, g=252, b=239, a=127}, --Salt
    ['ferric-chloride']                                     ={r=240, g=141, b=000, a=127}, --Ferric chloride
    ['pcb']                                                 ={r=234, g=041, b=079, a=127}, --PCB
    ['pcb-substrate']                                       ={r=241, g=117, b=205, a=127}, --__ITEM__pcb__ Substrate

    ['chlorine-bzcl']                                       ={r=102, g=255, b=064, a=127}, --Chlorine
    ['epoxy']                                               ={r=217, g=255, b=217, a=127}, --Epoxy
    ['hydrogen-chloride-bzcl']                              ={r=179, g=255, b=140, a=127}, --Hydrogen chloride
    ['vinyl-chloride']                                      ={r=217, g=255, b=159, a=127}, --Vinyl chloride
}

bzchlorine_filters={
    "chlorine",
    "hydrogen-chloride",
}