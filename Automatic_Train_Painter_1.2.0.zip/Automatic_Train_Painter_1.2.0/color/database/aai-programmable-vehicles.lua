aai_programmable_vehicles={
    ['cannon-shell-precision']                              ={r=196, g=160, b=111, a=127}, --Precision Cannon Shell
    ['car-vehicle-machine-gun']                             ={r=255, g=126, b=000, a=127}, --AI Car
    ['explosive-cannon-shell-precision']                    ={r=255, g=000, b=024, a=127}, --Precision Explosive Cannon Shell
    ['path-remote-control']                                 ={r=000, g=158, b=239, a=127}, --Path Remote Controller
    ['position-beacon']                                     ={r=255, g=206, b=104, a=127}, --Position Beacon
    ['tank-tank-cannon']                                    ={r=255, g=126, b=000, a=127}, --AI Tank
    ['unit-remote-control']                                 ={r=254, g=155, b=000, a=127}, --Unit Remote Controller
    ['vehicle-deployer']                                    ={r=083, g=065, b=050, a=127}, --Vehicle Deployer
    ['vehicle-depot']                                       ={r=203, g=131, b=000, a=127}, --Vehicle Depot
}