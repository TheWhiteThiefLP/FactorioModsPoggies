omnimatter={
    ['angels-roll-omnicium']                                ={r=113, g=000, b=162, a=127}, --Omniciuim Sheet Coil
    ['burner-omni-furnace']                                 ={r=255, g=000, b=227, a=127}, --Omnifurnace
    ['burner-omniphlog']                                    ={r=103, g=013, b=169, a=127}, --Burner Omniphlog
    ['burner-omnitractor']                                  ={r=107, g=073, b=101, a=127}, --Burner Omnitractor
    ['crushed-omnite']                                      ={r=108, g=000, b=120, a=127}, --Crushed Omnite
    ['infinite-omnite']                                     ={r=142, g=000, b=217, a=127}, --Infinite omnite
    ['ingot-omnicium']                                      ={r=098, g=000, b=140, a=127}, --Omnicium Ingot
    ['omnicium-aluminium-alloy']                            ={r=154, g=000, b=178, a=127}, --Omnilumina
    ['omnicium-brass-gear-box']                             ={r=154, g=000, b=178, a=127}, --Omnicium Brass gear box
    ['omnicium-gear-wheel']                                 ={r=129, g=000, b=139, a=127}, --Omnicium Gear wheel
    ['omnicium-iron-alloy']                                 ={r=154, g=000, b=178, a=127}, --Omniferrum
    ['omnicium-iron-gear-box']                              ={r=154, g=000, b=178, a=127}, --Omnicium Iron gear box
    ['omnicium-nitinol-gear-box']                           ={r=154, g=000, b=178, a=127}, --Omnicium Nitinol gear box
    ['omnicium-plate']                                      ={r=216, g=000, b=246, a=127}, --Omnicium Plate
    ['omnicium-steel-alloy']                                ={r=154, g=000, b=178, a=127}, --Omnichalybs
    ['omnicium-steel-gear-box']                             ={r=154, g=000, b=178, a=127}, --Omnicium Steel gear box
    ['omnicium-titanium-gear-box']                          ={r=154, g=000, b=178, a=127}, --Omnicium Titanium gear box
    ['omnicium-tungsten-alloy']                             ={r=154, g=000, b=178, a=127}, --Omnifram
    ['omnicium-tungsten-gear-box']                          ={r=154, g=000, b=178, a=127}, --Omnicium Tungsten gear box
    ['omniphlog-1']                                         ={r=103, g=013, b=169, a=127}, --Omniphlog Mk1
    ['omniphlog-2']                                         ={r=103, g=013, b=169, a=127}, --Omniphlog Mk2
    ['omniphlog-3']                                         ={r=103, g=013, b=169, a=127}, --Omniphlog Mk3
    ['omniphlog-4']                                         ={r=103, g=013, b=169, a=127}, --Omniphlog Mk4
    ['omniphlog-5']                                         ={r=103, g=013, b=169, a=127}, --Omniphlog Mk5
    ['omnite']                                              ={r=142, g=000, b=217, a=127}, --Omnite
    ['omnite-brick']                                        ={r=127, g=000, b=238, a=127}, --Omnite Brick
    ['omnitractor-1']                                       ={r=107, g=073, b=101, a=127}, --Electric Omnitractor Mk1
    ['omnitractor-2']                                       ={r=107, g=073, b=101, a=127}, --Electric Omnitractor Mk2
    ['omnitractor-3']                                       ={r=107, g=073, b=101, a=127}, --Electric Omnitractor Mk3
    ['omnitractor-4']                                       ={r=107, g=073, b=101, a=127}, --Electric Omnitractor Mk4
    ['omnitractor-5']                                       ={r=107, g=073, b=101, a=127}, --Electric Omnitractor Mk5
    ['pellet-omnicium']                                     ={r=098, g=000, b=145, a=127}, --Omnicium Pellet
    ['processed-omnicium']                                  ={r=104, g=000, b=150, a=127}, --Processed Omnicium
    ['pulverized-omnite']                                   ={r=153, g=000, b=155, a=127}, --Pulverized Omnite
    ['pulverized-stone']                                    ={r=160, g=160, b=160, a=127}, --Pulverized Stone
    ['steam-omniphlog']                                     ={r=103, g=013, b=169, a=127}, --Steam Omniphlog
    ['steam-omnitractor']                                   ={r=107, g=073, b=101, a=127}, --Steam Omnitractor
    ['stone-crushed']                                       ={r=178, g=178, b=178, a=127}, --Crushed Stone

    ['omnic-acid']                                          ={r=153, g=000, b=255, a=127}, --Omnic Acid
    ['omnic-waste']                                         ={r=000, g=000, b=255, a=127}, --Omnic Waste
    ['omnic-water']                                         ={r=255, g=000, b=252, a=127}, --Omnic Water
    ['omnisludge']                                          ={r=115, g=000, b=115, a=127}, --Omni Sludge
    ['omniston']                                            ={r=016, g=252, b=255, a=127}, --Omniston
}