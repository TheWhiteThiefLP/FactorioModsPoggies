aai_vehicles_flame_tank={
    ['flamejet-ammo-aaivft']                                ={r=197, g=096, b=049, a=127}, --Flamejet Ammo
    ['flame-tank-flamethrower']                             ={r=255, g=134, b=000, a=127}, --Flamethrower
    ['vehicle-flame-tank']                                  ={r=255, g=134, b=000, a=127}, --Flame Tank
    ['vehicle-flame-tank-flame-tank-flamethrower']          ={r=255, g=134, b=000, a=127}, --AI Flame Tank
}

aai_vehicles_flame_tank_filters={
    "flamejet-ammo",
}
