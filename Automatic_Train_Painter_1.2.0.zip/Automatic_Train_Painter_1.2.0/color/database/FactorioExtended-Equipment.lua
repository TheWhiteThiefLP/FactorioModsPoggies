FactorioExtended_Equipment={
    ['battery-equipment-1']                                 ={r=242, g=047, b=000, a=127}, --Battery Equipment Mk1
    ['battery-equipment-2']                                 ={r=002, g=242, b=000, a=127}, --Battery Equipment Mk2
    ['battery-equipment-3']                                 ={r=119, g=000, b=255, a=127}, --Battery Equipment Mk3
    ['energy-shield-equipment-1']                           ={r=255, g=104, b=000, a=127}, --Energy Shield Equipment Mk1
    ['energy-shield-equipment-2']                           ={r=000, g=255, b=034, a=127}, --Energy Shield Equipment Mk2
    ['energy-shield-equipment-3']                           ={r=042, g=000, b=255, a=127}, --Energy Shield Equipment Mk3
    ['exoskeleton-equipment-1']                             ={r=142, g=032, b=048, a=127}, --Exoskeleton Equipment Mk1
    ['exoskeleton-equipment-2']                             ={r=032, g=142, b=057, a=127}, --Exoskeleton Equipment Mk2
    ['exoskeleton-equipment-3']                             ={r=120, g=030, b=142, a=127}, --Exoskeleton Equipment Mk3
    ['fusion-reactor-equipment-1']                          ={r=085, g=017, b=013, a=127}, --Fusion Reactor Equipment Mk1
    ['fusion-reactor-equipment-2']                          ={r=025, g=086, b=011, a=127}, --Fusion Reactor Equipment Mk2
    ['fusion-reactor-equipment-3']                          ={r=099, g=002, b=158, a=127}, --Fusion Reactor Equipment Mk3
    ['personal-laser-defense-equipment-1']                  ={r=241, g=065, b=049, a=127}, --Personal Laser Defense Equipment Mk1
    ['personal-laser-defense-equipment-2']                  ={r=049, g=241, b=056, a=127}, --Personal Laser Defense Equipment Mk2
    ['personal-laser-defense-equipment-3']                  ={r=113, g=032, b=246, a=127}, --Personal Laser Defense Equipment Mk3
    ['personal-roboport-equipment-1']                       ={r=157, g=011, b=000, a=127}, --Personal Roboport Equipment Mk1
    ['personal-roboport-equipment-2']                       ={r=000, g=157, b=030, a=127}, --Personal Roboport Equipment Mk2
    ['personal-roboport-equipment-3']                       ={r=051, g=000, b=157, a=127}, --Personal Roboport Equipment Mk3
    ['power-armor-1']                                       ={r=233, g=000, b=003, a=127}, --Stainless Steel Power Armor
    ['power-armor-2']                                       ={r=000, g=232, b=066, a=127}, --Titanium Power Armor
    ['power-armor-3']                                       ={r=181, g=000, b=234, a=127}, --Graphene Power Armor
    ['solar-panel-equipment-1']                             ={r=223, g=045, b=052, a=127}, --Solar Panel Equipment Mk1
    ['solar-panel-equipment-2']                             ={r=047, g=233, b=087, a=127}, --Solar Panel Equipment Mk2
    ['solar-panel-equipment-3']                             ={r=143, g=080, b=204, a=127}, --Solar Panel Equipment Mk3
}