bobores={
    ['amethyst-ore-bobo']                                   ={r=203, g=133, b=194, a=127}, --Amethyst Ore
    ['bauxite-ore-bobo']                                    ={r=206, g=163, b=005, a=127}, --Bauxite (Aluminium ore)
    ['cobalt-ore-bobo']                                     ={r=004, g=096, b=197, a=127}, --Cobaltite
    ['diamond-ore-bobo']                                    ={r=169, g=173, b=139, a=127}, --Diamond Ore
    ['emerald-ore-bobo']                                    ={r=131, g=169, b=149, a=127}, --Emerald Ore
    ['gem-ore-bobo']                                        ={r=000, g=246, b=061, a=127}, --Gemstones
    ['gold-ore-bobo']                                       ={r=255, g=198, b=006, a=127}, --Gold ore
    ['lead-ore-bobo']                                       ={r=028, g=028, b=028, a=127}, --Galena (Lead ore)
    ['nickel-ore-bobo']                                     ={r=082, g=152, b=134, a=127}, --Nickel ore
    ['quartz-bobo']                                         ={r=252, g=252, b=252, a=127}, --Quartz (Silicon ore)
    ['ruby-ore-bobo']                                       ={r=156, g=000, b=056, a=127}, --Ruby Ore
    ['rutile-ore-bobo']                                     ={r=108, g=072, b=101, a=127}, --Rutile (Titanium ore)
    ['sapphire-ore-bobo']                                   ={r=042, g=065, b=179, a=127}, --Sapphire Ore
    ['silver-ore-bobo']                                     ={r=136, g=182, b=186, a=127}, --Silver ore
    ['thorium-ore-bobo']                                    ={r=255, g=255, b=000, a=127}, --Thorium ore
    ['tin-ore-bobo']                                        ={r=130, g=130, b=130, a=127}, --Tin ore
    ['topaz-ore-bobo']                                      ={r=160, g=100, b=075, a=127}, --Topaz Ore
    ['tungsten-ore-bobo']                                   ={r=167, g=079, b=003, a=127}, --Tungsten ore
    ['zinc-ore-bobo']                                       ={r=038, g=172, b=163, a=127}, --Zinc ore

    ['lithia-water']                                        ={r=000, g=104, b=184, a=127}, --Lithia Water
}

bobores_filters={
    "amethyst-ore",
    "bauxite-ore",
    "cobalt-ore",
    "diamond-ore",
    "emerald-ore",
    "gem-ore",
    "gold-ore",
    "lead-ore",
    "nickel-ore",
    "quartz",
    "ruby-ore",
    "rutile-ore",
    "sapphire-ore",
    "silver-ore",
    "thorium-ore",
    "tin-ore",
    "topaz-ore",
    "tungsten-ore",
    "zinc-ore",
}