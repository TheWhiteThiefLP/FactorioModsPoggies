bobwarfare={
    ['acid-bullet']                                         ={r=141, g=059, b=255, a=127}, --Acid bullet
    ['acid-bullet-magazine']                                ={r=170, g=000, b=255, a=127}, --Acid ammo magazine
    ['acid-bullet-projectile']                              ={r=169, g=077, b=255, a=127}, --Acid bullet projectile
    ['acid-rocket-warhead']                                 ={r=212, g=110, b=255, a=127}, --Acid rocket warhead
    ['ap-bullet']                                           ={r=088, g=153, b=255, a=127}, --AP bullet
    ['ap-bullet-magazine']                                  ={r=000, g=184, b=255, a=127}, --AP ammo magazine
    ['ap-bullet-projectile']                                ={r=060, g=144, b=255, a=127}, --AP bullet projectile
    ['better-shotgun-shell']                                ={r=197, g=197, b=195, a=127}, --Better shotgun shells
    ['bob-acid-rocket']                                     ={r=182, g=000, b=255, a=127}, --Acid rocket
    ['bob-artillery-turret-2']                              ={r=255, g=212, b=000, a=127}, --__ITEM__artillery-turret__ MK2
    ['bob-artillery-turret-3']                              ={r=255, g=212, b=000, a=127}, --__ITEM__artillery-turret__ MK3
    ['bob-artillery-wagon-2']                               ={r=255, g=218, b=000, a=127}, --__ITEM__artillery-wagon__ MK2
    ['bob-artillery-wagon-3']                               ={r=255, g=218, b=000, a=127}, --__ITEM__artillery-wagon__ MK3
    ['bob-electric-rocket']                                 ={r=255, g=125, b=000, a=127}, --Electric rocket
    ['bob-explosive-rocket']                                ={r=255, g=254, b=000, a=127}, --Explosive rocket
    ['bob-flame-rocket']                                    ={r=255, g=000, b=000, a=127}, --Flame rocket
    ['bob-gun-turret-2']                                    ={r=122, g=094, b=067, a=127}, --Gun turret MK2
    ['bob-gun-turret-3']                                    ={r=122, g=094, b=067, a=127}, --Gun turret MK3
    ['bob-gun-turret-4']                                    ={r=122, g=094, b=067, a=127}, --Gun turret MK4
    ['bob-gun-turret-5']                                    ={r=122, g=094, b=067, a=127}, --Gun turret MK5
    ['bob-laser-robot']                                     ={r=193, g=031, b=182, a=127}, --Laser robot
    ['bob-laser-robot-capsule']                             ={r=000, g=142, b=255, a=127}, --Laser robot capsule
    ['bob-laser-turret-2']                                  ={r=085, g=166, b=194, a=127}, --Laser turret MK2
    ['bob-laser-turret-3']                                  ={r=085, g=166, b=194, a=127}, --Laser turret MK3
    ['bob-laser-turret-4']                                  ={r=085, g=166, b=194, a=127}, --Laser turret MK4
    ['bob-laser-turret-5']                                  ={r=085, g=166, b=194, a=127}, --Laser turret MK5
    ['bob-piercing-rocket']                                 ={r=000, g=182, b=255, a=127}, --Piercing rocket
    ['bob-plasma-rocket']                                   ={r=000, g=212, b=255, a=127}, --Plasma rocket
    ['bob-plasma-turret-1']                                 ={r=085, g=166, b=194, a=127}, --Plasma turret MK1
    ['bob-plasma-turret-2']                                 ={r=085, g=166, b=194, a=127}, --Plasma turret MK2
    ['bob-plasma-turret-3']                                 ={r=085, g=166, b=194, a=127}, --Plasma turret MK3
    ['bob-plasma-turret-4']                                 ={r=085, g=166, b=194, a=127}, --Plasma turret MK4
    ['bob-plasma-turret-5']                                 ={r=085, g=166, b=194, a=127}, --Plasma turret MK5
    ['bob-poison-rocket']                                   ={r=000, g=255, b=000, a=127}, --Poison rocket
    ['bob-power-armor-mk3']                                 ={r=034, g=030, b=028, a=127}, --Power armor MK3
    ['bob-power-armor-mk4']                                 ={r=074, g=076, b=074, a=127}, --Power armor MK4
    ['bob-power-armor-mk5']                                 ={r=188, g=006, b=000, a=127}, --Power armor MK5
    ['bob-robot-flamethrower-drone']                        ={r=218, g=018, b=000, a=127}, --Robotic flamethrower attack drone
    ['bob-robot-gun-drone']                                 ={r=218, g=018, b=000, a=127}, --Robotic attack drone
    ['bob-robot-laser-drone']                               ={r=218, g=018, b=000, a=127}, --Robotic laser attack drone
    ['bob-robot-plasma-drone']                              ={r=218, g=018, b=000, a=127}, --Robotic plasma attack drone
    ['bob-rocket']                                          ={r=082, g=082, b=082, a=127}, --Rocket
    ['bob-sniper-turret-1']                                 ={r=122, g=094, b=067, a=127}, --Sniper turret MK1
    ['bob-sniper-turret-2']                                 ={r=122, g=094, b=067, a=127}, --Sniper turret MK2
    ['bob-sniper-turret-3']                                 ={r=122, g=094, b=067, a=127}, --Sniper turret MK3
    ['bob-tank-2']                                          ={r=138, g=000, b=197, a=127}, --Tank MK2
    ['bob-tank-3']                                          ={r=004, g=152, b=000, a=127}, --Tank MK3
    ['bullet']                                              ={r=188, g=133, b=037, a=127}, --Bullet
    ['bullet-casing']                                       ={r=221, g=187, b=053, a=127}, --Bullet casing
    ['bullet-magazine']                                     ={r=101, g=088, b=077, a=127}, --Ammo magazine
    ['bullet-projectile']                                   ={r=126, g=045, b=013, a=127}, --Bullet projectile
    ['cordite']                                             ={r=210, g=104, b=000, a=127}, --Cordite
    ['defender-capsule-bobw']                               ={r=053, g=255, b=118, a=127}, --Defender capsule
    ['defender-robot']                                      ={r=137, g=231, b=233, a=127}, --Defender robot
    ['destroyer-capsule-bobw']                              ={r=255, g=082, b=054, a=127}, --Destroyer capsule
    ['destroyer-robot']                                     ={r=253, g=000, b=002, a=127}, --Destroyer robot
    ['distractor-artillery-shell']                          ={r=136, g=206, b=000, a=127}, --Distractor artillery shells
    ['distractor-capsule-bobw']                             ={r=181, g=045, b=255, a=127}, --Distractor capsule
    ['distractor-mine']                                     ={r=107, g=074, b=037, a=127}, --Distractor robot mine
    ['distractor-robot']                                    ={r=136, g=206, b=000, a=127}, --Distractor robot
    ['electric-bullet']                                     ={r=255, g=177, b=087, a=127}, --Electric bullet
    ['electric-bullet-magazine']                            ={r=255, g=145, b=000, a=127}, --Electric ammo magazine
    ['electric-bullet-projectile']                          ={r=255, g=159, b=060, a=127}, --Electric bullet projectile
    ['electric-rocket-warhead']                             ={r=255, g=178, b=110, a=127}, --Electric rocket warhead
    ['explosive-artillery-shell']                           ={r=065, g=082, b=060, a=127}, --Explosive artillery shells
    ['explosive-rocket-warhead']                            ={r=255, g=255, b=110, a=127}, --Explosive rocket warhead
    ['fire-artillery-shell']                                ={r=173, g=058, b=000, a=127}, --Napalm artillery shells
    ['fire-capsule']                                        ={r=173, g=058, b=000, a=127}, --Napalm capsule
    ['flame-bullet']                                        ={r=255, g=095, b=095, a=127}, --Flame bullet
    ['flame-bullet-magazine']                               ={r=255, g=028, b=000, a=127}, --Flame ammo magazine
    ['flame-bullet-projectile']                             ={r=255, g=080, b=082, a=127}, --Flame bullet projectile
    ['flame-rocket-warhead']                                ={r=255, g=110, b=110, a=127}, --Flame rocket warhead
    ['gatling-gun']                                         ={r=115, g=130, b=126, a=127}, --Gatling gun
    ['gun-cotton']                                          ={r=240, g=251, b=249, a=127}, --Guncotton
    ['heavy-armor-2']                                       ={r=107, g=109, b=107, a=127}, --Invar Cobalt-steel armor
    ['heavy-armor-3']                                       ={r=067, g=062, b=065, a=127}, --Titanium-Ceramic armor
    ['he-bullet']                                           ={r=242, g=255, b=087, a=127}, --HE bullet
    ['he-bullet-magazine']                                  ={r=253, g=255, b=000, a=127}, --HE ammo magazine
    ['he-bullet-projectile']                                ={r=243, g=255, b=065, a=127}, --HE bullet projectile
    ['laser-rifle']                                         ={r=190, g=051, b=035, a=127}, --Laser rifle
    ['laser-rifle-battery']                                 ={r=255, g=187, b=000, a=127}, --Laser rifle battery
    ['laser-rifle-battery-amethyst']                        ={r=141, g=000, b=197, a=127}, --Amethyst laser rifle battery
    ['laser-rifle-battery-case']                            ={r=255, g=187, b=000, a=127}, --Laser rifle battery case
    ['laser-rifle-battery-diamond']                         ={r=173, g=180, b=191, a=127}, --Diamond laser rifle battery
    ['laser-rifle-battery-emerald']                         ={r=037, g=143, b=083, a=127}, --Emerald laser rifle battery
    ['laser-rifle-battery-ruby']                            ={r=255, g=000, b=048, a=127}, --Ruby laser rifle battery
    ['laser-rifle-battery-sapphire']                        ={r=005, g=085, b=202, a=127}, --Sapphire laser rifle battery
    ['laser-rifle-battery-topaz']                           ={r=216, g=108, b=000, a=127}, --Topaz laser rifle battery
    ['magazine']                                            ={r=101, g=088, b=077, a=127}, --Magazine
    ['petroleum-jelly']                                     ={r=199, g=206, b=178, a=127}, --Petroleum jelly
    ['piercing-rocket-warhead']                             ={r=110, g=178, b=255, a=127}, --Piercing rocket warhead
    ['plasma-bullet']                                       ={r=079, g=210, b=246, a=127}, --Plasma bullet
    ['plasma-bullet-magazine']                              ={r=000, g=230, b=236, a=127}, --Plasma ammo magazine
    ['plasma-bullet-projectile']                            ={r=054, g=209, b=252, a=127}, --Plasma bullet projectile
    ['plasma-rocket-warhead']                               ={r=035, g=202, b=255, a=127}, --Plasma rocket warhead
    ['poison-artillery-shell']                              ={r=003, g=232, b=255, a=127}, --Poison artillery shells
    ['poison-bullet']                                       ={r=129, g=255, b=087, a=127}, --Poison bullet
    ['poison-bullet-magazine']                              ={r=000, g=255, b=017, a=127}, --Poison ammo magazine
    ['poison-bullet-projectile']                            ={r=112, g=255, b=065, a=127}, --Poison bullet projectile
    ['poison-mine']                                         ={r=107, g=074, b=037, a=127}, --Poison mine
    ['poison-rocket-warhead']                               ={r=110, g=255, b=110, a=127}, --Poison rocket warhead
    ['radar-2-bobw']                                        ={r=168, g=119, b=058, a=127}, --Radar 2
    ['radar-3-bobw']                                        ={r=168, g=119, b=058, a=127}, --Radar 3
    ['radar-4']                                             ={r=168, g=119, b=058, a=127}, --Radar 4
    ['radar-5']                                             ={r=168, g=119, b=058, a=127}, --Radar 5
    ['reinforced-gate']                                     ={r=109, g=077, b=048, a=127}, --Re-inforced concrete gate
    ['reinforced-wall']                                     ={r=130, g=088, b=130, a=127}, --Re-inforced concrete wall
    ['rifle']                                               ={r=076, g=082, b=082, a=127}, --Rifle
    ['robot-brain-combat']                                  ={r=255, g=000, b=092, a=127}, --Combat robot brain
    ['robot-brain-combat-2']                                ={r=255, g=000, b=092, a=127}, --Combat robot brain 2
    ['robot-brain-combat-3']                                ={r=255, g=000, b=092, a=127}, --Combat robot brain 3
    ['robot-brain-combat-4']                                ={r=255, g=000, b=092, a=127}, --Combat robot brain 4
    ['robot-drone-frame']                                   ={r=098, g=061, b=052, a=127}, --Robotic attack drone frame
    ['robot-drone-frame-large']                             ={r=098, g=061, b=052, a=127}, --Large robotic attack drone frame
    ['robot-tool-combat']                                   ={r=251, g=000, b=045, a=127}, --Defender robot weapon
    ['robot-tool-combat-2']                                 ={r=251, g=000, b=045, a=127}, --Distractor robot weapon
    ['robot-tool-combat-3']                                 ={r=251, g=000, b=045, a=127}, --Destroyer robot weapon
    ['robot-tool-combat-4']                                 ={r=251, g=000, b=045, a=127}, --Laser robot weapon
    ['rocket-body']                                         ={r=245, g=238, b=218, a=127}, --Rocket body
    ['rocket-engine']                                       ={r=122, g=000, b=001, a=127}, --Rocket engine
    ['rocket-warhead']                                      ={r=176, g=178, b=172, a=127}, --Rocket warhead
    ['scatter-cannon-shell']                                ={r=196, g=160, b=111, a=127}, --Scatter cannon shells
    ['shot']                                                ={r=188, g=188, b=188, a=127}, --Shotgun pellets
    ['shotgun-acid-shell']                                  ={r=117, g=000, b=255, a=127}, --Shotgun acid shells
    ['shotgun-ap-shell']                                    ={r=000, g=131, b=255, a=127}, --Shotgun AP shells
    ['shotgun-electric-shell']                              ={r=255, g=128, b=000, a=127}, --Shotgun electric shells
    ['shotgun-explosive-shell']                             ={r=255, g=222, b=000, a=127}, --Shotgun explosive shells
    ['shotgun-flame-shell']                                 ={r=255, g=004, b=023, a=127}, --Shotgun flame shells
    ['shotgun-plasma-shell']                                ={r=000, g=232, b=235, a=127}, --Shotgun plasma shells
    ['shotgun-poison-shell']                                ={r=028, g=255, b=000, a=127}, --Shotgun poison shells
    ['shotgun-shell-casing']                                ={r=186, g=159, b=031, a=127}, --Shotgun shell casing
    ['shotgun-uranium-shell']                               ={r=030, g=204, b=000, a=127}, --Shotgun uranium shells
    ['slowdown-mine']                                       ={r=107, g=074, b=037, a=127}, --Slowdown mine
    ['sniper-rifle']                                        ={r=047, g=054, b=047, a=127}, --Sniper rifle
    ['tank-laser']                                          ={r=124, g=107, b=100, a=127}, --Tank laser
    ['uranium-bullet']                                      ={r=043, g=245, b=045, a=127}, --Uranium bullet
    ['uranium-bullet-projectile']                           ={r=065, g=251, b=078, a=127}, --Uranium bullet projectile

    ['glycerol']                                            ={r=255, g=255, b=064, a=127}, --Glycerol
    ['nitroglycerin']                                       ={r=000, g=000, b=255, a=127}, --Nitroglycerin
    ['sulfuric-nitric-acid']                                ={r=000, g=000, b=255, a=127}, --Sulfuric and Nitric acid mixture
}

bobwarfare_filters={
    "defender-capsule",
    "destroyer-capsule",
    "distractor-capsule",
    "radar-2",
    "radar-3",
}