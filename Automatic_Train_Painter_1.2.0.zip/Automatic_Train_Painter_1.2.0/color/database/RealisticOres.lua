RealisticOres={
    ['copper-ore-realistic']                                ={r=044, g=161, b=114, a=127}, --Copper ore
    ['iron-ore-realistic']                                  ={r=216, g=043, b=000, a=127}, --Iron ore
    ['uranium-ore-realistic']                               ={r=157, g=168, b=001, a=127}, --Uranium ore
}

RealisticOres_filters={
    "copper-ore",
    "iron-ore",
    "uranium-ore",
    "se-core-fragment-copper-ore",
    "se-core-fragment-iron-ore",
    "se-core-fragment-uranium-ore",
}