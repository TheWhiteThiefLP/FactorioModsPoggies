_5dim_storage={
    ['5d-storage-tank-02']                                  ={r=250, g=025, b=000, a=127}, --Storage tank MK2
    ['5d-storage-tank-03']                                  ={r=000, g=198, b=255, a=127}, --Storage tank MK3
    ['5d-storage-tank-04']                                  ={r=248, g=074, b=234, a=127}, --Storage tank MK4
    ['5d-storage-tank-05']                                  ={r=022, g=255, b=009, a=127}, --Storage tank MK5
    ['5d-storage-tank-06']                                  ={r=178, g=107, b=055, a=127}, --Storage tank MK6
    ['5d-storage-tank-07']                                  ={r=124, g=023, b=191, a=127}, --Storage tank MK7
    ['5d-storage-tank-08']                                  ={r=252, g=252, b=248, a=127}, --Storage tank MK8
    ['5d-storage-tank-09']                                  ={r=255, g=121, b=000, a=127}, --Storage tank MK9
    ['5d-storage-tank-10']                                  ={r=025, g=029, b=252, a=127}, --Storage tank MK10
    ['5d-storage-tank-multi-01']                            ={r=255, g=207, b=000, a=127}, --Storage tank multi conection
    ['5d-storage-tank-multi-02']                            ={r=250, g=025, b=000, a=127}, --Storage tank multi conection MK2
    ['5d-storage-tank-multi-03']                            ={r=000, g=198, b=255, a=127}, --Storage tank multi conection MK3
    ['5d-storage-tank-multi-04']                            ={r=248, g=074, b=234, a=127}, --Storage tank multi conection MK4
    ['5d-storage-tank-multi-05']                            ={r=022, g=255, b=009, a=127}, --Storage tank multi conection MK5
    ['5d-storage-tank-multi-06']                            ={r=178, g=107, b=055, a=127}, --Storage tank multi conection MK6
    ['5d-storage-tank-multi-07']                            ={r=124, g=023, b=191, a=127}, --Storage tank multi conection MK7
    ['5d-storage-tank-multi-08']                            ={r=252, g=252, b=248, a=127}, --Storage tank multi conection MK8
    ['5d-storage-tank-multi-09']                            ={r=255, g=121, b=000, a=127}, --Storage tank multi conection MK9
    ['5d-storage-tank-multi-10']                            ={r=025, g=029, b=252, a=127}, --Storage tank multi conection MK10
    ['storage-tank-5ds']                                    ={r=255, g=207, b=000, a=127}, --Storage tank
}

_5dim_storage_filters={
    "storage-tank",
}