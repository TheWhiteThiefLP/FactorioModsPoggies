omnimatter_wood={
    ['omnialgae']                                           ={r=126, g=000, b=148, a=127}, --Omni Algae
    ['omnimutator']                                         ={r=154, g=010, b=168, a=127}, --Omnimutator
    ['omniseedling']                                        ={r=208, g=000, b=176, a=127}, --Omnifused Seedling
    ['omniwood']                                            ={r=154, g=046, b=240, a=127}, --Omnifused Wood
}