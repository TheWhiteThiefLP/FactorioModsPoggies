CompressedFluids={
    ['fluid-compressor']                                    ={r=158, g=014, b=000, a=127}, --Compressor
    ['fluid-decompressor']                                  ={r=158, g=014, b=000, a=127}, --Expander
}