bzgas={
    ['gas-boiler']                                          ={r=181, g=000, b=008, a=127}, --Gas-fired boiler
    ['basic-chemical-plant']                                ={r=102, g=077, b=043, a=127}, --Basic chemical plant
    ['gas-extractor']                                       ={r=116, g=086, b=053, a=127}, --Drilling rig
    ['bakelite-bzg']                                        ={r=121, g=137, b=068, a=127}, --Bakelite
    ['phenol-bzg']                                          ={r=229, g=220, b=186, a=127}, --Phenol

    ['gas']                                                 ={r=167, g=255, b=255, a=127}, --Natural gas
    ['formaldehyde-bzg']                                    ={r=211, g=255, b=211, a=127}, --Formaldehyde
}

bzgas_filters={
    "bakelite",
    "phenol",

    "formaldehyde",
}