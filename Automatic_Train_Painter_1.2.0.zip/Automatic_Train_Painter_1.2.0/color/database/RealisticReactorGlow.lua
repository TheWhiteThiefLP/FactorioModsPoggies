RealisticReactorGlow={
    ['nuclear-reactor-realistic']                           ={r=000, g=129, b=255, a=127}, --Nuclear reactor
}

RealisticReactorGlow_filters={
    "nuclear-reactor",
}