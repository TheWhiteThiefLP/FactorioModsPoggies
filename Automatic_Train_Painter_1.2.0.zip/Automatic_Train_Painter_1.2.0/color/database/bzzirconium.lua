bzzirconium={
    ['cermet-bzz']                                          ={r=175, g=150, b=166, a=127}, --Cermet
    ['compressed-zircon']                                   ={r=211, g=148, b=092, a=127}, --Compressed zircon
    ['enriched-zircon']                                     ={r=149, g=080, b=102, a=127}, --Enriched zircon
    ['zircon']                                              ={r=211, g=148, b=092, a=127}, --Zircon
    ['zirconia']                                            ={r=226, g=204, b=226, a=127}, --Zirconia
    ['zirconium-dust']                                      ={r=216, g=216, b=202, a=127}, --Zircon dust
    ['zirconium-plate']                                     ={r=255, g=220, b=248, a=127}, --Zirconium plate
}

bzzirconium_filters={
    "cermet",
}