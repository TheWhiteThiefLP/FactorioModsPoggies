jetpack={
    ['jetpack-1']                                           ={r=255, g=162, b=000, a=127}, --Jetpack Equipment MK1
    ['jetpack-2']                                           ={r=255, g=011, b=000, a=127}, --Jetpack Equipment MK2
    ['jetpack-3']                                           ={r=000, g=120, b=248, a=127}, --Jetpack Equipment MK3
    ['jetpack-4']                                           ={r=028, g=025, b=034, a=127}, --Jetpack Equipment MK4
}