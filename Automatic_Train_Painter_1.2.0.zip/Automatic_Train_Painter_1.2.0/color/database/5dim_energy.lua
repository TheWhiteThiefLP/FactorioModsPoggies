_5dim_energy={
    ['5d-basic-accumulator-2']                              ={r=153, g=155, b=139, a=127}, --Accumulator MK2
    ['5d-basic-accumulator-3']                              ={r=140, g=076, b=056, a=127}, --Accumulator MK3
    ['5d-boiler']                                           ={r=106, g=062, b=050, a=127}, --Boiler MK2
    ['5d-boiler-2']                                         ={r=076, g=058, b=043, a=127}, --Boiler MK3
    ['5d-electric-pole-4']                                  ={r=135, g=133, b=140, a=127}, --Medium electric pole MK2
    ['5d-electric-pole-5']                                  ={r=122, g=115, b=094, a=127}, --Big electric pole MK2
    ['5d-electric-pole-6']                                  ={r=054, g=052, b=045, a=127}, --Wifi electric pole
    ['5d-lamp']                                             ={r=126, g=126, b=220, a=127}, --Big Lamp
    ['5d-offshore-pump']                                    ={r=142, g=084, b=084, a=127}, --Offshore pump MK2
    ['5d-offshore-pump-2']                                  ={r=058, g=058, b=058, a=127}, --Offshore pump MK3
    ['5d-small-pump']                                       ={r=000, g=045, b=178, a=127}, --Small pump MK2
    ['5d-small-pump-2']                                     ={r=038, g=133, b=092, a=127}, --Small pump MK3
    ['5d-solar-panel-2']                                    ={r=022, g=040, b=119, a=127}, --Solar panel MK2
    ['5d-solar-panel-3']                                    ={r=040, g=055, b=085, a=127}, --Solar panel MK3
    ['5d-steam-engine-2']                                   ={r=121, g=094, b=056, a=127}, --Steam engine MK2
    ['5d-steam-engine-3']                                   ={r=086, g=070, b=049, a=127}, --Steam engine MK3
}