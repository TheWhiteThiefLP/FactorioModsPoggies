bobgreenhouse={
    ['bob-greenhouse']                                      ={r=023, g=131, b=124, a=127}, --Greenhouse
    ['fertiliser-bobg']                                     ={r=113, g=164, b=187, a=127}, --Fertiliser
    ['seedling-bobg']                                       ={r=109, g=174, b=019, a=127}, --Seedling
    ['wood-pellets-bobg']                                   ={r=250, g=185, b=115, a=127}, --Wood fuel pellets
}

bobgreenhouse_filters={
    "fertiliser",
    "seedling",
    "wood-pellets",
}