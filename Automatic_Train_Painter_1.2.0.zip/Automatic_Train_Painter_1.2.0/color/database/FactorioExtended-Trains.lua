FactorioExtended_Trains={
    ['cargo-wagon-1']                                       ={r=121, g=060, b=073, a=127}, --Cargo Wagon Mk1
    ['cargo-wagon-2']                                       ={r=078, g=121, b=062, a=127}, --Cargo Wagon Mk2
    ['cargo-wagon-3']                                       ={r=080, g=062, b=121, a=127}, --Cargo Wagon Mk3
    ['fluid-wagon-1']                                       ={r=188, g=068, b=030, a=127}, --Fluid Wagon Mk1
    ['fluid-wagon-2']                                       ={r=029, g=180, b=065, a=127}, --Fluid Wagon Mk2
    ['fluid-wagon-3']                                       ={r=167, g=072, b=184, a=127}, --Fluid Wagon Mk3
    ['locomotive-1']                                        ={r=211, g=080, b=006, a=127}, --Locomotive Mk1
    ['locomotive-2']                                        ={r=015, g=118, b=033, a=127}, --Locomotive Mk2
    ['locomotive-3']                                        ={r=122, g=012, b=203, a=127}, --Locomotive Mk3
}