omnimatter_science={
    ['omni-pack']                                           ={r=210, g=000, b=238, a=127}, --Omni science pack
    ['omni-tech-card']                                      ={r=181, g=000, b=255, a=127}, --Omni tech card
    ['production-science-pack-oms']                         ={r=244, g=129, b=000, a=127}, --Production science pack
}

omnimatter_science_filters={
    "production-science-pack",
}