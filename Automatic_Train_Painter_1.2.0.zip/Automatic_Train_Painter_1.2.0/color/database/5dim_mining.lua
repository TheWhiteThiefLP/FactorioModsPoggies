_5dim_mining={
    ['5d-mining-drill-speed-1']                         ={r=105, g=047, b=161, a=127}, --Mining Drill - Speed MK1
    ['5d-mining-drill-speed-2']                         ={r=158, g=045, b=103, a=127}, --Mining Drill - Speed MK2
    ['5d-mining-drill-speed-3']                         ={r=140, g=083, b=083, a=127}, --Mining Drill - Speed MK3
    ['5d-mining-drill-range-1']                         ={r=083, g=140, b=083, a=127}, --Mining Drill - Range MK1
    ['5d-mining-drill-range-2']                         ={r=083, g=083, b=140, a=127}, --Mining Drill - Range MK2
    ['5d-mining-drill-range-3']                         ={r=138, g=080, b=138, a=127}, --Mining Drill - Range MK3
    ['5d-pumpjack-2']                                   ={r=067, g=133, b=068, a=127}, --Pumpjack MK2
    ['5d-pumpjack-3']                                   ={r=077, g=149, b=073, a=127}, --Pumpjack MK3
    ['5d-water-pumpjack']                               ={r=018, g=176, b=198, a=127}, --Water pumpjack
}