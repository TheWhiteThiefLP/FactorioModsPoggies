aai_programmable_structures={
    ['path-control']                                        ={r=020, g=112, b=223, a=127}, --Path Controller
    ['path-scan']                                           ={r=020, g=112, b=223, a=127}, --Path Scanner
    ['tile-scan']                                           ={r=110, g=180, b=041, a=127}, --Tile Scanner
    ['unit-control']                                        ={r=255, g=164, b=000, a=127}, --Unit Controller
    ['unitdata-control']                                    ={r=227, g=010, b=000, a=127}, --Unit Data Controller
    ['unitdata-scan']                                       ={r=227, g=010, b=000, a=127}, --Unit Data Scanner
    ['unit-scan']                                           ={r=255, g=164, b=000, a=127}, --Player Scanner
    ['zone-control']                                        ={r=136, g=055, b=217, a=127}, --Zone Controller
    ['zone-scan']                                           ={r=136, g=055, b=217, a=127}, --Zone Scanner
}