_5dim_vehicle={
    ['5d-air-plane']                                        ={r=097, g=124, b=062, a=127}, --Air plane
    ['5d-boat']                                             ={r=106, g=070, b=041, a=127}, --Boat
    ['5d-truck']                                            ={r=174, g=142, b=113, a=127}, --Truck
}