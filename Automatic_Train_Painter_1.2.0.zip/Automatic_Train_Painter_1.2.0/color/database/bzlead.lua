bzlead={
    ['compressed-lead-ore']                                 ={r=103, g=076, b=078, a=127}, --Compressed lead ore
    ['enriched-lead']                                       ={r=058, g=041, b=047, a=127}, --Enriched lead
    ['lead-alloy']                                          ={r=071, g=055, b=056, a=127}, --Lead alloy
    ['lead-chest']                                          ={r=072, g=058, b=058, a=127}, --Lead chest
    ['lead-dust-bzpb']                                      ={r=088, g=066, b=077, a=127}, --Lead dust
    ['lead-ore']                                            ={r=103, g=076, b=078, a=127}, --Lead ore
    ['lead-plate-bzpb']                                     ={r=071, g=055, b=056, a=127}, --Lead plate
}

bzlead_filters={
    "lead-dust",
    "lead-plate",
}