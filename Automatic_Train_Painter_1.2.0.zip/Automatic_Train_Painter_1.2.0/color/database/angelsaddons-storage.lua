angelsaddons_storage={
    ['angels-pressure-tank-1']                              ={r=146, g=199, b=247, a=127}, --Jax 35 pressure tank
    ['angels-warehouse']                                    ={r=056, g=056, b=058, a=127}, --Warehouse
    ['angels-warehouse-active-provider']                    ={r=115, g=000, b=197, a=127}, --Active provider warehouse
    ['angels-warehouse-buffer']                             ={r=000, g=206, b=019, a=127}, --Buffer warehouse
    ['angels-warehouse-passive-provider']                   ={r=255, g=026, b=000, a=127}, --Passive provider warehouse
    ['angels-warehouse-requester']                          ={r=000, g=115, b=197, a=127}, --Requester warehouse
    ['angels-warehouse-storage']                            ={r=254, g=188, b=019, a=127}, --Storage warehouse
    ['silo']                                                ={r=061, g=064, b=073, a=127}, --Silo
    ['silo-active-provider']                                ={r=115, g=000, b=197, a=127}, --Active provider silo
    ['silo-buffer']                                         ={r=000, g=206, b=019, a=127}, --Buffer silo
    ['silo-coal']                                           ={r=036, g=050, b=058, a=127}, --Coal silo
    ['silo-ore1']                                           ={r=048, g=062, b=120, a=127}, --Saphirite silo
    ['silo-ore2']                                           ={r=139, g=136, b=000, a=127}, --Jivolite silo
    ['silo-ore3']                                           ={r=029, g=101, b=187, a=127}, --Stiratite silo
    ['silo-ore4']                                           ={r=158, g=162, b=173, a=127}, --Crotinnium silo
    ['silo-ore5']                                           ={r=130, g=050, b=007, a=127}, --Rubyte silo
    ['silo-ore6']                                           ={r=080, g=039, b=012, a=127}, --Bobmonium silo
    ['silo-passive-provider']                               ={r=255, g=026, b=000, a=127}, --Passive provider silo
    ['silo-requester']                                      ={r=000, g=115, b=197, a=127}, --Requester silo
    ['silo-storage']                                        ={r=254, g=188, b=019, a=127}, --Storage silo
}