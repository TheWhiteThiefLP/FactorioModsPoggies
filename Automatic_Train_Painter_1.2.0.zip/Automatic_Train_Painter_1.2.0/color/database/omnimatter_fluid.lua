omnimatter_fluid={
    ['steam-T-165']                                         ={r=255, g=255, b=255, a=127}, --Steam T 165 C
}