Clowns_Science={
    ['facility-mk1']                                        ={r=255, g=014, b=000, a=127}, --Research Facility MK1
    ['facility-mk2']                                        ={r=255, g=014, b=000, a=127}, --Research Facility MK2
    ['facility-mk3']                                        ={r=255, g=014, b=000, a=127}, --Research Facility MK3
    ['particle-accelerator-mk1']                            ={r=241, g=011, b=000, a=127}, --Particle Accelerator MK1
    ['particle-accelerator-mk2']                            ={r=241, g=011, b=000, a=127}, --Particle Accelerator MK2
}

Clowns_Science_filters={

}