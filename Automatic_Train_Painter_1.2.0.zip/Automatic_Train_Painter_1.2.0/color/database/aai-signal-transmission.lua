aai_signal_transmission={
    ['aai-signal-receiver']                                 ={r=028, g=157, b=002, a=127}, --Signal receiver
    ['aai-signal-sender']                                   ={r=082, g=197, b=060, a=127}, --Signal transmitter
}