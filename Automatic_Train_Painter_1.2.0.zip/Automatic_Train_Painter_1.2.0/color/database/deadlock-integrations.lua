deadlock_integrations={
    ['basic-transport-belt-beltbox']                        ={r=198, g=198, b=198, a=127}, --Basic stacking beltbox
    ['basic-transport-belt-loader']                         ={r=198, g=198, b=198, a=127}, --Basic compact loader
    ['blistering-transport-belt-beltbox']                   ={r=000, g=255, b=018, a=127}, --Blistering stacking beltbox
    ['blistering-transport-belt-loader']                    ={r=000, g=255, b=018, a=127}, --Blistering compact loader
    ['expedited-transport-belt-beltbox']                    ={r=000, g=255, b=018, a=127}, --Expedited stacking beltbox
    ['expedited-transport-belt-loader']                     ={r=000, g=255, b=018, a=127}, --Expedited compact loader
    ['furious-transport-belt-beltbox']                      ={r=000, g=018, b=255, a=127}, --Furious stacking beltbox
    ['furious-transport-belt-loader']                       ={r=000, g=018, b=255, a=127}, --Furious compact loader
    ['rapid-transport-belt-mk1-beltbox']                    ={r=000, g=255, b=018, a=127}, --Rapid stacking beltbox mk1
    ['rapid-transport-belt-mk1-loader']                     ={r=000, g=255, b=018, a=127}, --Rapid compact loader mk1
    ['rapid-transport-belt-mk2-beltbox']                    ={r=255, g=000, b=255, a=127}, --Rapid stacking beltbox mk2
    ['rapid-transport-belt-mk2-loader']                     ={r=255, g=000, b=255, a=127}, --Rapid compact loader mk2
    ['slow-transport-belt-beltbox']                         ={r=199, g=199, b=098, a=127}, --Slow stacking beltbox
    ['slow-transport-belt-loader']                          ={r=199, g=199, b=098, a=127}, --Slow compact loader
    ['turbo-transport-belt-beltbox']                        ={r=184, g=000, b=255, a=127}, --Turbo stacking beltbox
    ['turbo-transport-belt-loader']                         ={r=184, g=000, b=255, a=127}, --Turbo compact loader
    ['ultimate-transport-belt-beltbox']                     ={r=000, g=255, b=018, a=127}, --Ultimate stacking beltbox
    ['ultimate-transport-belt-loader']                      ={r=000, g=255, b=018, a=127}, --Ultimate compact loader
}