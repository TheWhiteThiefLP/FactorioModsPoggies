aai_vehicles_laser_tank={
    ['laser-cannon-battery-focussed']                       ={r=255, g=022, b=146, a=127}, --Laser Cannon Battery Focussed
    ['laser-cannon-battery-piercing']                       ={r=024, g=020, b=255, a=127}, --Laser Cannon Battery Piercing
    ['laser-tank-cannon']                                   ={r=255, g=142, b=000, a=127}, --Laser Cannon
    ['vehicle-laser-tank']                                  ={r=255, g=142, b=000, a=127}, --Laser Tank
    ['vehicle-laser-tank-laser-tank-cannon']                ={r=255, g=142, b=000, a=127}, --AI Laser Tank
}