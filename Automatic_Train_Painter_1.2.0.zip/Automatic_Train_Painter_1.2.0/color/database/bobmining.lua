bobmining={
    ['bob-area-mining-drill-1']                             ={r=175, g=103, b=080, a=127}, --Electric large area mining drill 2
    ['bob-area-mining-drill-2']                             ={r=175, g=103, b=080, a=127}, --Electric large area mining drill 3
    ['bob-area-mining-drill-3']                             ={r=175, g=103, b=080, a=127}, --Electric large area mining drill 4
    ['bob-area-mining-drill-4']                             ={r=175, g=103, b=080, a=127}, --Electric large area mining drill 5
    ['bob-mining-drill-1']                                  ={r=175, g=103, b=080, a=127}, --__ENTITY__electric-mining-drill__ 2
    ['bob-mining-drill-2']                                  ={r=175, g=103, b=080, a=127}, --__ENTITY__electric-mining-drill__ 3
    ['bob-mining-drill-3']                                  ={r=175, g=103, b=080, a=127}, --__ENTITY__electric-mining-drill__ 4
    ['bob-mining-drill-4']                                  ={r=175, g=103, b=080, a=127}, --__ENTITY__electric-mining-drill__ 5
    ['bob-pumpjack-1']                                      ={r=099, g=151, b=000, a=127}, --Pumpjack 2
    ['bob-pumpjack-2']                                      ={r=099, g=151, b=000, a=127}, --Pumpjack 3
    ['bob-pumpjack-3']                                      ={r=099, g=151, b=000, a=127}, --Pumpjack 4
    ['bob-pumpjack-4']                                      ={r=099, g=151, b=000, a=127}, --Pumpjack 5
    ['steam-mining-drill']                                  ={r=118, g=091, b=092, a=127}, --Steam powered mining drill
    ['water-miner-1']                                       ={r=010, g=097, b=109, a=127}, --Water Pumpjack 1
    ['water-miner-2']                                       ={r=010, g=097, b=109, a=127}, --Water Pumpjack 2
    ['water-miner-3']                                       ={r=010, g=097, b=109, a=127}, --Water Pumpjack 3
    ['water-miner-4']                                       ={r=010, g=097, b=109, a=127}, --Water Pumpjack 4
    ['water-miner-5']                                       ={r=010, g=097, b=109, a=127}, --Water Pumpjack 5
}