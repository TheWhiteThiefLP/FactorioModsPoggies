aai_vehicles_miner={
    ['vehicle-miner']                                       ={r=203, g=157, b=000, a=127}, --Mining Vehicle MK1
    ['vehicle-miner-0']                                     ={r=203, g=157, b=000, a=127}, --AI Mining Vehicle MK1
    ['vehicle-miner-mk2']                                   ={r=188, g=000, b=003, a=127}, --Mining Vehicle MK2
    ['vehicle-miner-mk2-0']                                 ={r=188, g=000, b=003, a=127}, --AI Mining Vehicle MK2
    ['vehicle-miner-mk3']                                   ={r=000, g=043, b=202, a=127}, --Mining Vehicle MK3
    ['vehicle-miner-mk3-0']                                 ={r=000, g=043, b=202, a=127}, --AI Mining Vehicle MK3
    ['vehicle-miner-mk4']                                   ={r=156, g=000, b=220, a=127}, --Mining Vehicle MK4
    ['vehicle-miner-mk4-0']                                 ={r=156, g=000, b=220, a=127}, --AI Mining Vehicle MK4
    ['vehicle-miner-mk5']                                   ={r=020, g=224, b=000, a=127}, --Mining Vehicle MK5
    ['vehicle-miner-mk5-0']                                 ={r=020, g=224, b=000, a=127}, --AI Mining Vehicle MK5
}