bobtech={
    ['advanced-logistic-science-pack']                      ={r=223, g=011, b=200, a=127}, --Advanced logistic science pack
    ['alien-science-pack']                                  ={r=209, g=043, b=255, a=127}, --Alien science pack
    ['alien-science-pack-blue']                             ={r=000, g=126, b=255, a=127}, --Blue alien science pack
    ['alien-science-pack-green']                            ={r=000, g=255, b=001, a=127}, --Green alien science pack
    ['alien-science-pack-orange']                           ={r=255, g=122, b=000, a=127}, --Orange alien science pack
    ['alien-science-pack-purple']                           ={r=071, g=000, b=255, a=127}, --Purple alien science pack
    ['alien-science-pack-red']                              ={r=255, g=011, b=000, a=127}, --Red alien science pack
    ['alien-science-pack-yellow']                           ={r=255, g=211, b=000, a=127}, --Yellow alien science pack
    ['automation-science-pack-bobt']                        ={r=255, g=204, b=000, a=127}, --Automation science pack
    ['burner-lab']                                          ={r=250, g=007, b=000, a=127}, --Burner lab
    ['lab-2']                                               ={r=072, g=187, b=101, a=127}, --Lab 2
    ['lab-alien']                                           ={r=212, g=178, b=211, a=127}, --Alien lab
    ['logistic-science-pack-bobt']                          ={r=227, g=000, b=028, a=127}, --Logistic science pack
    ['science-pack-4']                                      ={r=000, g=054, b=218, a=127}, --Science pack 4
    ['science-pack-gold']                                   ={r=255, g=096, b=021, a=127}, --Gold science pack
    ['steam-science-pack']                                  ={r=255, g=253, b=255, a=127}, --Steam science pack
    ['transport-science-pack']                              ={r=227, g=000, b=028, a=127}, --Transport science pack
    ['utility-science-pack-bobt']                           ={r=042, g=139, b=004, a=127}, --Utility science pack
}

bobtech_filters={
    "automation-science-pack",
    "logistic-science-pack",
    "utility-science-pack",
}