bztitanium={
    ['compressed-titanium-ore']                             ={r=198, g=196, b=167, a=127}, --Compressed titanium ore
    ['enriched-titanium']                                   ={r=217, g=205, b=183, a=127}, --Enriched titanium
    ['titanium-alloy']                                      ={r=199, g=194, b=170, a=127}, --Titanium alloy
    ['titanium-dust']                                       ={r=206, g=206, b=179, a=127}, --Titanium dust
    ['titanium-ore-bzti']                                   ={r=198, g=196, b=167, a=127}, --Titanium ore
    ['titanium-plate']                                      ={r=199, g=194, b=170, a=127}, --Titanium plate
}

bztitanium_filters={
    "titanium-ore",
}