local mod = {}

mod.name = "Kux-OrbitalIonCannon"
mod.path="__"..mod.name.."__/"
mod.prefix=mod.name.."-"

mod.KuxCoreLibPath="__Kux-CoreLib__/lib/"

return mod