# Orbital Ion Cannon
A Factorio Mod

Based on [Supercheese's Orbital Ion Cannon](https://mods.factorio.com/mod/Orbital%20Ion%20Cannon)

Feel free to add you ideas and contribute to this repository.

### Files to change for each release
- changelog.txt
- [Version](###Versionscheme) in info_1.0.json AND info_1.1.json

### Version scheme
X.Y.Z\
X = Factorio Version (1 = 1.0, 2= 1.1, ...)\
Y = Feature version (increment on each new feature)\
Z = Patch version (increment on each bugfix or small changes)\

### Contact
- [Mod Portal](https://mods.factorio.com/mod/Kux-Kux-OrbitalIonCannon/discussion)
- [Discord](https://discord.gg/BWUTaJy)
- [Facebook](https://www.facebook.com/Kuxynator.Factorio)
- [GitHub](https://github.com/kuxynator/Kux-Kux-OrbitalIonCannon)
- [Patreon](https://www.patreon.com/kuxynator)
