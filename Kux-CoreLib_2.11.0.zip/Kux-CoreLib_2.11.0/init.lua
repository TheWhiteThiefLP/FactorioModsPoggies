return require((KuxCoreLibPath or "__Kux-CoreLib__/").."lib/init")
