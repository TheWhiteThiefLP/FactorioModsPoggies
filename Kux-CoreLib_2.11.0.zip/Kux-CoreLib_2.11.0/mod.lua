require("init")

local mod = {}

mod.name = "Kux-CoreLib"
mod.path="__"..mod.name.."__/"
mod.prefix=mod.name.."-"

return mod