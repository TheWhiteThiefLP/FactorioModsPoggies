require("init")
print(KuxCoreLib.ModInfo.current_stage)