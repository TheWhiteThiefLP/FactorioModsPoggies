data:extend({
    {
        type = "bool-setting",
        name = "wire-shortcuts-is-retain-wire-crafting",
        setting_type = "startup",
        default_value = false
    },
    {
        type = "bool-setting",
        name = "wire-shortcuts-is-advanced-cutter",
        setting_type = "runtime-per-user",
        default_value = false
    }
})