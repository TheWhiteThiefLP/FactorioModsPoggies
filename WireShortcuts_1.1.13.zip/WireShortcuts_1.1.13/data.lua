require("prototypes.input")
require("prototypes.shortcut")
require("prototypes.wire-cutter")
require("prototypes.fake-wire")
